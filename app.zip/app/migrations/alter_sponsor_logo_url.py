"""
Migration script to alter the logo_url column in the sponsors table
from VARCHAR(255) to TEXT to accommodate large base64 encoded images.
"""

from sqlalchemy import create_engine, text
from db.config import settings

def run_migration():
    """
    Run the migration to alter the logo_url column in the sponsors table.
    """
    # Create engine
    engine = create_engine(settings.DATABASE_URL)
    
    # Connect to the database
    with engine.connect() as connection:
        # Begin transaction
        with connection.begin():
            # Alter the logo_url column to TEXT type
            connection.execute(text("""
                ALTER TABLE sponsors
                MODIFY COLUMN logo_url TEXT;
            """))
            
            print("Migration completed successfully: Changed logo_url column from VARCHAR(255) to TEXT")

if __name__ == "__main__":
    run_migration()
