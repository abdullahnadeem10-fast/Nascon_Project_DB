"""
Script to run all migrations in the correct order.
"""

from alter_sponsor_logo_url import run_migration as alter_sponsor_logo_url

def run_all_migrations():
    """
    Run all migrations in the correct order.
    """
    print("Starting migrations...")
    
    # Run migrations in order
    alter_sponsor_logo_url()
    
    print("All migrations completed successfully!")

if __name__ == "__main__":
    run_all_migrations()
