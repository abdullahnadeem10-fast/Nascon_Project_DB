from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict
from decimal import Decimal

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.sponsorship import (
    create_sponsorship_payment,
    get_sponsorship_payment,
    get_sponsorship_payment_with_details,
    get_sponsorship_payments,
    get_sponsorship_payments_summary,
    update_sponsorship_payment,
    delete_sponsorship_payment
)
from schemas.sponsorship import (
    SponsorshipPaymentCreate,
    SponsorshipPaymentUpdate,
    SponsorshipPayment,
    SponsorshipPaymentDetail,
    SponsorshipPaymentResponse,
    SponsorshipPaymentDetailResponse,
    SponsorshipPaymentList
)
from schemas.rbac.user import User

router = APIRouter(prefix="/payments", tags=["sponsorship_payments"])

@router.post("/", response_model=SponsorshipPaymentResponse)
def create_payment_endpoint(
    payment: SponsorshipPaymentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new sponsorship payment"""
    db_payment = create_sponsorship_payment(db, payment, current_user.id)
    return SponsorshipPaymentResponse(
        message="Sponsorship payment recorded successfully",
        payment=db_payment
    )

@router.get("/", response_model=SponsorshipPaymentList)
def get_payments_endpoint(
    skip: int = 0,
    limit: int = 100,
    contract_id: Optional[int] = None,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all sponsorship payments with optional filters"""
    payments = get_sponsorship_payments(db, skip, limit, contract_id)
    total_amount = sum(payment.amount for payment in payments)
    return SponsorshipPaymentList(
        payments=payments,
        total=len(payments),
        total_amount=total_amount
    )

@router.get("/contract/{contract_id}/summary", response_model=Dict)
def get_payments_summary_endpoint(
    contract_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get summary of payments for a contract"""
    return get_sponsorship_payments_summary(db, contract_id)

@router.get("/{payment_id}", response_model=SponsorshipPayment)
def get_payment_endpoint(
    payment_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get a sponsorship payment by ID"""
    return get_sponsorship_payment(db, payment_id)

@router.get("/{payment_id}/details", response_model=SponsorshipPaymentDetailResponse)
def get_payment_details_endpoint(
    payment_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get a sponsorship payment with detailed information"""
    payment_details = get_sponsorship_payment_with_details(db, payment_id)
    return SponsorshipPaymentDetailResponse(
        message="Sponsorship payment details retrieved successfully",
        payment=payment_details
    )

@router.put("/{payment_id}", response_model=SponsorshipPaymentResponse)
def update_payment_endpoint(
    payment_id: int,
    payment: SponsorshipPaymentUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Update a sponsorship payment"""
    updated_payment = update_sponsorship_payment(db, payment_id, payment)
    return SponsorshipPaymentResponse(
        message="Sponsorship payment updated successfully",
        payment=updated_payment
    )

@router.delete("/{payment_id}", response_model=SponsorshipPaymentResponse)
def delete_payment_endpoint(
    payment_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Delete a sponsorship payment"""
    deleted_payment = delete_sponsorship_payment(db, payment_id)
    return SponsorshipPaymentResponse(
        message="Sponsorship payment deleted successfully",
        payment=deleted_payment
    )
