from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.sponsorship import (
    create_sponsorship_package,
    get_sponsorship_package,
    get_sponsorship_packages,
    get_sponsorship_packages_with_stats,
    update_sponsorship_package,
    delete_sponsorship_package
)
from schemas.sponsorship import (
    SponsorshipPackageCreate,
    SponsorshipPackageUpdate,
    SponsorshipPackage,
    SponsorshipPackageWithStats,
    SponsorshipPackageResponse,
    SponsorshipPackageList
)
from schemas.rbac.user import User

router = APIRouter(prefix="/packages", tags=["sponsorship_packages"])

@router.post("/", response_model=SponsorshipPackageResponse)
def create_package_endpoint(
    package: SponsorshipPackageCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new sponsorship package"""
    db_package = create_sponsorship_package(db, package)
    return SponsorshipPackageResponse(
        message="Sponsorship package created successfully",
        package=db_package
    )

@router.get("/", response_model=SponsorshipPackageList)
def get_packages_endpoint(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all sponsorship packages"""
    packages = get_sponsorship_packages(db, skip, limit)
    return SponsorshipPackageList(
        packages=packages,
        total=len(packages)
    )

@router.get("/with-stats", response_model=List[SponsorshipPackageWithStats])
def get_packages_with_stats_endpoint(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Get all sponsorship packages with contract statistics"""
    return get_sponsorship_packages_with_stats(db, skip, limit)

@router.get("/{package_id}", response_model=SponsorshipPackage)
def get_package_endpoint(
    package_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get a sponsorship package by ID"""
    return get_sponsorship_package(db, package_id)

@router.put("/{package_id}", response_model=SponsorshipPackageResponse)
def update_package_endpoint(
    package_id: int,
    package: SponsorshipPackageUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Update a sponsorship package"""
    updated_package = update_sponsorship_package(db, package_id, package)
    return SponsorshipPackageResponse(
        message="Sponsorship package updated successfully",
        package=updated_package
    )

@router.delete("/{package_id}", response_model=SponsorshipPackageResponse)
def delete_package_endpoint(
    package_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Delete a sponsorship package"""
    deleted_package = delete_sponsorship_package(db, package_id)
    return SponsorshipPackageResponse(
        message="Sponsorship package deleted successfully",
        package=deleted_package
    )
