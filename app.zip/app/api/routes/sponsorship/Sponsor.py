from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.sponsorship import (
    create_sponsor,
    get_sponsor,
    get_sponsors,
    get_sponsors_with_stats,
    update_sponsor,
    delete_sponsor
)
from schemas.sponsorship import (
    SponsorCreate,
    SponsorUpdate,
    Sponsor,
    SponsorWithStats,
    SponsorResponse,
    SponsorList
)
from schemas.rbac.user import User

router = APIRouter(prefix="/sponsors", tags=["sponsors"])

@router.post("/", response_model=SponsorResponse)
def create_sponsor_endpoint(
    sponsor: SponsorCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new sponsor"""
    db_sponsor = create_sponsor(db, sponsor)
    return SponsorResponse(
        message="Sponsor created successfully",
        sponsor=db_sponsor
    )

@router.get("/", response_model=SponsorList)
def get_sponsors_endpoint(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all sponsors"""
    sponsors = get_sponsors(db, skip, limit)
    return SponsorList(
        sponsors=sponsors,
        total=len(sponsors)
    )

@router.get("/with-stats", response_model=List[SponsorWithStats])
def get_sponsors_with_stats_endpoint(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Get all sponsors with contract statistics"""
    return get_sponsors_with_stats(db, skip, limit)

@router.get("/{sponsor_id}", response_model=Sponsor)
def get_sponsor_endpoint(
    sponsor_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get a sponsor by ID"""
    return get_sponsor(db, sponsor_id)

@router.put("/{sponsor_id}", response_model=SponsorResponse)
def update_sponsor_endpoint(
    sponsor_id: int,
    sponsor: SponsorUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Update a sponsor"""
    updated_sponsor = update_sponsor(db, sponsor_id, sponsor)
    return SponsorResponse(
        message="Sponsor updated successfully",
        sponsor=updated_sponsor
    )

@router.delete("/{sponsor_id}", response_model=SponsorResponse)
def delete_sponsor_endpoint(
    sponsor_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Delete a sponsor"""
    deleted_sponsor = delete_sponsor(db, sponsor_id)
    return SponsorResponse(
        message="Sponsor deleted successfully",
        sponsor=deleted_sponsor
    )
