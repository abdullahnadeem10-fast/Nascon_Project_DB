from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.sponsorship import (
    create_sponsorship_contract,
    get_sponsorship_contract,
    get_sponsorship_contract_with_details,
    get_sponsorship_contracts,
    update_sponsorship_contract,
    delete_sponsorship_contract
)
from schemas.sponsorship import (
    ContractStatus,
    SponsorshipContractCreate,
    SponsorshipContractUpdate,
    SponsorshipContract,
    SponsorshipContractDetail,
    SponsorshipContractResponse,
    SponsorshipContractDetailResponse,
    SponsorshipContractList
)
from schemas.rbac.user import User

router = APIRouter(prefix="/contracts", tags=["sponsorship_contracts"])

@router.post("/", response_model=SponsorshipContractResponse)
def create_contract_endpoint(
    contract: SponsorshipContractCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new sponsorship contract"""
    db_contract = create_sponsorship_contract(db, contract, current_user.id)
    return SponsorshipContractResponse(
        message="Sponsorship contract created successfully",
        contract=db_contract
    )

@router.get("/", response_model=SponsorshipContractList)
def get_contracts_endpoint(
    skip: int = 0,
    limit: int = 100,
    sponsor_id: Optional[int] = None,
    package_id: Optional[int] = None,
    status: Optional[ContractStatus] = None,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all sponsorship contracts with optional filters"""
    contracts = get_sponsorship_contracts(
        db, skip, limit, sponsor_id, package_id, 
        status.value if status else None
    )
    return SponsorshipContractList(
        contracts=contracts,
        total=len(contracts)
    )

@router.get("/{contract_id}", response_model=SponsorshipContract)
def get_contract_endpoint(
    contract_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get a sponsorship contract by ID"""
    return get_sponsorship_contract(db, contract_id)

@router.get("/{contract_id}/details", response_model=SponsorshipContractDetailResponse)
def get_contract_details_endpoint(
    contract_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get a sponsorship contract with detailed information"""
    contract_details = get_sponsorship_contract_with_details(db, contract_id)
    return SponsorshipContractDetailResponse(
        message="Sponsorship contract details retrieved successfully",
        contract=contract_details
    )

@router.put("/{contract_id}", response_model=SponsorshipContractResponse)
def update_contract_endpoint(
    contract_id: int,
    contract: SponsorshipContractUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Update a sponsorship contract"""
    updated_contract = update_sponsorship_contract(db, contract_id, contract)
    return SponsorshipContractResponse(
        message="Sponsorship contract updated successfully",
        contract=updated_contract
    )

@router.delete("/{contract_id}", response_model=SponsorshipContractResponse)
def delete_contract_endpoint(
    contract_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_sponsorships")),
    token: str = Depends(oauth2_scheme)
):
    """Delete a sponsorship contract"""
    deleted_contract = delete_sponsorship_contract(db, contract_id)
    return SponsorshipContractResponse(
        message="Sponsorship contract deleted successfully",
        contract=deleted_contract
    )
