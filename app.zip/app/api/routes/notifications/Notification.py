from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.notifications.Notification import (
    create_notification,
    get_notification,
    get_notifications,
    get_unread_count,
    update_notification,
    mark_as_read,
    mark_all_as_read,
    delete_notification,
    delete_all_notifications,
    create_system_notification,
    create_bulk_notifications
)
from schemas.notifications.Notification import (
    NotificationCreate,
    NotificationResponse,
    NotificationUpdate,
    Notification,
    NotificationList
)
from schemas.rbac.user import User

router = APIRouter(prefix="/notifications", tags=["notifications"])

@router.post("/", response_model=NotificationResponse)
def create_notification_endpoint(
    notification: NotificationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_notifications")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new notification"""
    db_notification = create_notification(db, notification)
    return NotificationResponse(
        message="Notification created successfully",
        notification=db_notification
    )

@router.get("/", response_model=NotificationList)
def get_user_notifications(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Get all notifications for the current user"""
    notifications = get_notifications(db, current_user.id, skip, limit)
    unread_count = get_unread_count(db, current_user.id)
    return NotificationList(
        notifications=notifications,
        total=len(notifications),
        unread_count=unread_count
    )

@router.get("/unread-count", response_model=dict)
def get_unread_notifications_count(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Get count of unread notifications for the current user"""
    count = get_unread_count(db, current_user.id)
    return {"unread_count": count}

@router.get("/{notification_id}", response_model=Notification)
def get_notification_by_id(
    notification_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Get a notification by ID"""
    notification = get_notification(db, notification_id)

    # Check if the notification belongs to the current user
    if notification.user_id != current_user.id:
        # Allow admins to view any notification
        _=Depends(require_permission("manage_notifications"))

    return notification

@router.put("/{notification_id}", response_model=NotificationResponse)
def update_notification_endpoint(
    notification_id: int,
    notification: NotificationUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Update a notification"""
    db_notification = get_notification(db, notification_id)

    # Check if the notification belongs to the current user
    if db_notification.user_id != current_user.id:
        # Allow admins to update any notification
        _=Depends(require_permission("manage_notifications"))

    updated_notification = update_notification(db, notification_id, notification)
    return NotificationResponse(
        message="Notification updated successfully",
        notification=updated_notification
    )

@router.put("/{notification_id}/read", response_model=NotificationResponse)
def mark_notification_as_read(
    notification_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Mark a notification as read"""
    notification = get_notification(db, notification_id)

    # Check if the notification belongs to the current user
    if notification.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to mark this notification as read")

    updated_notification = mark_as_read(db, notification_id)
    return NotificationResponse(
        message="Notification marked as read",
        notification=updated_notification
    )

@router.put("/mark-all-read", response_model=dict)
def mark_all_notifications_as_read(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Mark all notifications as read for the current user"""
    count = mark_all_as_read(db, current_user.id)
    return {"message": f"{count} notifications marked as read"}

@router.delete("/{notification_id}", response_model=dict)
def delete_notification_endpoint(
    notification_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Delete a notification"""
    notification = get_notification(db, notification_id)

    # Check if the notification belongs to the current user
    if notification.user_id != current_user.id:
        # Allow admins to delete any notification
        _=Depends(require_permission("manage_notifications"))

    delete_notification(db, notification_id)
    return {"message": "Notification deleted successfully"}

@router.delete("/", response_model=dict)
def delete_all_notifications_endpoint(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Delete all notifications for the current user"""
    count = delete_all_notifications(db, current_user.id)
    return {"message": f"{count} notifications deleted successfully"}

@router.post("/system", response_model=NotificationResponse)
def create_system_notification_endpoint(
    title: str,
    message: str,
    user_id: int,
    notification_type: str = "System",
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_notifications")),
    token: str = Depends(oauth2_scheme)
):
    """Create a system notification for a specific user"""
    db_notification = create_system_notification(
        db=db,
        user_id=user_id,
        title=title,
        message=message,
        notification_type=notification_type
    )
    return NotificationResponse(
        message="System notification created successfully",
        notification=db_notification
    )

@router.post("/bulk", response_model=dict)
def create_bulk_notifications_endpoint(
    title: str,
    message: str,
    user_ids: List[int],
    notification_type: str = "System",
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_notifications")),
    token: str = Depends(oauth2_scheme)
):
    """Create notifications for multiple users at once"""
    count = create_bulk_notifications(
        db=db,
        user_ids=user_ids,
        title=title,
        message=message,
        notification_type=notification_type
    )
    return {"message": f"{count} notifications created successfully"}
