from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.notifications.Announcement import (
    create_announcement,
    get_announcement,
    get_announcement_with_publisher,
    get_announcements,
    get_announcements_by_event,
    get_announcements_by_audience,
    update_announcement,
    delete_announcement,
    toggle_announcement_status
)
from schemas.notifications.Announcement import (
    AnnouncementCreate,
    AnnouncementResponse,
    AnnouncementUpdate,
    Announcement,
    AnnouncementWithPublisher,
    AnnouncementList,
    TargetAudience
)
from schemas.rbac.user import User

router = APIRouter(prefix="/announcements", tags=["announcements"])

@router.post("/", response_model=AnnouncementResponse)
def create_announcement_endpoint(
    announcement: AnnouncementCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_announcements")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new announcement"""
    db_announcement = create_announcement(db, announcement, current_user.id)
    return AnnouncementResponse(
        message="Announcement created successfully",
        announcement=db_announcement
    )

@router.get("/", response_model=AnnouncementList)
def get_all_announcements(
    skip: int = 0,
    limit: int = 100,
    active_only: bool = True,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all announcements"""
    announcements = get_announcements(db, skip, limit, active_only)
    return AnnouncementList(
        announcements=announcements,
        total=len(announcements)
    )

@router.get("/event/{event_id}", response_model=AnnouncementList)
def get_event_announcements(
    event_id: int,
    skip: int = 0,
    limit: int = 100,
    active_only: bool = True,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all announcements for a specific event"""
    announcements = get_announcements_by_event(db, event_id, skip, limit, active_only)
    return AnnouncementList(
        announcements=announcements,
        total=len(announcements)
    )

@router.get("/audience/{audience}", response_model=AnnouncementList)
def get_audience_announcements(
    audience: TargetAudience,
    skip: int = 0,
    limit: int = 100,
    active_only: bool = True,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get all announcements for a specific audience"""
    announcements = get_announcements_by_audience(db, audience, skip, limit, active_only)
    return AnnouncementList(
        announcements=announcements,
        total=len(announcements)
    )

@router.get("/{announcement_id}", response_model=Announcement)
def get_announcement_by_id(
    announcement_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get an announcement by ID"""
    return get_announcement(db, announcement_id)

@router.get("/{announcement_id}/with-publisher", response_model=AnnouncementWithPublisher)
def get_announcement_with_publisher_endpoint(
    announcement_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Get an announcement with publisher details"""
    return get_announcement_with_publisher(db, announcement_id)

@router.put("/{announcement_id}", response_model=AnnouncementResponse)
def update_announcement_endpoint(
    announcement_id: int,
    announcement: AnnouncementUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_announcements")),
    token: str = Depends(oauth2_scheme)
):
    """Update an announcement"""
    updated_announcement = update_announcement(db, announcement_id, announcement)
    return AnnouncementResponse(
        message="Announcement updated successfully",
        announcement=updated_announcement
    )

@router.put("/{announcement_id}/toggle-status", response_model=AnnouncementResponse)
def toggle_announcement_status_endpoint(
    announcement_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_announcements")),
    token: str = Depends(oauth2_scheme)
):
    """Toggle the active status of an announcement"""
    updated_announcement = toggle_announcement_status(db, announcement_id)
    status = "activated" if updated_announcement.is_active else "deactivated"
    return AnnouncementResponse(
        message=f"Announcement {status} successfully",
        announcement=updated_announcement
    )

@router.delete("/{announcement_id}", response_model=dict)
def delete_announcement_endpoint(
    announcement_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_announcements")),
    token: str = Depends(oauth2_scheme)
):
    """Delete an announcement"""
    delete_announcement(db, announcement_id)
    return {"message": "Announcement deleted successfully"}
