from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import List

from core.security import create_access_token, get_password_hash, verify_password, oauth2_scheme
from crud.rbac import user as user_crud
from crud.rbac import token as token_crud

from jose import jwt
from crud.rbac.roles import create_role, get_role, get_role_by_name
from models import User
from schemas.rbac.role import RoleCreate
from schemas.rbac.user import UserCreate, UserResponse, UserUpdate, User, UserBase
from api.deps import ALGORITHM, SECRET_KEY, get_db, get_current_user
from core.permissions import require_permission

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/check-auth", response_model=UserResponse)
def auth(
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    user = get_current_user(token, db)
    return UserResponse(message="User authenticated successfully", user=user)

@router.post("/", response_model=User, status_code=status.HTTP_201_CREATED)
def create_user(user_create: UserCreate, db: Session = Depends(get_db)):
    db_user = user_crud.get_user_by_username(db, user_create.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    return user_crud.create_user(db, user_create)

@router.get("/", response_model=List[User])
def get_all_users(db: Session = Depends(get_db)):
    return user_crud.get_users(db)

@router.get("/me", response_model=User)
def get_current_user_info(
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_me")),
    token: str = Depends(oauth2_scheme)
):
    user = get_current_user(token, db)
    return user

@router.get("/{user_id}", response_model=User)
def read_user(
    user_id: int,  # Changed from str to int
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("view_user")),
    token: str = Depends(oauth2_scheme)
):
    db_user = user_crud.get_user(db, user_id=user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    return db_user


@router.put("/{user_id}", response_model=User)
def update_user(user_id: int, user_data: UserUpdate, db: Session = Depends(get_db)):  # Changed from str to int
    updated_user = user_crud.update_user(db, user_id=user_id, user_update=user_data)  # Fixed parameter name
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user

@router.delete("/{user_id}", response_model=User)
def delete_user(user_id: int, db: Session = Depends(get_db)):  # Changed from str to int
    deleted_user = user_crud.delete_user(db, user_id=user_id)
    if not deleted_user:
        raise HTTPException(status_code=404, detail="User not found")
    return deleted_user

@router.post("/signup", response_model=User)
async def signup(user_data: UserCreate, db: Session = Depends(get_db)):
    # Get or create the role based on user selection
    role_name = user_data.role_type.value
    role = get_role_by_name(db, name=role_name)

    if role is None:
        # Create the role if it doesn't exist
        role_descriptions = {
            "Event Organizer": "Handle events, venues, sponsorships, accommodations",
            "Participant": "Register and participate in events",
            "Sponsor": "Provide funding and get branding opportunities",
            "Judge": "Evaluate competitions and assign scores",
            "User": "Default user role with basic permissions"
        }

        role_create = RoleCreate(
            role_name=role_name,
            description=role_descriptions.get(role_name, "")
        )
        role = create_role(db, role_create)

    # Create the user
    new_user = user_crud.create_user(db, user_data)

    if new_user:
        # Assign the selected role to the new user
        user_crud.assign_role_to_user(db, new_user.id, role.id)
        return new_user

    raise HTTPException(status_code=400, detail="User already exists")

@router.post("/{user_id}/assign_role/{role_id}", response_model=dict)
async def assign_role_to_user_endpoint(user_id: int, role_id: int, db: Session = Depends(get_db)):  # Changed from str to int
    db_user = user_crud.get_user(db, user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")

    db_role = get_role(db, role_id=role_id)
    if not db_role:
        raise HTTPException(status_code=404, detail="Role not found")

    result = user_crud.assign_role_to_user(db, user_id=db_user.id, role_id=db_role.id)
    return result



class Token(BaseModel):
    access_token: str
    token_type: str

class Login(BaseModel):
    email: str
    password: str

@router.post("/signin", response_model=Token)
async def signin(login: Login, db: Session = Depends(get_db)):
    db_user = user_crud.get_user_by_email(db, email=login.email)
    if not db_user:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Verify the password hash
    if not verify_password(login.password, db_user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Update last_login timestamp
    db_user.last_login = datetime.now(timezone.utc)
    db.commit()

    # Create a JWT token
    access_token = create_access_token(data={"sub": db_user.email})

    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/logout")
async def logout(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    # Decode token to get expiry time
    payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    exp = payload.get("exp")
    if exp is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid token")

    # Convert exp (Unix timestamp) to datetime
    expires_at = datetime.fromtimestamp(exp)

    # Blacklist the token
    token_crud.blacklist_token(db, token, expires_at)

    # Cleanup expired tokens while we're here
    token_crud.cleanup_expired_tokens(db)

    return {"msg": "Successfully logged out"}



