from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from crud.rbac import permissions
from schemas.rbac.permission import PermissionCreate, PermissionUpdate, Permission, PermissionResponse
from api.deps import get_db

router = APIRouter(prefix="/permissions", tags=["permissions"])

@router.post("/", response_model=PermissionResponse)
async def create_permission(
    permission: PermissionCreate, 
    db: Session = Depends(get_db)
):
    """Create a new permission"""
    try:
        new_permission = permissions.create_permission(db, permission)
        return PermissionResponse(
            message=f"Permission '{new_permission.permission_name}' created successfully",
            permission=new_permission
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/", response_model=List[Permission])
async def read_permissions(
    skip: int = 0, 
    limit: int = 10, 
    db: Session = Depends(get_db)
):
    """Get all permissions with pagination"""
    return permissions.get_permissions(db, skip=skip, limit=limit)

@router.get("/{permission_id}", response_model=Permission)
async def read_permission(
    permission_id: int,  # Changed from UUID to int
    db: Session = Depends(get_db)
):
    """Get a specific permission by ID"""
    if permission := permissions.get_permission(db, permission_id):
        return permission
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="Permission not found"
    )

@router.put("/{permission_id}", response_model=PermissionResponse)
async def update_permission(
    permission_id: int,  # Changed from UUID to int
    permission: PermissionUpdate,
    db: Session = Depends(get_db)
):
    """Update a permission"""
    try:
        updated_permission = permissions.update_permission(db, permission_id, permission)
        return PermissionResponse(
            message=f"Permission '{updated_permission.permission_name}' updated successfully",
            permission=updated_permission
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.delete("/{permission_id}", response_model=PermissionResponse)
async def delete_permission(
    permission_id: int,  # Changed from UUID to int
    db: Session = Depends(get_db)
):
    """Delete a permission"""
    try:
        deleted_permission = permissions.delete_permission(db, permission_id)
        return PermissionResponse(
            message=f"Permission '{deleted_permission.permission_name}' deleted successfully",
            permission=deleted_permission
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
