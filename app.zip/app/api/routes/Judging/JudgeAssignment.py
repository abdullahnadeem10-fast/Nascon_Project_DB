from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import datetime

from api.deps import get_db, get_current_user
from core.security import oauth2_scheme
from core.permissions import require_permission
from crud.Judging import JudgeAssignment as judge_assignment_crud
from schemas.Judging.JudgeAssignment import (
    JudgeAssignmentCreate,
    JudgeAssignmentUpdate,
    JudgeAssignment,
    JudgeAssignmentResponse,
    JudgeAssignmentList,
    JudgeAssignmentDetail,
    JudgeAssignmentDetailList,
    JudgeStatus
)

router = APIRouter(prefix="/judge-assignments", tags=["judge_assignments"])

@router.post("/", response_model=JudgeAssignmentResponse)
def create_judge_assignment(
    assignment: JudgeAssignmentCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("manage_judges"))
):
    """
    Create a new judge assignment
    """
    db_assignment = judge_assignment_crud.create_judge_assignment(
        db=db, 
        assignment=assignment, 
        assigner_id=current_user.id
    )
    return JudgeAssignmentResponse(
        message="Judge assigned successfully",
        assignment=db_assignment
    )

@router.get("/", response_model=JudgeAssignmentDetailList)
def get_judge_assignments(
    skip: int = 0,
    limit: int = 100,
    user_id: Optional[int] = None,
    event_id: Optional[int] = None,
    schedule_id: Optional[int] = None,
    status: Optional[JudgeStatus] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get all judge assignments with pagination and filtering
    """
    # Build filters
    filters = {}
    if user_id:
        filters["user_id"] = user_id
    if event_id:
        filters["event_id"] = event_id
    if schedule_id:
        filters["schedule_id"] = schedule_id
    if status:
        filters["status"] = status
    
    # Get assignments with details
    assignments, total = judge_assignment_crud.get_judge_assignments_with_details(
        db=db, 
        skip=skip, 
        limit=limit, 
        filters=filters
    )
    
    return JudgeAssignmentDetailList(
        assignments=assignments,
        total=total
    )

@router.get("/my-assignments", response_model=JudgeAssignmentDetailList)
def get_my_assignments(
    skip: int = 0,
    limit: int = 100,
    status: Optional[JudgeStatus] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get current user's judge assignments
    """
    # Build filters
    filters = {"user_id": current_user.id}
    if status:
        filters["status"] = status
    
    # Get assignments with details
    assignments, total = judge_assignment_crud.get_judge_assignments_with_details(
        db=db, 
        skip=skip, 
        limit=limit, 
        filters=filters
    )
    
    return JudgeAssignmentDetailList(
        assignments=assignments,
        total=total
    )

@router.get("/{assignment_id}", response_model=JudgeAssignment)
def get_judge_assignment(
    assignment_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get a judge assignment by ID
    """
    assignment = judge_assignment_crud.get_judge_assignment(db=db, assignment_id=assignment_id)
    
    # Check if user has permission to view this assignment
    if assignment.user_id != current_user.id and not current_user.has_permission("manage_judges"):
        raise HTTPException(status_code=403, detail="Not authorized to access this judge assignment")
    
    return assignment

@router.put("/{assignment_id}", response_model=JudgeAssignmentResponse)
def update_judge_assignment(
    assignment_id: int,
    assignment: JudgeAssignmentUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("manage_judges"))
):
    """
    Update a judge assignment
    """
    updated_assignment = judge_assignment_crud.update_judge_assignment(
        db=db, 
        assignment_id=assignment_id, 
        assignment=assignment
    )
    
    return JudgeAssignmentResponse(
        message="Judge assignment updated successfully",
        assignment=updated_assignment
    )

@router.post("/{assignment_id}/complete", response_model=JudgeAssignmentResponse)
def complete_assignment(
    assignment_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Mark a judge assignment as completed
    """
    # Get the assignment
    assignment = judge_assignment_crud.get_judge_assignment(db=db, assignment_id=assignment_id)
    
    # Check if user is the assigned judge or has manage_judges permission
    if assignment.user_id != current_user.id and not current_user.has_permission("manage_judges"):
        raise HTTPException(status_code=403, detail="Not authorized to update this judge assignment")
    
    # Update the assignment status
    update_data = JudgeAssignmentUpdate(status=JudgeStatus.COMPLETED)
    updated_assignment = judge_assignment_crud.update_judge_assignment(
        db=db, 
        assignment_id=assignment_id, 
        assignment=update_data
    )
    
    return JudgeAssignmentResponse(
        message="Judge assignment marked as completed",
        assignment=updated_assignment
    )

@router.delete("/{assignment_id}", response_model=JudgeAssignmentResponse)
def delete_judge_assignment(
    assignment_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_judges"))
):
    """
    Delete a judge assignment
    """
    deleted_assignment = judge_assignment_crud.delete_judge_assignment(db=db, assignment_id=assignment_id)
    
    return JudgeAssignmentResponse(
        message="Judge assignment deleted successfully",
        assignment=deleted_assignment
    )
