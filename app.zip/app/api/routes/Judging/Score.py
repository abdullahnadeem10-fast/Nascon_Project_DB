from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List
from decimal import Decimal

from api.deps import get_db, get_current_user
from core.security import oauth2_scheme
from core.permissions import require_permission
from crud.Judging import Score as score_crud
from schemas.Judging.Score import (
    ScoreCreate,
    ScoreUpdate,
    Score,
    ScoreResponse,
    ScoreList,
    ScoreDetail,
    ScoreDetailList,
    BatchScoreCreate,
    BatchScoreResponse,
    ParticipantScoreSummary,
    ParticipantScoreSummaryList
)

router = APIRouter(prefix="/scores", tags=["scores"])

@router.post("/", response_model=ScoreResponse)
def create_score(
    score: ScoreCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Create a new score
    """
    # Check if the current user is the judge or has manage_judges permission
    if score.judge_id != current_user.id and not current_user.has_permission("manage_judges"):
        raise HTTPException(status_code=403, detail="Not authorized to submit scores for other judges")
    
    db_score = score_crud.create_score(db=db, score=score)
    return ScoreResponse(
        message="Score submitted successfully",
        score=db_score
    )

@router.post("/batch", response_model=BatchScoreResponse)
def batch_create_scores(
    batch: BatchScoreCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Create multiple scores in a batch
    """
    db_scores = score_crud.batch_create_scores(db=db, batch=batch, judge_id=current_user.id)
    return BatchScoreResponse(
        message="Scores submitted successfully",
        scores=db_scores
    )

@router.get("/", response_model=ScoreDetailList)
def get_scores(
    skip: int = 0,
    limit: int = 100,
    judge_id: Optional[int] = None,
    registration_id: Optional[int] = None,
    criteria_id: Optional[int] = None,
    schedule_id: Optional[int] = None,
    event_id: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get all scores with pagination and filtering
    """
    # Build filters
    filters = {}
    if judge_id:
        filters["judge_id"] = judge_id
    if registration_id:
        filters["registration_id"] = registration_id
    if criteria_id:
        filters["criteria_id"] = criteria_id
    if schedule_id:
        filters["schedule_id"] = schedule_id
    if event_id:
        filters["event_id"] = event_id
    
    # Get scores with details
    scores, total = score_crud.get_scores_with_details(
        db=db, 
        skip=skip, 
        limit=limit, 
        filters=filters
    )
    
    return ScoreDetailList(
        scores=scores,
        total=total
    )

@router.get("/my", response_model=ScoreDetailList)
def get_my_scores(
    skip: int = 0,
    limit: int = 100,
    registration_id: Optional[int] = None,
    criteria_id: Optional[int] = None,
    schedule_id: Optional[int] = None,
    event_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get current user's submitted scores
    """
    # Build filters
    filters = {"judge_id": current_user.id}
    if registration_id:
        filters["registration_id"] = registration_id
    if criteria_id:
        filters["criteria_id"] = criteria_id
    if schedule_id:
        filters["schedule_id"] = schedule_id
    if event_id:
        filters["event_id"] = event_id
    
    # Get scores with details
    scores, total = score_crud.get_scores_with_details(
        db=db, 
        skip=skip, 
        limit=limit, 
        filters=filters
    )
    
    return ScoreDetailList(
        scores=scores,
        total=total
    )

@router.get("/event/{event_id}/summary", response_model=ParticipantScoreSummaryList)
def get_event_score_summary(
    event_id: int,
    schedule_id: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get score summaries for all participants in an event
    """
    summaries = score_crud.get_participant_score_summaries(
        db=db, 
        event_id=event_id,
        schedule_id=schedule_id
    )
    
    return ParticipantScoreSummaryList(
        summaries=summaries,
        total=len(summaries)
    )

@router.get("/{score_id}", response_model=Score)
def get_score(
    score_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get a score by ID
    """
    score = score_crud.get_score(db=db, score_id=score_id)
    
    # Check if user has permission to view this score
    if score.judge_id != current_user.id and not current_user.has_permission("manage_judges"):
        raise HTTPException(status_code=403, detail="Not authorized to access this score")
    
    return score

@router.put("/{score_id}", response_model=ScoreResponse)
def update_score(
    score_id: int,
    score: ScoreUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Update a score
    """
    # Get the score
    db_score = score_crud.get_score(db=db, score_id=score_id)
    
    # Check if user has permission to update this score
    if db_score.judge_id != current_user.id and not current_user.has_permission("manage_judges"):
        raise HTTPException(status_code=403, detail="Not authorized to update this score")
    
    # Update the score
    updated_score = score_crud.update_score(db=db, score_id=score_id, score=score)
    
    return ScoreResponse(
        message="Score updated successfully",
        score=updated_score
    )

@router.delete("/{score_id}", response_model=ScoreResponse)
def delete_score(
    score_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Delete a score
    """
    # Get the score
    db_score = score_crud.get_score(db=db, score_id=score_id)
    
    # Check if user has permission to delete this score
    if db_score.judge_id != current_user.id and not current_user.has_permission("manage_judges"):
        raise HTTPException(status_code=403, detail="Not authorized to delete this score")
    
    # Delete the score
    deleted_score = score_crud.delete_score(db=db, score_id=score_id)
    
    return ScoreResponse(
        message="Score deleted successfully",
        score=deleted_score
    )
