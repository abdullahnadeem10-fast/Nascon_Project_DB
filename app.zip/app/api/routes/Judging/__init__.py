# Import routers
from .JudgeAssignment import router as judge_assignment_router
from .EvaluationCriteria import router as evaluation_criteria_router
from .Score import router as score_router
from .Winner import router as winner_router
