from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List
from decimal import Decimal

from api.deps import get_db, get_current_user
from core.security import oauth2_scheme
from core.permissions import require_permission
from crud.Judging import EvaluationCriteria as criteria_crud
from schemas.Judging.EvaluationCriteria import (
    EvaluationCriteriaCreate,
    EvaluationCriteriaUpdate,
    EvaluationCriteria,
    EvaluationCriteriaResponse,
    EvaluationCriteriaList,
    EvaluationCriteriaWithEvent,
    EvaluationCriteriaWithEventList
)

router = APIRouter(prefix="/evaluation-criteria", tags=["evaluation_criteria"])

@router.post("/", response_model=EvaluationCriteriaResponse)
def create_evaluation_criteria(
    criteria: EvaluationCriteriaCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_events"))
):
    """
    Create a new evaluation criteria
    """
    db_criteria = criteria_crud.create_evaluation_criteria(db=db, criteria=criteria)
    return EvaluationCriteriaResponse(
        message="Evaluation criteria created successfully",
        criteria=db_criteria
    )

@router.get("/", response_model=EvaluationCriteriaWithEventList)
def get_evaluation_criteria(
    skip: int = 0,
    limit: int = 100,
    event_id: Optional[int] = None,
    criteria_name: Optional[str] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get all evaluation criteria with pagination and filtering
    """
    # Build filters
    filters = {}
    if event_id:
        filters["event_id"] = event_id
    if criteria_name:
        filters["criteria_name"] = criteria_name
    
    # Get criteria with event details
    criteria_list, total = criteria_crud.get_evaluation_criteria_with_event(
        db=db, 
        skip=skip, 
        limit=limit, 
        filters=filters
    )
    
    return EvaluationCriteriaWithEventList(
        criteria=criteria_list,
        total=total
    )

@router.get("/event/{event_id}", response_model=EvaluationCriteriaList)
def get_criteria_by_event(
    event_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get all evaluation criteria for a specific event
    """
    criteria = criteria_crud.get_evaluation_criteria_by_event(db=db, event_id=event_id)
    return EvaluationCriteriaList(
        criteria=criteria,
        total=len(criteria)
    )

@router.get("/{criteria_id}", response_model=EvaluationCriteria)
def get_evaluation_criteria_by_id(
    criteria_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get an evaluation criteria by ID
    """
    return criteria_crud.get_evaluation_criteria(db=db, criteria_id=criteria_id)

@router.put("/{criteria_id}", response_model=EvaluationCriteriaResponse)
def update_evaluation_criteria(
    criteria_id: int,
    criteria: EvaluationCriteriaUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_events"))
):
    """
    Update an evaluation criteria
    """
    updated_criteria = criteria_crud.update_evaluation_criteria(
        db=db, 
        criteria_id=criteria_id, 
        criteria=criteria
    )
    
    return EvaluationCriteriaResponse(
        message="Evaluation criteria updated successfully",
        criteria=updated_criteria
    )

@router.delete("/{criteria_id}", response_model=EvaluationCriteriaResponse)
def delete_evaluation_criteria(
    criteria_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_events"))
):
    """
    Delete an evaluation criteria
    """
    deleted_criteria = criteria_crud.delete_evaluation_criteria(db=db, criteria_id=criteria_id)
    
    return EvaluationCriteriaResponse(
        message="Evaluation criteria deleted successfully",
        criteria=deleted_criteria
    )
