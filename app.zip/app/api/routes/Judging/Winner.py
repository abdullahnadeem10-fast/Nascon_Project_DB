from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List

from api.deps import get_db, get_current_user
from core.security import oauth2_scheme
from core.permissions import require_permission
from crud.Judging import Winner as winner_crud
from schemas.Judging.Winner import (
    WinnerCreate,
    WinnerUpdate,
    Winner,
    WinnerResponse,
    WinnerList,
    WinnerDetail,
    WinnerDetailList,
    BatchWinnerCreate
)

router = APIRouter(prefix="/winners", tags=["winners"])

@router.post("/", response_model=WinnerResponse)
def create_winner(
    winner: WinnerCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("manage_events"))
):
    """
    Create a new winner
    """
    db_winner = winner_crud.create_winner(db=db, winner=winner, declarer_id=current_user.id)
    return WinnerResponse(
        message="Winner declared successfully",
        winner=db_winner
    )

@router.post("/batch", response_model=WinnerList)
def batch_create_winners(
    batch: BatchWinnerCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("manage_events"))
):
    """
    Create multiple winners in a batch
    """
    db_winners = winner_crud.batch_create_winners(db=db, batch=batch, declarer_id=current_user.id)
    return WinnerList(
        message="Winners declared successfully",
        winners=db_winners,
        total=len(db_winners)
    )

@router.get("/", response_model=WinnerDetailList)
def get_winners(
    skip: int = 0,
    limit: int = 100,
    event_id: Optional[int] = None,
    registration_id: Optional[int] = None,
    position: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get all winners with pagination and filtering
    """
    # Build filters
    filters = {}
    if event_id:
        filters["event_id"] = event_id
    if registration_id:
        filters["registration_id"] = registration_id
    if position:
        filters["position"] = position
    
    # Get winners with details
    winners, total = winner_crud.get_winners_with_details(
        db=db, 
        skip=skip, 
        limit=limit, 
        filters=filters
    )
    
    return WinnerDetailList(
        winners=winners,
        total=total
    )

@router.get("/event/{event_id}", response_model=WinnerDetailList)
def get_winners_by_event(
    event_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get all winners for a specific event
    """
    winners, total = winner_crud.get_winners_with_details(
        db=db, 
        filters={"event_id": event_id}
    )
    
    return WinnerDetailList(
        winners=winners,
        total=total
    )

@router.get("/{winner_id}", response_model=Winner)
def get_winner(
    winner_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme)
):
    """
    Get a winner by ID
    """
    return winner_crud.get_winner(db=db, winner_id=winner_id)

@router.put("/{winner_id}", response_model=WinnerResponse)
def update_winner(
    winner_id: int,
    winner: WinnerUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_events"))
):
    """
    Update a winner
    """
    updated_winner = winner_crud.update_winner(
        db=db, 
        winner_id=winner_id, 
        winner=winner
    )
    
    return WinnerResponse(
        message="Winner updated successfully",
        winner=updated_winner
    )

@router.delete("/{winner_id}", response_model=WinnerResponse)
def delete_winner(
    winner_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_events"))
):
    """
    Delete a winner
    """
    deleted_winner = winner_crud.delete_winner(db=db, winner_id=winner_id)
    
    return WinnerResponse(
        message="Winner deleted successfully",
        winner=deleted_winner
    )
