from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Events.EventRegistration import (
    create_event_registration,
    get_event_registration,
    get_event_registration_with_details,
    get_event_registration_by_confirmation_code,
    get_event_registrations,
    get_event_registrations_with_details,
    get_event_registrations_with_names,
    update_event_registration,
    update_payment_status,
    delete_event_registration
)
from schemas.Events.EventRegistration import (
    EventRegistrationCreate,
    EventRegistrationResponse,
    EventRegistrationUpdate,
    EventRegistration,
    EventRegistrationList,
    EventRegistrationDetail,
    EventRegistrationWithNames,
    EventRegistrationWithNamesList,
    PaymentStatus
)
from schemas.rbac.user import User

router = APIRouter(prefix="/event-registrations", tags=["event_registrations"])

@router.post("/", response_model=EventRegistrationResponse)
def register_for_event(
    registration: EventRegistrationCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("register_for_event")),
    token: str = Depends(oauth2_scheme)
):
    """Register for an event (as an individual or team)"""
    user = get_current_user(token,db)


    # Always use the current authenticated user's ID from the token
    if registration.team_id is None:
        # For individual registrations, always use the current user's ID
        registration.user_id = user.id

    # For team registrations, we don't need to set user_id as it will be handled by the team
    # But we need to ensure the current user is a member of the team
    if registration.team_id is not None:
        from models.events import TeamMember
        # Check if current user is a member of the team
        team_member = db.query(TeamMember).filter(
            TeamMember.team_id == registration.team_id,
            TeamMember.user_id == user.id
        ).first()

        if not team_member:
            raise HTTPException(
                status_code=403,
                detail="You must be a member of the team to register it for an event"
            )

        # If the user is not a team lead, check if they have permission to register the team
        if not team_member.is_team_lead:
            # Check if user has admin permissions to register teams they don't lead
            _=Depends(require_permission("register_any_team"))

    db_registration = create_event_registration(db, registration)
    return EventRegistrationResponse(
        message="Registration successful",
        registration=db_registration
    )

@router.get("/", response_model=EventRegistrationWithNamesList)
def get_all_registrations(
    skip: int = 0,
    limit: int = 100,
    event_id: Optional[int] = None,
    user_id: Optional[int] = None,
    team_id: Optional[int] = None,
    payment_status: Optional[PaymentStatus] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_registrations"))
):
    """
    Get all event registrations with pagination and optional filtering

    Returns registrations with event names and team names instead of just IDs
    """
    filters = {
        "event_id": event_id,
        "user_id": user_id,
        "team_id": team_id,
        "payment_status": payment_status.value if payment_status else None
    }
    registrations, total = get_event_registrations_with_names(db, skip=skip, limit=limit, filters=filters)
    return EventRegistrationWithNamesList(
        registrations=registrations,
        total=total
    )

@router.get("/my-registrations", response_model=EventRegistrationWithNamesList)
def get_my_registrations(
    skip: int = 0,
    limit: int = 100,
    event_id: Optional[int] = None,
    payment_status: Optional[PaymentStatus] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get all registrations for the current user (based on token)

    Returns registrations with event names and team names instead of just IDs
    """
    # Use the current user's ID from the token
    user_id = current_user.id

    # Get individual registrations
    filters = {
        "event_id": event_id,
        "user_id": user_id,
        "payment_status": payment_status.value if payment_status else None
    }
    individual_registrations, individual_total = get_event_registrations_with_names(db, skip=skip, limit=limit, filters=filters)

    # Also get team registrations where the user is a member
    from models.events import TeamMember

    # Get all teams where the user is a member
    user_teams = db.query(TeamMember.team_id).filter(TeamMember.user_id == user_id).all()
    team_ids = [team.team_id for team in user_teams]

    # If user is part of any teams, get those team registrations too
    team_registrations = []
    team_total = 0
    if team_ids:
        team_filters = {
            "event_id": event_id,
            "team_id": team_ids,  # This will be handled specially in the query
            "payment_status": payment_status.value if payment_status else None
        }
        team_registrations, team_total = get_event_registrations_with_names(db, skip=0, limit=1000, filters=team_filters)

    # Combine individual and team registrations
    all_registrations = individual_registrations + team_registrations
    total = individual_total + team_total

    return EventRegistrationWithNamesList(
        registrations=all_registrations,
        total=total
    )

@router.get("/event/{event_id}", response_model=List[EventRegistrationDetail])
def get_registrations_by_event(
    event_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_registrations"))
):
    """Get all registrations for a specific event with user/team details"""
    registrations, _ = get_event_registrations_with_details(db, event_id, skip=skip, limit=limit)
    return registrations

@router.get("/{registration_id}", response_model=EventRegistration)
def get_registration(
    registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific registration by ID"""
    registration = get_event_registration(db, registration_id)

    # Check if user is authorized to view this registration
    is_authorized = False

    # User can view their own individual registrations
    if registration.user_id == current_user.id:
        is_authorized = True

    # User can view team registrations if they are a member of the team
    if registration.team_id is not None:
        from models.events import TeamMember
        team_member = db.query(TeamMember).filter(
            TeamMember.team_id == registration.team_id,
            TeamMember.user_id == current_user.id
        ).first()
        if team_member:
            is_authorized = True

    # If not authorized, check if user has admin permissions
    if not is_authorized:
        _=Depends(require_permission("view_registrations"))

    return registration

@router.get("/{registration_id}/details", response_model=EventRegistrationDetail)
def get_registration_details(
    registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific registration by ID with related details"""
    registration = get_event_registration_with_details(db, registration_id)

    # Check if user is authorized to view this registration
    is_authorized = False

    # User can view their own individual registrations
    if registration.user_id == current_user.id:
        is_authorized = True

    # User can view team registrations if they are a member of the team
    if registration.team_id is not None:
        from models.events import TeamMember
        team_member = db.query(TeamMember).filter(
            TeamMember.team_id == registration.team_id,
            TeamMember.user_id == current_user.id
        ).first()
        if team_member:
            is_authorized = True

    # If not authorized, check if user has admin permissions
    if not is_authorized:
        _=Depends(require_permission("view_registrations"))

    # Create response with event, user, and team details
    return EventRegistrationDetail(
        id=registration.id,
        event_id=registration.event_id,
        user_id=registration.user_id,
        team_id=registration.team_id,
        payment_status=registration.payment_status,
        confirmation_code=registration.confirmation_code,
        registration_date=registration.registration_date,
        event_name=registration.event.event_name,
        user_name=registration.participant.username if registration.participant else None,
        team_name=registration.team.team_name if registration.team else None
    )

@router.get("/confirmation/{confirmation_code}", response_model=EventRegistrationDetail)
def get_registration_by_confirmation_code(
    confirmation_code: str,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_registrations"))
):
    """Get a registration by confirmation code"""
    registration = get_event_registration_by_confirmation_code(db, confirmation_code)

    # Create response with event, user, and team details
    return EventRegistrationDetail(
        id=registration.id,
        event_id=registration.event_id,
        user_id=registration.user_id,
        team_id=registration.team_id,
        payment_status=registration.payment_status,
        confirmation_code=registration.confirmation_code,
        registration_date=registration.registration_date,
        event_name=registration.event.event_name,
        user_name=registration.participant.username if registration.participant else None,
        team_name=registration.team.team_name if registration.team else None
    )

@router.put("/{registration_id}", response_model=EventRegistrationResponse)
def update_registration(
    registration_id: int,
    registration: EventRegistrationUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_registrations"))
):
    """Update a registration (admin only)"""
    db_registration = update_event_registration(db, registration_id, registration)
    return EventRegistrationResponse(
        message="Registration updated successfully",
        registration=db_registration
    )

@router.post("/{registration_id}/payment/{status}", response_model=EventRegistrationResponse)
def update_registration_payment_status(
    registration_id: int,
    status: PaymentStatus,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_payments"))
):
    """Update the payment status of a registration"""
    db_registration = update_payment_status(db, registration_id, status.value)

    message = "Payment status updated to Pending"
    if status == PaymentStatus.PAID:
        message = "Payment confirmed successfully"
    elif status == PaymentStatus.CANCELLED:
        message = "Payment cancelled"

    return EventRegistrationResponse(
        message=message,
        registration=db_registration
    )

@router.delete("/{registration_id}", response_model=EventRegistrationResponse)
def cancel_registration(
    registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Cancel a registration"""
    registration = get_event_registration(db, registration_id)

    # Check if user is authorized to cancel this registration
    is_authorized = False

    # User can cancel their own individual registrations
    if registration.user_id == current_user.id:
        is_authorized = True

    # User can cancel team registrations if they are the team lead
    if registration.team_id is not None:
        from models.events import TeamMember
        team_member = db.query(TeamMember).filter(
            TeamMember.team_id == registration.team_id,
            TeamMember.user_id == current_user.id,
            TeamMember.is_team_lead == True
        ).first()
        if team_member:
            is_authorized = True

    # If not authorized, check if user has admin permissions
    if not is_authorized:
        _=Depends(require_permission("manage_registrations"))

    deleted_registration = delete_event_registration(db, registration_id)
    return EventRegistrationResponse(
        message="Registration cancelled successfully",
        registration=deleted_registration
    )
