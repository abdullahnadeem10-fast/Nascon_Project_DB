from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Events.TeamMember import (
    create_team_member,
    get_team_member,
    get_team_member_with_user,
    get_team_members,
    get_team_members_with_users,
    update_team_member,
    delete_team_member,
    make_team_lead
)
from crud.Events.Team import get_team
from schemas.Events.TeamMember import (
    TeamMemberCreate,
    TeamMemberResponse,
    TeamMemberUpdate,
    TeamMember,
    TeamMemberList,
    TeamMemberWithUser
)
from schemas.rbac.user import User

router = APIRouter(prefix="/team-members", tags=["team_members"])

@router.post("/", response_model=TeamMemberResponse)
def add_team_member(
    member: TeamMemberCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_team_members"))
):
    """Add a member to a team"""
    # Check if user is the team creator or has admin permissions
    team = get_team(db, member.team_id)
    if team.created_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        pass
    
    db_member = create_team_member(db, member)
    return TeamMemberResponse(
        message="Member added to team successfully",
        member=db_member
    )

@router.get("/", response_model=TeamMemberList)
def get_all_team_members(
    skip: int = 0,
    limit: int = 100,
    team_id: Optional[int] = None,
    user_id: Optional[int] = None,
    is_team_lead: Optional[bool] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team_members"))
):
    """Get all team members with pagination and optional filtering"""
    filters = {
        "team_id": team_id,
        "user_id": user_id,
        "is_team_lead": is_team_lead
    }
    members, total = get_team_members(db, skip=skip, limit=limit, filters=filters)
    return TeamMemberList(
        members=members,
        total=total
    )

@router.get("/team/{team_id}", response_model=TeamMemberList)
def get_members_by_team(
    team_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team_members"))
):
    """Get all members of a specific team"""
    members, total = get_team_members(db, skip=skip, limit=limit, filters={"team_id": team_id})
    return TeamMemberList(
        members=members,
        total=total
    )

@router.get("/team/{team_id}/with-users", response_model=List[TeamMemberWithUser])
def get_members_with_users(
    team_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team_members"))
):
    """Get all members of a specific team with user details"""
    members, _ = get_team_members_with_users(db, team_id, skip=skip, limit=limit)
    
    # Create response with user details
    result = []
    for member in members:
        result.append(TeamMemberWithUser(
            id=member.id,
            team_id=member.team_id,
            user_id=member.user_id,
            is_team_lead=member.is_team_lead,
            joined_at=member.joined_at,
            username=member.user.username,
            first_name=member.user.first_name,
            last_name=member.user.last_name
        ))
    
    return result

@router.get("/user/{user_id}", response_model=TeamMemberList)
def get_members_by_user(
    user_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team_members"))
):
    """Get all team memberships for a specific user"""
    members, total = get_team_members(db, skip=skip, limit=limit, filters={"user_id": user_id})
    return TeamMemberList(
        members=members,
        total=total
    )

@router.get("/{member_id}", response_model=TeamMember)
def get_member(
    member_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team_member"))
):
    """Get a specific team member by ID"""
    return get_team_member(db, member_id)

@router.get("/{member_id}/with-user", response_model=TeamMemberWithUser)
def get_member_with_user(
    member_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team_member"))
):
    """Get a specific team member by ID with user details"""
    member = get_team_member_with_user(db, member_id)
    
    # Create response with user details
    return TeamMemberWithUser(
        id=member.id,
        team_id=member.team_id,
        user_id=member.user_id,
        is_team_lead=member.is_team_lead,
        joined_at=member.joined_at,
        username=member.user.username,
        first_name=member.user.first_name,
        last_name=member.user.last_name
    )

@router.put("/{member_id}", response_model=TeamMemberResponse)
def update_member(
    member_id: int,
    member: TeamMemberUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_team_members"))
):
    """Update a team member"""
    # Get the team member to check permissions
    db_member = get_team_member(db, member_id)
    
    # Get the team to check if current user is the team creator
    team = get_team(db, db_member.team_id)
    if team.created_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        pass
    
    db_member = update_team_member(db, member_id, member)
    return TeamMemberResponse(
        message="Team member updated successfully",
        member=db_member
    )

@router.post("/{member_id}/make-lead", response_model=TeamMemberResponse)
def make_member_team_lead(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_team_members"))
):
    """Make a team member the team lead"""
    # Get the team member to check permissions
    db_member = get_team_member(db, member_id)
    
    # Get the team to check if current user is the team creator
    team = get_team(db, db_member.team_id)
    if team.created_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        pass
    
    db_member = make_team_lead(db, member_id)
    return TeamMemberResponse(
        message="Team member is now a team lead",
        member=db_member
    )

@router.delete("/{member_id}", response_model=TeamMemberResponse)
def remove_member(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("manage_team_members"))
):
    """Remove a member from a team"""
    # Get the team member to check permissions
    db_member = get_team_member(db, member_id)
    
    # Get the team to check if current user is the team creator
    team = get_team(db, db_member.team_id)
    if team.created_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        pass
    
    deleted_member = delete_team_member(db, member_id)
    return TeamMemberResponse(
        message="Team member removed successfully",
        member=deleted_member
    )
