from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Events.Venue import (
    create_venue,
    get_venue,
    get_venue_with_schedules,
    get_venues,
    update_venue,
    delete_venue
)
from schemas.Events.Venue import (
    VenueCreate,
    VenueResponse,
    VenueUpdate,
    Venue,
    VenueList,
    VenueType
)
from schemas.rbac.user import User

router = APIRouter(prefix="/venues", tags=["venues"])

@router.post("/", response_model=VenueResponse)
def create_venue_endpoint(
    venue: VenueCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("create_venue")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new venue"""
    db_venue = create_venue(db, venue)
    return VenueResponse(
        message="Venue created successfully",
        venue=db_venue
    )

@router.get("/", response_model=VenueList)
def get_venues_endpoint(
    skip: int = 0,
    limit: int = 100,
    venue_type: Optional[VenueType] = None,
    min_capacity: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_venues"))
):
    """Get all venues with pagination and optional filtering"""
    filters = {
        "venue_type": venue_type.value if venue_type else None,
        "min_capacity": min_capacity
    }
    venues, total = get_venues(db, skip=skip, limit=limit, filters=filters)
    return VenueList(
        venues=venues,
        total=total
    )

@router.get("/{venue_id}", response_model=Venue)
def get_venue_endpoint(
    venue_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_venue"))
):
    """Get a specific venue by ID"""
    return get_venue(db, venue_id)

@router.get("/{venue_id}/schedules", response_model=Venue)
def get_venue_with_schedules_endpoint(
    venue_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_venue"))
):
    """Get a specific venue by ID with all related schedules"""
    return get_venue_with_schedules(db, venue_id)

@router.put("/{venue_id}", response_model=VenueResponse)
def update_venue_endpoint(
    venue_id: int,
    venue: VenueUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("update_venue")),
    token: str = Depends(oauth2_scheme)
):
    """Update a venue"""
    db_venue = update_venue(db, venue_id, venue)
    return VenueResponse(
        message="Venue updated successfully",
        venue=db_venue
    )

@router.delete("/{venue_id}", response_model=VenueResponse)
def delete_venue_endpoint(
    venue_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("delete_venue"))
):
    """Delete a venue"""
    deleted_venue = delete_venue(db, venue_id)
    return VenueResponse(
        message="Venue deleted successfully",
        venue=deleted_venue
    )
