from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from api.deps import get_db
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Events.EventCategory import (
    create_event_category,
    get_event_category,
    get_event_categories,
    update_event_category,
    delete_event_category
)
from schemas.Events.EventCategory import (
    EventCategoryCreate,
    EventCategoryResponse,
    EventCategoryUpdate,
    EventCategory
)

router = APIRouter(prefix="/event-categories", tags=["event_categories"])

@router.post("/", response_model=EventCategoryResponse)
def create_category(
    category: EventCategoryCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("create_event_category")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new event category"""
    db_category = create_event_category(db, category)
    return EventCategoryResponse(
        message="Event category created successfully",
        category=db_category
    )

@router.get("/", response_model=List[EventCategory])
def get_categories(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event_categories"))
):
    """Get all event categories with pagination"""
    return get_event_categories(db, skip=skip, limit=limit)

@router.get("/{category_id}", response_model=EventCategory)
def get_category(
    category_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event_category"))
):
    """Get a specific event category by ID"""
    return get_event_category(db, category_id)

@router.put("/{category_id}", response_model=EventCategoryResponse)
def update_category(
    category_id: int,
    category: EventCategoryUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("update_event_category")),
    token: str = Depends(oauth2_scheme)
):
    """Update an event category"""
    db_category = update_event_category(db, category_id, category)
    return EventCategoryResponse(
        message="Event category updated successfully",
        category=db_category
    )

@router.delete("/{category_id}", response_model=EventCategoryResponse)
def delete_category(
    category_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("delete_event_category"))
):
    """Delete an event category and all associated events and teams"""
    deleted_category = delete_event_category(db, category_id)
    return EventCategoryResponse(
        message="Event category and all associated events and teams deleted successfully",
        category=deleted_category
    )