from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Events.Team import (
    create_team,
    get_team,
    get_team_with_members,
    get_teams,
    update_team,
    delete_team
)
from schemas.Events.Team import (
    TeamCreate,
    TeamResponse,
    TeamUpdate,
    Team,
    TeamList,
    TeamWithMembers
)
from schemas.rbac.user import User

router = APIRouter(prefix="/teams", tags=["teams"])

# Team endpoints

@router.post("/", response_model=TeamResponse)
def create_team_endpoint(
    team: TeamCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """Create a new team"""
    db_team = create_team(db, team, current_user.id)
    return TeamResponse(
        message="Team created successfully",
        team=db_team
    )

@router.get("/", response_model=TeamList)
def get_teams_endpoint(
    skip: int = 0,
    limit: int = 100,
    event_id: Optional[int] = None,
    created_by: Optional[int] = None,
    user_id: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_teams"))
):
    """Get all teams with pagination and optional filtering"""
    filters = {
        "event_id": event_id,
        "created_by": created_by,
        "user_id": user_id
    }
    teams, total = get_teams(db, skip=skip, limit=limit, filters=filters)
    return TeamList(
        teams=teams,
        total=total
    )

@router.get("/my-teams", response_model=TeamList)
def get_my_teams_endpoint(
    skip: int = 0,
    limit: int = 100,
    event_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get teams created by or where the current user is a member"""
    filters = {
        "event_id": event_id,
        "user_id": current_user.id
    }
    teams, total = get_teams(db, skip=skip, limit=limit, filters=filters)
    return TeamList(
        teams=teams,
        total=total
    )

@router.get("/{team_id}", response_model=Team)
def get_team_endpoint(
    team_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team"))
):
    """Get a specific team by ID"""
    return get_team(db, team_id)

@router.get("/{team_id}/members", response_model=TeamWithMembers)
def get_team_with_members_endpoint(
    team_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_team"))
):
    """Get a specific team by ID with all members"""
    return get_team_with_members(db, team_id)

@router.put("/{team_id}", response_model=TeamResponse)
def update_team_endpoint(
    team_id: int,
    team: TeamUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("update_team")),
    token: str = Depends(oauth2_scheme)
):
    """Update a team"""
    # Check if user is the team creator or has admin permissions
    db_team = get_team(db, team_id)
    if db_team.created_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        pass

    db_team = update_team(db, team_id, team)
    return TeamResponse(
        message="Team updated successfully",
        team=db_team
    )

@router.delete("/{team_id}", response_model=TeamResponse)
def delete_team_endpoint(
    team_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("delete_team"))
):
    """Delete a team"""
    # Get the team with its members
    db_team = get_team_with_members(db, team_id)

    # Check if user is the team creator
    if db_team.created_by != current_user.id:
        # Check if user is a team lead for this team
        is_team_lead = False
        for member in db_team.members:
            if member.user_id == current_user.id and member.is_team_lead:
                is_team_lead = True
                break

        if not is_team_lead:
            raise HTTPException(
                status_code=403,
                detail="Only the team creator or team lead can delete the team"
            )

    deleted_team = delete_team(db, team_id)
    return TeamResponse(
        message="Team deleted successfully",
        team=deleted_team
    )


