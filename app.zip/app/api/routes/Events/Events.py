from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Tuple

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from crud.Events.Events import (
    create_event,
    get_event,
    get_event_with_details,
    get_events,
    update_event,
    delete_event,
    get_unscheduled_events
)
from schemas.Events.Events import (
    EventCreate,
    EventResponse,
    EventUpdate,
    Event,
    EventList
)
from schemas.rbac.user import User

router = APIRouter(prefix="/events", tags=["events"])

@router.post("/", response_model=EventResponse)
def create_event_endpoint(
    event: EventCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_event"))
):
    """Create a new event"""
    db_event = create_event(db, event, current_user.id)
    return EventResponse(
        message="Event created successfully",
        event=db_event
    )

@router.get("/", response_model=EventList)
def get_events_endpoint(
    skip: int = 0,
    limit: int = 100,
    category_id: Optional[int] = None,
    is_team_event: Optional[bool] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_events"))
):
    """Get all events with pagination and optional filtering"""
    filters = {
        "category_id": category_id,
        "is_team_event": is_team_event
    }
    events, total = get_events(db, skip=skip, limit=limit, filters=filters)
    return EventList(
        events=events,
        total=total
    )

@router.get("/public", response_model=EventList)
def get_public_events_endpoint(
    skip: int = 0,
    limit: int = 100,
    category_id: Optional[int] = None,
    is_team_event: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    """
    Get all events without requiring authentication or permissions

    This endpoint is publicly accessible and does not require a token.

    Optional query parameters:
    - skip: Number of records to skip (for pagination)
    - limit: Maximum number of records to return (for pagination)
    - category_id: Filter by category ID
    - is_team_event: Filter by whether the event is a team event
    """
    filters = {
        "category_id": category_id,
        "is_team_event": is_team_event
    }
    events, total = get_events(db, skip=skip, limit=limit, filters=filters)
    return EventList(
        events=events,
        total=total
    )

@router.get("/public/unscheduled", response_model=EventList)
def get_public_unscheduled_events_endpoint(
    skip: int = 0,
    limit: int = 100,
    category_id: Optional[int] = None,
    is_team_event: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    """
    Get all unscheduled events without requiring authentication or permissions

    This endpoint is publicly accessible and does not require a token.

    Optional query parameters:
    - skip: Number of records to skip (for pagination)
    - limit: Maximum number of records to return (for pagination)
    - category_id: Filter by category ID
    - is_team_event: Filter by whether the event is a team event
    """
    filters = {
        "category_id": category_id,
        "is_team_event": is_team_event
    }
    events, total = get_unscheduled_events(db, skip=skip, limit=limit, filters=filters)
    return EventList(
        events=events,
        total=total
    )

@router.get("/unscheduled", response_model=EventList)
def get_unscheduled_events_endpoint(
    skip: int = 0,
    limit: int = 100,
    category_id: Optional[int] = None,
    is_team_event: Optional[bool] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_events"))
):
    """
    Get all events that haven't been scheduled yet

    Optional query parameters:
    - skip: Number of records to skip (for pagination)
    - limit: Maximum number of records to return (for pagination)
    - category_id: Filter by category ID
    - is_team_event: Filter by whether the event is a team event
    """
    filters = {
        "category_id": category_id,
        "is_team_event": is_team_event
    }
    events, total = get_unscheduled_events(db, skip=skip, limit=limit, filters=filters)
    return EventList(
        events=events,
        total=total
    )

@router.get("/public/{event_id}/details", response_model=Event)
def get_public_event_details_endpoint(
    event_id: int,
    db: Session = Depends(get_db)
):
    """
    Get a specific event by ID with all related details without requiring authentication

    This endpoint is publicly accessible and does not require a token.
    """
    return get_event_with_details(db, event_id)

@router.get("/public/{event_id}", response_model=Event)
def get_public_event_endpoint(
    event_id: int,
    db: Session = Depends(get_db)
):
    """
    Get a specific event by ID without requiring authentication

    This endpoint is publicly accessible and does not require a token.
    """
    return get_event(db, event_id)

@router.get("/{event_id}/details", response_model=Event)
def get_event_details_endpoint(
    event_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event"))
):
    """Get a specific event by ID with all related details"""
    return get_event_with_details(db, event_id)

@router.get("/{event_id}", response_model=Event)
def get_event_endpoint(
    event_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event"))
):
    """Get a specific event by ID"""
    return get_event(db, event_id)

@router.put("/{event_id}", response_model=EventResponse)
def update_event_endpoint(
    event_id: int,
    event: EventUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("update_event"))
):
    """Update an event"""
    db_event = update_event(db, event_id, event)
    return EventResponse(
        message="Event updated successfully",
        event=db_event
    )

@router.delete("/{event_id}", response_model=EventResponse)
def delete_event_endpoint(
    event_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("delete_event"))
):
    """Delete an event and all associated teams and team members"""
    deleted_event = delete_event(db, event_id)
    return EventResponse(
        message="Event and all associated teams and team members deleted successfully",
        event=deleted_event
    )

