from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Events.EventSchedule import (
    create_event_schedule,
    get_event_schedule,
    get_event_schedule_with_details,
    get_event_schedules,
    update_event_schedule,
    delete_event_schedule
)
from schemas.Events.EventSchedule import (
    EventScheduleCreate,
    EventScheduleResponse,
    EventScheduleUpdate,
    EventSchedule,
    EventScheduleList,
    EventScheduleDetail,
    EventScheduleWithNames,
    RoundType
)
from schemas.rbac.user import User

router = APIRouter(prefix="/event-schedules", tags=["event_schedules"])

@router.post("/", response_model=EventScheduleResponse)
def create_schedule_endpoint(
    schedule: EventScheduleCreate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("create_event_schedule")),
    token: str = Depends(oauth2_scheme)
):
    """Create a new event schedule"""
    db_schedule = create_event_schedule(db, schedule)
    return EventScheduleResponse(
        message="Event schedule created successfully",
        schedule=db_schedule
    )

@router.get("/", response_model=EventScheduleList)
def get_schedules_endpoint(
    skip: int = 0,
    limit: int = 100,
    round_name: Optional[RoundType] = None,
    date_filter: Optional[date] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event_schedules"))
):
    """Get all event schedules with pagination and optional filtering"""
    filters = {
        "round_name": round_name.value if round_name else None,
        "date": date_filter
    }
    schedules, total = get_event_schedules(db, skip=skip, limit=limit, filters=filters)

    # Convert the list of dictionaries to a list of EventScheduleWithNames objects
    schedule_objects = [EventScheduleWithNames(**schedule) for schedule in schedules]

    return EventScheduleList(
        schedules=schedule_objects,
        total=total
    )

@router.get("/{schedule_id}", response_model=EventSchedule)
def get_schedule_endpoint(
    schedule_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event_schedule"))
):
    """Get a specific event schedule by ID"""
    return get_event_schedule(db, schedule_id)

@router.get("/{schedule_id}/details", response_model=EventScheduleDetail)
def get_schedule_details_endpoint(
    schedule_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_event_schedule"))
):
    """Get a specific event schedule by ID with related event and venue details"""
    schedule = get_event_schedule_with_details(db, schedule_id)

    # Create a response with flattened event and venue information
    return EventScheduleDetail(
        id=schedule.id,
        event_id=schedule.event_id,
        venue_id=schedule.venue_id,
        start_time=schedule.start_time,
        end_time=schedule.end_time,
        round_name=schedule.round_name,
        event_name=schedule.event.event_name,
        venue_name=schedule.venue.venue_name
    )

@router.put("/{schedule_id}", response_model=EventScheduleResponse)
def update_schedule_endpoint(
    schedule_id: int,
    schedule: EventScheduleUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("update_event_schedule")),
    token: str = Depends(oauth2_scheme)
):
    """Update an event schedule"""
    db_schedule = update_event_schedule(db, schedule_id, schedule)
    return EventScheduleResponse(
        message="Event schedule updated successfully",
        schedule=db_schedule
    )

@router.delete("/{schedule_id}", response_model=EventScheduleResponse)
def delete_schedule_endpoint(
    schedule_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("delete_event_schedule"))
):
    """Delete an event schedule"""
    deleted_schedule = delete_event_schedule(db, schedule_id)
    return EventScheduleResponse(
        message="Event schedule deleted successfully",
        schedule=deleted_schedule
    )
