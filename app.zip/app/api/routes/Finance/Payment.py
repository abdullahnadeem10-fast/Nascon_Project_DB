from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from pydantic import BaseModel

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from crud.Finance.Payment import (
    create_payment,
    get_payment,
    get_payment_by_transaction_id,
    get_payments,
    get_payment_summary,
    update_payment,
    update_payment_status,
    delete_payment,
    map_db_to_schema_payment_type
)
from pydantic import BaseModel
from schemas.Finance.Payment import (
    PaymentCreate,
    PaymentResponse,
    PaymentUpdate,
    Payment,
    PaymentList,
    PaymentSummary,
    PaymentMethod,
    PaymentType,
    PaymentStatus
)
from schemas.rbac.user import User

router = APIRouter(prefix="/payments", tags=["payments"])

@router.post("/", response_model=PaymentResponse)
def create_payment_endpoint(
    payment: PaymentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a new payment record"""
    # If user_id is not provided, use the current user's ID
    if payment.user_id != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        _=Depends(require_permission("manage_payments"))

    db_payment = create_payment(db, payment)

    # Convert database model to schema model
    payment_schema = Payment(
        id=db_payment.id,
        amount=db_payment.amount,
        payment_method=db_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
        registration_id=db_payment.registration_id,
        notes=db_payment.notes,
        user_id=db_payment.user_id,
        status=db_payment.status,
        transaction_id=db_payment.transaction_id,
        created_at=db_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return PaymentResponse(
        message="Payment record created successfully",
        payment=payment_schema
    )

@router.get("/", response_model=PaymentList)
def get_all_payments(
    skip: int = 0,
    limit: int = 100,
    user_id: Optional[int] = None,
    payment_type: Optional[PaymentType] = None,
    payment_method: Optional[PaymentMethod] = None,
    status: Optional[PaymentStatus] = None,
    reference_id: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    min_amount: Optional[float] = None,
    max_amount: Optional[float] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_payments"))
):
    """Get all payments with pagination and optional filtering"""
    filters = {
        "user_id": user_id,
        "payment_type": payment_type.value if payment_type else None,
        "payment_method": payment_method.value if payment_method else None,
        "status": status.value if status else None,
        "reference_id": reference_id,
        "start_date": start_date,
        "end_date": end_date,
        "min_amount": min_amount,
        "max_amount": max_amount
    }
    db_payments, total = get_payments(db, skip=skip, limit=limit, filters=filters)

    # Convert database models to schema models
    payment_schemas = []
    for db_payment in db_payments:
        payment_schema = Payment(
            id=db_payment.id,
            amount=db_payment.amount,
            payment_method=db_payment.payment_method,
            payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
            registration_id=db_payment.registration_id,
            notes=db_payment.notes,
            user_id=db_payment.user_id,
            status=db_payment.status,
            transaction_id=db_payment.transaction_id,
            created_at=db_payment.payment_date,  # Use payment_date as created_at
            updated_at=None
        )
        payment_schemas.append(payment_schema)

    return PaymentList(
        payments=payment_schemas,
        total=total
    )

@router.get("/my-payments", response_model=PaymentList)
def get_my_payments(
    skip: int = 0,
    limit: int = 100,
    payment_type: Optional[PaymentType] = None,
    payment_method: Optional[PaymentMethod] = None,
    status: Optional[PaymentStatus] = None,
    reference_id: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get all payments for the current user"""
    filters = {
        "user_id": current_user.id,
        "payment_type": payment_type.value if payment_type else None,
        "payment_method": payment_method.value if payment_method else None,
        "status": status.value if status else None,
        "reference_id": reference_id,
        "start_date": start_date,
        "end_date": end_date
    }
    db_payments, total = get_payments(db, skip=skip, limit=limit, filters=filters)

    # Convert database models to schema models
    payment_schemas = []
    for db_payment in db_payments:
        payment_schema = Payment(
            id=db_payment.id,
            amount=db_payment.amount,
            payment_method=db_payment.payment_method,
            payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
            registration_id=db_payment.registration_id,
            notes=db_payment.notes,
            user_id=db_payment.user_id,
            status=db_payment.status,
            transaction_id=db_payment.transaction_id,
            created_at=db_payment.payment_date,  # Use payment_date as created_at
            updated_at=None
        )
        payment_schemas.append(payment_schema)

    return PaymentList(
        payments=payment_schemas,
        total=total
    )

@router.get("/summary", response_model=PaymentSummary)
def get_payment_summary_endpoint(
    user_id: Optional[int] = None,
    payment_type: Optional[PaymentType] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_payment_summary"))
):
    """Get payment summary statistics"""
    return get_payment_summary(
        db,
        user_id=user_id,
        payment_type=payment_type.value if payment_type else None,
        start_date=start_date,
        end_date=end_date
    )

@router.get("/my-summary", response_model=PaymentSummary)
def get_my_payment_summary(
    payment_type: Optional[PaymentType] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get payment summary statistics for the current user"""
    return get_payment_summary(
        db,
        user_id=current_user.id,
        payment_type=payment_type.value if payment_type else None,
        start_date=start_date,
        end_date=end_date
    )

@router.get("/{payment_id}", response_model=Payment)
def get_payment_endpoint(
    payment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific payment by ID"""
    db_payment = get_payment(db, payment_id)

    # Check if user is authorized to view this payment
    if db_payment.user_id != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        _=Depends(require_permission("view_payments"))

    # Convert database model to schema model
    payment_schema = Payment(
        id=db_payment.id,
        amount=db_payment.amount,
        payment_method=db_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
        registration_id=db_payment.registration_id,
        notes=db_payment.notes,
        user_id=db_payment.user_id,
        status=db_payment.status,
        transaction_id=db_payment.transaction_id,
        created_at=db_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return payment_schema

@router.get("/transaction/{transaction_id}", response_model=Payment)
def get_payment_by_transaction_id_endpoint(
    transaction_id: str,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_payments"))
):
    """Get a payment by transaction ID"""
    db_payment = get_payment_by_transaction_id(db, transaction_id)

    # Convert database model to schema model
    payment_schema = Payment(
        id=db_payment.id,
        amount=db_payment.amount,
        payment_method=db_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
        registration_id=db_payment.registration_id,
        notes=db_payment.notes,
        user_id=db_payment.user_id,
        status=db_payment.status,
        transaction_id=db_payment.transaction_id,
        created_at=db_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return payment_schema

@router.put("/{payment_id}", response_model=PaymentResponse)
def update_payment_endpoint(
    payment_id: int,
    payment: PaymentUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_payments"))
):
    """Update a payment (admin only)"""
    db_payment = update_payment(db, payment_id, payment)

    # Convert database model to schema model
    payment_schema = Payment(
        id=db_payment.id,
        amount=db_payment.amount,
        payment_method=db_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
        registration_id=db_payment.registration_id,
        notes=db_payment.notes,
        user_id=db_payment.user_id,
        status=db_payment.status,
        transaction_id=db_payment.transaction_id,
        created_at=db_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return PaymentResponse(
        message="Payment updated successfully",
        payment=payment_schema
    )

@router.post("/{payment_id}/status/{status}", response_model=PaymentResponse)
def update_payment_status_endpoint(
    payment_id: int,
    status: PaymentStatus,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_payments"))
):
    """Update the status of a payment"""
    db_payment = update_payment_status(db, payment_id, status.value)

    message = "Payment status updated to Pending"
    if status == PaymentStatus.COMPLETED:
        message = "Payment completed successfully"
    elif status == PaymentStatus.FAILED:
        message = "Payment failed"
    elif status == PaymentStatus.REFUNDED:
        message = "Payment refunded"

    # Convert database model to schema model
    payment_schema = Payment(
        id=db_payment.id,
        amount=db_payment.amount,
        payment_method=db_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
        registration_id=db_payment.registration_id,
        notes=db_payment.notes,
        user_id=db_payment.user_id,
        status=db_payment.status,
        transaction_id=db_payment.transaction_id,
        created_at=db_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return PaymentResponse(
        message=message,
        payment=payment_schema
    )

@router.delete("/{payment_id}", response_model=PaymentResponse)
def delete_payment_endpoint(
    payment_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_payments"))
):
    """Delete a payment (admin only)"""
    deleted_payment = delete_payment(db, payment_id)

    # Convert database model to schema model
    payment_schema = Payment(
        id=deleted_payment.id,
        amount=deleted_payment.amount,
        payment_method=deleted_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(deleted_payment.payment_type),
        registration_id=deleted_payment.registration_id,
        notes=deleted_payment.notes,
        user_id=deleted_payment.user_id,
        status=deleted_payment.status,
        transaction_id=deleted_payment.transaction_id,
        created_at=deleted_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return PaymentResponse(
        message="Payment deleted successfully",
        payment=payment_schema
    )

@router.post("/{payment_id}/approve", response_model=PaymentResponse)
def approve_payment_endpoint(
    payment_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("approve_payments"))
):
    """
    Approve a payment (change status from Pending to Completed)

    If this is a registration payment, the associated event registration's payment status
    will also be updated to 'Paid' automatically.
    """
    # Get the payment
    db_payment = get_payment(db, payment_id)

    # Check if payment is already completed
    if db_payment.status == "Completed":
        raise HTTPException(status_code=400, detail="Payment is already approved")

    # Check if payment is in pending status
    if db_payment.status != "Pending":
        raise HTTPException(status_code=400, detail=f"Cannot approve payment with status: {db_payment.status}")

    # Update payment status to Completed
    # This will also update the associated registration's payment status if applicable
    db_payment = update_payment_status(db, payment_id, "Completed")

    # Prepare response message
    message = "Payment approved successfully"
    if db_payment.payment_type == "Registration" and db_payment.registration_id is not None:
        message = "Payment approved successfully and event registration marked as paid"

    # Convert database model to schema model
    payment_schema = Payment(
        id=db_payment.id,
        amount=db_payment.amount,
        payment_method=db_payment.payment_method,
        payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
        registration_id=db_payment.registration_id,
        notes=db_payment.notes,
        user_id=db_payment.user_id,
        status=db_payment.status,
        transaction_id=db_payment.transaction_id,
        created_at=db_payment.payment_date,  # Use payment_date as created_at
        updated_at=None
    )

    return PaymentResponse(
        message=message,
        payment=payment_schema
    )

@router.get("/status/{status}", response_model=PaymentList)
def get_payments_by_status_endpoint(
    status: PaymentStatus,
    skip: int = 0,
    limit: int = 100,
    user_id: Optional[int] = None,
    payment_type: Optional[PaymentType] = None,
    payment_method: Optional[PaymentMethod] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_payments"))
):
    """Get all payments with a specific status"""
    filters = {
        "user_id": user_id,
        "payment_type": payment_type.value if payment_type else None,
        "payment_method": payment_method.value if payment_method else None,
        "status": status.value,
        "start_date": start_date,
        "end_date": end_date
    }

    db_payments, total = get_payments(db, skip=skip, limit=limit, filters=filters)

    # Convert database models to schema models
    payment_schemas = []
    for db_payment in db_payments:
        payment_schema = Payment(
            id=db_payment.id,
            amount=db_payment.amount,
            payment_method=db_payment.payment_method,
            payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
            registration_id=db_payment.registration_id,
            notes=db_payment.notes,
            user_id=db_payment.user_id,
            status=db_payment.status,
            transaction_id=db_payment.transaction_id,
            created_at=db_payment.payment_date,  # Use payment_date as created_at
            updated_at=None
        )
        payment_schemas.append(payment_schema)

    return PaymentList(
        payments=payment_schemas,
        total=total
    )

@router.get("/my-payments/status/{status}", response_model=PaymentList)
def get_my_payments_by_status_endpoint(
    status: PaymentStatus,
    skip: int = 0,
    limit: int = 100,
    payment_type: Optional[PaymentType] = None,
    payment_method: Optional[PaymentMethod] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get current user's payments with a specific status"""
    filters = {
        "user_id": current_user.id,
        "payment_type": payment_type.value if payment_type else None,
        "payment_method": payment_method.value if payment_method else None,
        "status": status.value,
        "start_date": start_date,
        "end_date": end_date
    }

    db_payments, total = get_payments(db, skip=skip, limit=limit, filters=filters)

    # Convert database models to schema models
    payment_schemas = []
    for db_payment in db_payments:
        payment_schema = Payment(
            id=db_payment.id,
            amount=db_payment.amount,
            payment_method=db_payment.payment_method,
            payment_type=map_db_to_schema_payment_type(db_payment.payment_type),
            registration_id=db_payment.registration_id,
            notes=db_payment.notes,
            user_id=db_payment.user_id,
            status=db_payment.status,
            transaction_id=db_payment.transaction_id,
            created_at=db_payment.payment_date,  # Use payment_date as created_at
            updated_at=None
        )
        payment_schemas.append(payment_schema)

    return PaymentList(
        payments=payment_schemas,
        total=total
    )

class BatchApprovalResponse(BaseModel):
    message: str
    approved_count: int
    failed_count: int
    failed_ids: List[int] = []

@router.post("/batch-approve", response_model=BatchApprovalResponse)
def batch_approve_payments_endpoint(
    payment_ids: List[int] = Body(..., description="List of payment IDs to approve"),
    db: Session = Depends(get_db),
    _=Depends(require_permission("approve_payments"))
):
    """Approve multiple payments at once"""
    approved_count = 0
    failed_count = 0
    failed_ids = []

    for payment_id in payment_ids:
        try:
            # Get the payment
            db_payment = get_payment(db, payment_id)

            # Skip if already completed
            if db_payment.status == "Completed":
                failed_count += 1
                failed_ids.append(payment_id)
                continue

            # Skip if not in pending status
            if db_payment.status != "Pending":
                failed_count += 1
                failed_ids.append(payment_id)
                continue

            # Update payment status to Completed
            update_payment_status(db, payment_id, "Completed")
            approved_count += 1

        except Exception:
            failed_count += 1
            failed_ids.append(payment_id)

    return BatchApprovalResponse(
        message=f"Batch approval completed. {approved_count} payments approved, {failed_count} failed.",
        approved_count=approved_count,
        failed_count=failed_count,
        failed_ids=failed_ids
    )
