from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, date, timedelta

from api.deps import get_db, get_current_user
from core.permissions import require_permission
from core.security import oauth2_scheme
from crud.Finance.FinancialReport import (
    create_financial_report,
    get_financial_report,
    get_financial_report_with_generator,
    get_financial_reports,
    get_financial_reports_with_generators,
    get_latest_financial_reports,
    generate_periodic_report,
    generate_event_report,
    update_financial_report,
    delete_financial_report
)
from schemas.Finance.FinancialReport import (
    FinancialReportCreate,
    FinancialReportResponse,
    FinancialReportUpdate,
    FinancialReport,
    FinancialReportList,
    FinancialReportWithGenerator,
    ReportType
)
from schemas.rbac.user import User

router = APIRouter(prefix="/financial-reports", tags=["financial_reports"])

@router.post("/", response_model=FinancialReportResponse)
def create_financial_report_endpoint(
    report: FinancialReportCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_financial_report"))
):
    """Create a new financial report"""
    # Set the current user as the generator if not specified
    if report.generated_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        _=Depends(require_permission("manage_all_financial_reports"))

    db_report = create_financial_report(db, report)
    return FinancialReportResponse(
        message="Financial report created successfully",
        report=db_report
    )

@router.get("/", response_model=FinancialReportList)
def get_all_financial_reports(
    skip: int = 0,
    limit: int = 100,
    report_type: Optional[ReportType] = None,
    generated_by: Optional[int] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_financial_reports"))
):
    """Get all financial reports with pagination and optional filtering"""
    filters = {
        "report_type": report_type.value if report_type else None,
        "generated_by": generated_by,
        "start_date": start_date,
        "end_date": end_date,
        "search": search
    }
    reports, total = get_financial_reports(db, skip=skip, limit=limit, filters=filters)
    return FinancialReportList(
        reports=reports,
        total=total
    )

@router.get("/with-generators", response_model=List[FinancialReportWithGenerator])
def get_financial_reports_with_generators_endpoint(
    skip: int = 0,
    limit: int = 100,
    report_type: Optional[ReportType] = None,
    generated_by: Optional[int] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_financial_reports"))
):
    """Get all financial reports with generator details"""
    filters = {
        "report_type": report_type.value if report_type else None,
        "generated_by": generated_by,
        "start_date": start_date,
        "end_date": end_date,
        "search": search
    }
    reports, _ = get_financial_reports_with_generators(db, skip=skip, limit=limit, filters=filters)

    # Create response with generator details
    result = []
    for report in reports:
        result.append(FinancialReportWithGenerator(
            id=report.id,
            report_name=report.report_name,
            report_type=report.report_type,
            start_date=report.start_date,
            end_date=report.end_date,
            total_income=report.total_income,
            total_expense=report.total_expense,
            net_profit=report.net_profit,
            report_data=report.report_data,
            generated_at=report.generated_at,
            generated_by=report.generated_by,
            generator_username=report.generator.username,
            generator_name=f"{report.generator.first_name} {report.generator.last_name}"
        ))

    return result

@router.get("/latest", response_model=List[FinancialReport])
def get_latest_reports(
    report_type: Optional[ReportType] = None,
    limit: int = 5,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_financial_reports"))
):
    """Get the latest financial reports"""
    reports = get_latest_financial_reports(
        db,
        report_type=report_type.value if report_type else None,
        limit=limit
    )
    return reports

@router.post("/generate/daily", response_model=FinancialReportResponse)
def generate_daily_report(
    date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_financial_report"))
):
    """Generate a daily financial report"""
    # Use today's date if not specified
    report_date = date or datetime.now().date()

    # For a daily report, start and end date are the same
    db_report = generate_periodic_report(
        db,
        report_type="Daily",
        start_date=report_date,
        end_date=report_date,
        user_id=current_user.id
    )

    return FinancialReportResponse(
        message=f"Daily financial report for {report_date.strftime('%Y-%m-%d')} generated successfully",
        report=db_report
    )

@router.post("/generate/weekly", response_model=FinancialReportResponse)
def generate_weekly_report(
    start_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_financial_report"))
):
    """Generate a weekly financial report"""
    # Use the start of the current week if not specified
    today = datetime.now().date()
    report_start_date = start_date or (today - timedelta(days=today.weekday()))
    report_end_date = report_start_date + timedelta(days=6)

    db_report = generate_periodic_report(
        db,
        report_type="Weekly",
        start_date=report_start_date,
        end_date=report_end_date,
        user_id=current_user.id
    )

    return FinancialReportResponse(
        message=f"Weekly financial report for {report_start_date.strftime('%Y-%m-%d')} to {report_end_date.strftime('%Y-%m-%d')} generated successfully",
        report=db_report
    )

@router.post("/generate/monthly", response_model=FinancialReportResponse)
def generate_monthly_report(
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_financial_report"))
):
    """Generate a monthly financial report"""
    # Use the current month if not specified
    today = datetime.now().date()
    report_year = year or today.year
    report_month = month or today.month

    # Calculate start and end dates for the month
    import calendar
    _, last_day = calendar.monthrange(report_year, report_month)
    report_start_date = date(report_year, report_month, 1)
    report_end_date = date(report_year, report_month, last_day)

    db_report = generate_periodic_report(
        db,
        report_type="Monthly",
        start_date=report_start_date,
        end_date=report_end_date,
        user_id=current_user.id
    )

    return FinancialReportResponse(
        message=f"Monthly financial report for {report_start_date.strftime('%B %Y')} generated successfully",
        report=db_report
    )

@router.post("/generate/custom", response_model=FinancialReportResponse)
def generate_custom_report(
    start_date: date,
    end_date: date,
    report_name: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_financial_report"))
):
    """Generate a custom financial report for a specific date range"""
    # Validate date range
    if end_date < start_date:
        raise HTTPException(status_code=400, detail="End date cannot be before start date")

    db_report = generate_periodic_report(
        db,
        report_type="Custom",
        start_date=start_date,
        end_date=end_date,
        report_name=report_name,
        user_id=current_user.id
    )

    return FinancialReportResponse(
        message=f"Custom financial report for {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')} generated successfully",
        report=db_report
    )

@router.post("/generate/event/{event_id}", response_model=FinancialReportResponse)
def generate_event_report_endpoint(
    event_id: int,
    report_name: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("create_financial_report"))
):
    """Generate a financial report for a specific event"""
    db_report = generate_event_report(
        db,
        event_id=event_id,
        report_name=report_name,
        user_id=current_user.id
    )

    return FinancialReportResponse(
        message=f"Event financial report for event ID {event_id} generated successfully",
        report=db_report
    )

@router.get("/{report_id}", response_model=FinancialReport)
def get_financial_report_endpoint(
    report_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_financial_reports"))
):
    """Get a specific financial report by ID"""
    return get_financial_report(db, report_id)

@router.get("/{report_id}/with-generator", response_model=FinancialReportWithGenerator)
def get_financial_report_with_generator_endpoint(
    report_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_financial_reports"))
):
    """Get a specific financial report by ID with generator details"""
    report = get_financial_report_with_generator(db, report_id)

    # Create response with generator details
    return FinancialReportWithGenerator(
        id=report.id,
        report_name=report.report_name,
        report_type=report.report_type,
        start_date=report.start_date,
        end_date=report.end_date,
        total_income=report.total_income,
        total_expense=report.total_expense,
        net_profit=report.net_profit,
        report_data=report.report_data,
        generated_at=report.generated_at,
        generated_by=report.generated_by,
        generator_username=report.generator.username,
        generator_name=f"{report.generator.first_name} {report.generator.last_name}"
    )

@router.put("/{report_id}", response_model=FinancialReportResponse)
def update_financial_report_endpoint(
    report_id: int,
    report: FinancialReportUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("update_financial_report"))
):
    """Update a financial report"""
    # Check if user is authorized to update this report
    db_report = get_financial_report(db, report_id)
    if db_report.generated_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        _=Depends(require_permission("manage_all_financial_reports"))

    updated_report = update_financial_report(db, report_id, report)
    return FinancialReportResponse(
        message="Financial report updated successfully",
        report=updated_report
    )

@router.delete("/{report_id}", response_model=FinancialReportResponse)
def delete_financial_report_endpoint(
    report_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _=Depends(require_permission("delete_financial_report"))
):
    """Delete a financial report"""
    # Check if user is authorized to delete this report
    db_report = get_financial_report(db, report_id)
    if db_report.generated_by != current_user.id:
        # Check if user has admin permissions
        # This would typically be handled by a more sophisticated permission system
        _=Depends(require_permission("manage_all_financial_reports"))

    deleted_report = delete_financial_report(db, report_id)
    return FinancialReportResponse(
        message="Financial report deleted successfully",
        report=deleted_report
    )
