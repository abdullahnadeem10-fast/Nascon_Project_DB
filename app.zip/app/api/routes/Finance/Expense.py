from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import date

from api.deps import get_db, get_current_user
from core.security import oauth2_scheme
from core.permissions import require_permission
from crud.Finance import Expense as expense_crud
from schemas.Finance.Expense import (
    ExpenseCreate,
    ExpenseUpdate,
    Expense,
    ExpenseResponse,
    ExpenseList,
    ExpenseSummary,
    ExpenseCategory,
    ApprovalStatus
)

router = APIRouter(prefix="/expenses", tags=["expenses"])

@router.post("/", response_model=ExpenseResponse)
def create_expense(
    expense: ExpenseCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("create_expense"))
):
    """
    Create a new expense record
    """
    db_expense = expense_crud.create_expense(db=db, expense=expense, user_id=current_user.id)
    return ExpenseResponse(
        message="Expense created successfully",
        expense=db_expense
    )

@router.get("/", response_model=ExpenseList)
def get_expenses(
    skip: int = 0,
    limit: int = 100,
    created_by: Optional[int] = None,
    expense_category: Optional[ExpenseCategory] = None,
    approval_status: Optional[ApprovalStatus] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    min_amount: Optional[float] = None,
    max_amount: Optional[float] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get all expenses with pagination and filtering
    """
    # Build filters
    filters = {}
    if created_by:
        filters["created_by"] = created_by
    if expense_category:
        filters["expense_category"] = expense_category
    if approval_status:
        filters["approval_status"] = approval_status
    if start_date:
        filters["start_date"] = start_date
    if end_date:
        filters["end_date"] = end_date
    if min_amount:
        filters["min_amount"] = min_amount
    if max_amount:
        filters["max_amount"] = max_amount
    
    # Get expenses
    expenses, total = expense_crud.get_expenses(db=db, skip=skip, limit=limit, filters=filters)
    
    return ExpenseList(
        expenses=expenses,
        total=total
    )

@router.get("/summary", response_model=ExpenseSummary)
def get_expense_summary(
    created_by: Optional[int] = None,
    expense_category: Optional[ExpenseCategory] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get expense summary statistics
    """
    return expense_crud.get_expense_summary(
        db=db,
        created_by=created_by,
        expense_category=expense_category,
        start_date=start_date,
        end_date=end_date
    )

@router.get("/my", response_model=ExpenseList)
def get_my_expenses(
    skip: int = 0,
    limit: int = 100,
    expense_category: Optional[ExpenseCategory] = None,
    approval_status: Optional[ApprovalStatus] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    min_amount: Optional[float] = None,
    max_amount: Optional[float] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get current user's expenses with pagination and filtering
    """
    # Build filters
    filters = {"created_by": current_user.id}
    if expense_category:
        filters["expense_category"] = expense_category
    if approval_status:
        filters["approval_status"] = approval_status
    if start_date:
        filters["start_date"] = start_date
    if end_date:
        filters["end_date"] = end_date
    if min_amount:
        filters["min_amount"] = min_amount
    if max_amount:
        filters["max_amount"] = max_amount
    
    # Get expenses
    expenses, total = expense_crud.get_expenses(db=db, skip=skip, limit=limit, filters=filters)
    
    return ExpenseList(
        expenses=expenses,
        total=total
    )

@router.get("/pending", response_model=ExpenseList)
def get_pending_expenses(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("approve_expense"))
):
    """
    Get all pending expenses
    """
    filters = {"approval_status": ApprovalStatus.PENDING}
    expenses, total = expense_crud.get_expenses(db=db, skip=skip, limit=limit, filters=filters)
    
    return ExpenseList(
        expenses=expenses,
        total=total
    )

@router.get("/{expense_id}", response_model=Expense)
def get_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    _=Depends(oauth2_scheme),
    current_user = Depends(get_current_user)
):
    """
    Get an expense by ID
    """
    expense = expense_crud.get_expense(db=db, expense_id=expense_id)
    
    # Check if user has permission to view this expense
    if expense.created_by != current_user.id and not current_user.has_permission("approve_expense"):
        raise HTTPException(status_code=403, detail="Not authorized to access this expense")
    
    return expense

@router.put("/{expense_id}", response_model=ExpenseResponse)
def update_expense(
    expense_id: int,
    expense: ExpenseUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Update an expense
    """
    # Get the expense
    db_expense = expense_crud.get_expense(db=db, expense_id=expense_id)
    
    # Check if user has permission to update this expense
    if db_expense.created_by != current_user.id and not current_user.has_permission("manage_expenses"):
        raise HTTPException(status_code=403, detail="Not authorized to update this expense")
    
    # Check if expense is already approved or rejected
    if db_expense.approval_status != ApprovalStatus.PENDING:
        raise HTTPException(status_code=400, detail="Cannot update an expense that is already approved or rejected")
    
    # Update the expense
    updated_expense = expense_crud.update_expense(db=db, expense_id=expense_id, expense=expense)
    
    return ExpenseResponse(
        message="Expense updated successfully",
        expense=updated_expense
    )

@router.post("/{expense_id}/approve", response_model=ExpenseResponse)
def approve_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("approve_expense"))
):
    """
    Approve an expense
    """
    approved_expense = expense_crud.approve_expense(db=db, expense_id=expense_id, approver_id=current_user.id)
    
    return ExpenseResponse(
        message="Expense approved successfully",
        expense=approved_expense
    )

@router.post("/{expense_id}/reject", response_model=ExpenseResponse)
def reject_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("approve_expense"))
):
    """
    Reject an expense
    """
    rejected_expense = expense_crud.reject_expense(db=db, expense_id=expense_id, approver_id=current_user.id)
    
    return ExpenseResponse(
        message="Expense rejected successfully",
        expense=rejected_expense
    )

@router.delete("/{expense_id}", response_model=ExpenseResponse)
def delete_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Delete an expense
    """
    # Get the expense
    db_expense = expense_crud.get_expense(db=db, expense_id=expense_id)
    
    # Check if user has permission to delete this expense
    if db_expense.created_by != current_user.id and not current_user.has_permission("manage_expenses"):
        raise HTTPException(status_code=403, detail="Not authorized to delete this expense")
    
    # Check if expense is already approved
    if db_expense.approval_status == ApprovalStatus.APPROVED:
        raise HTTPException(status_code=400, detail="Cannot delete an approved expense")
    
    # Delete the expense
    deleted_expense = expense_crud.delete_expense(db=db, expense_id=expense_id)
    
    return ExpenseResponse(
        message="Expense deleted successfully",
        expense=deleted_expense
    )
