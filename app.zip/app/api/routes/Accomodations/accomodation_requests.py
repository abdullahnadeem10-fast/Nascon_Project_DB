from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date, datetime, timedelta
from decimal import Decimal

from core.security import oauth2_scheme
from crud.accomodation import accommodation_requests as request_crud
from crud.accomodation import room_type as room_type_crud
from crud.accomodation import room as room_crud
from crud.accomodation import allocation as allocation_crud
from schemas.accomodation.Accomodation_Requests import (
    AccommodationRequestCreate,
    AccommodationRequestUpdate,
    AccommodationRequestResponse,
    AccommodationRequestWithMessage
)
from schemas.accomodation.Allocation import RoomAllocationCreate, RoomAllocationResponse
from api.deps import get_db, get_current_user
from core.permissions import require_permission

router = APIRouter(prefix="/requests")

@router.post("/",
    response_model=AccommodationRequestResponse,
    status_code=status.HTTP_201_CREATED)
def create_request(
    request: AccommodationRequestCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    return request_crud.create_accommodation_request(db, request, current_user.id)

@router.get("/", response_model=List[AccommodationRequestResponse])
def get_all_requests(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_all_requests")),
    token: str = Depends(oauth2_scheme)
):
    return request_crud.get_all_accommodation_requests(db, skip=skip, limit=limit)

@router.get("/me", response_model=List[AccommodationRequestResponse])
def get_my_requests(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("view_own_requests")),
    token: str = Depends(oauth2_scheme)
):
    return request_crud.get_user_accommodation_requests(db, current_user.id, skip=skip, limit=limit)

@router.get("/{request_id}", response_model=AccommodationRequestResponse)
def get_request(
    request_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("view_all_requests"))
):
    request = request_crud.get_accommodation_request(db, request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    if request.user_id != current_user.id and not current_user.has_permission("view_all_requests"):
        raise HTTPException(status_code=403, detail="Not authorized to view this request")
    return request

@router.put("/{request_id}", response_model=AccommodationRequestResponse)
def update_request(
    request_id: int,
    request_update: AccommodationRequestUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("manage_requests"))
):
    existing_request = request_crud.get_accommodation_request(db, request_id)
    if not existing_request:
        raise HTTPException(status_code=404, detail="Request not found")
    if existing_request.user_id != current_user.id and not current_user.has_permission("manage_requests"):
        raise HTTPException(status_code=403, detail="Not authorized to update this request")

    return request_crud.update_accommodation_request(db, request_id, request_update)

@router.delete("/{request_id}")
def delete_request(
    request_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("manage_requests"))
):
    existing_request = request_crud.get_accommodation_request(db, request_id)
    if not existing_request:
        raise HTTPException(status_code=404, detail="Request not found")
    if existing_request.user_id != current_user.id and not current_user.has_permission("manage_requests"):
        raise HTTPException(status_code=403, detail="Not authorized to delete this request")

    if request_crud.delete_accommodation_request(db, request_id):
        return {"message": "Request deleted successfully"}
    raise HTTPException(status_code=500, detail="Error deleting request")

@router.put("/{request_id}/status", response_model=AccommodationRequestResponse)
def update_request_status(
    request_id: int,
    status: str,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_requests")),
    token: str = Depends(oauth2_scheme),
):
    request = request_crud.update_request_status(db, request_id, status)
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    return request

@router.post("/{request_id}/approve", response_model=AccommodationRequestWithMessage)
def approve_request(
    request_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _=Depends(require_permission("manage_requests")),
):
    """
    Approve an accommodation request and automatically allocate a room.
    This changes the status to 'Approved' and creates a room allocation.
    The system will automatically find an available room of the preferred room type.
    """
    # Check if request exists
    existing_request = request_crud.get_accommodation_request(db, request_id)
    if not existing_request:
        raise HTTPException(status_code=404, detail="Request not found")

    # Calculate number of days between check-in and check-out
    check_in_date = existing_request.check_in_date
    check_out_date = existing_request.check_out_date
    num_days = (check_out_date - check_in_date).days

    if num_days <= 0:
        raise HTTPException(
            status_code=400,
            detail="Check-out date must be after check-in date"
        )

    # Convert dates to datetime for the allocation
    check_in_time = datetime.combine(check_in_date, datetime.min.time())
    check_out_time = datetime.combine(check_out_date, datetime.min.time())

    # Get preferred room type
    preferred_room_type_id = existing_request.preferred_room_type_id
    if not preferred_room_type_id:
        raise HTTPException(
            status_code=400,
            detail="No preferred room type specified in the request"
        )

    # Get room type to get price per night
    room_type = room_type_crud.get_room_type(db, preferred_room_type_id)

    # Find an available room of the preferred type
    available_room = room_crud.find_available_room_by_type(
        db=db,
        room_type_id=preferred_room_type_id,
        check_in_time=check_in_time,
        check_out_time=check_out_time
    )

    if not available_room:
        raise HTTPException(
            status_code=400,
            detail="No available rooms of the preferred type for the requested dates"
        )

    # Calculate total cost
    total_cost = room_type.price_per_night * Decimal(num_days)

    # Create room allocation
    allocation_data = RoomAllocationCreate(
        request_id=request_id,
        room_id=available_room.id,
        check_in_time=check_in_time,
        check_out_time=check_out_time,
        total_cost=total_cost,
        payment_status="Pending",
        allocated_by=current_user.id
    )

    # Create the allocation
    allocation = allocation_crud.create_allocation(db=db, allocation=allocation_data)

    # Update the status to Approved
    request = request_crud.update_request_status(db, request_id, "Approved")

    # Return with success message
    return AccommodationRequestWithMessage(
        message=f"Accommodation request has been approved successfully. Room {available_room.room_number} allocated with total cost of {total_cost}",
        request=request
    )

@router.post("/{request_id}/reject", response_model=AccommodationRequestWithMessage)
def reject_request(
    request_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_requests")),
):
    """
    Reject an accommodation request.
    This changes the status to 'Rejected'.
    """
    # Check if request exists
    existing_request = request_crud.get_accommodation_request(db, request_id)
    if not existing_request:
        raise HTTPException(status_code=404, detail="Request not found")

    # Update the status to Rejected
    request = request_crud.update_request_status(db, request_id, "Rejected")

    # Return with success message
    return AccommodationRequestWithMessage(
        message="Accommodation request has been rejected",
        request=request
    )

@router.get("/pending/", response_model=List[AccommodationRequestResponse])
def get_pending_requests(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(require_permission("manage_requests")),
    token: str = Depends(oauth2_scheme),
):
    return request_crud.get_pending_requests(db, skip=skip, limit=limit)

@router.get("/date-range/", response_model=List[AccommodationRequestResponse])
def get_requests_by_date_range(
    start_date: date,
    end_date: date,
    facility_id: int = None,
    status: str = None,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_all_requests")),
    token: str = Depends(oauth2_scheme)
):
    return request_crud.get_requests_by_date_range(
        db,
        start_date,
        end_date,
        facility_id=facility_id,
        status=status
    )