from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from typing import List
from core.security import oauth2_scheme
from crud.accomodation import accomodation_facilities as facility_crud
from schemas.accomodation.accomodation_Facilities import (
    AccommodationFacility,
    AccommodationFacilityCreate,
    AccommodationFacilityUpdate,
    AccommodationFacilityResponse
)
from api.deps import get_db, get_current_user
from core.permissions import require_permission
from .accomodation_requests import router as request_router

router = APIRouter(prefix="/accommodation", tags=["accommodation"])

# Facility endpoints
@router.post("/", 
    response_model=AccommodationFacilityResponse,
    status_code=status.HTTP_201_CREATED)
def create_facility(
    facility: AccommodationFacilityCreate, 
    db: Session = Depends(get_db),
    _=Depends(require_permission("create_facility")),
    token: str = Depends(oauth2_scheme)
):
    db_facility = facility_crud.create_facility(db, facility)
    return AccommodationFacilityResponse(
        message="Facility created successfully",
        facility=db_facility
    )

@router.get("/", response_model=List[AccommodationFacility])
def get_facilities(
    skip: int = 0, 
    limit: int = 10, 
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_facilities"))
):
    return facility_crud.get_facilities(db, skip=skip, limit=limit)

@router.get("/{facility_id}", response_model=AccommodationFacility)
def get_facility(
    facility_id: int, 
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_facility"))
):
    return facility_crud.get_facility(db, facility_id)

@router.put("/{facility_id}", response_model=AccommodationFacilityResponse)
def update_facility(
    facility_id: int,
    facility: AccommodationFacilityUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("update_facility"))
):
    db_facility = facility_crud.update_facility(db, facility_id, facility)
    return AccommodationFacilityResponse(
        message="Facility updated successfully",
        facility=db_facility
    )

@router.delete("/{facility_id}", response_model=AccommodationFacilityResponse)
def delete_facility(
    facility_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("delete_facility"))
):
    db_facility = facility_crud.delete_facility(db, facility_id)
    return AccommodationFacilityResponse(
        message="Facility deleted successfully",
        facility=db_facility
    )

