from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from api.deps import get_db
from core.permissions import require_permission
from crud.accomodation.room_type import (
    create_room_type,
    get_room_type,
    get_room_types,
    get_facility_room_types,
    update_room_type,
    delete_room_type
)
from schemas.accomodation.room_type import RoomTypeCreate, RoomTypeResponse, RoomTypeUpdate, RoomType
from core.security import oauth2_scheme


router = APIRouter(prefix="/room_types", tags=["room_types"])

# Room Type endpoints
@router.post("/", 
    response_model=RoomTypeResponse
    )
def create_room_type_endpoint(
    room_type: RoomTypeCreate, 
    db: Session = Depends(get_db),
    _=Depends(require_permission("create_room_type")),
    token: str = Depends(oauth2_scheme)
):
    db_room_type = create_room_type(db, room_type)
    return RoomTypeResponse(
        message="Room type created successfully",
        room_type=db_room_type
    )

@router.get("/", response_model=List[RoomType])
def get_room_types_endpoint(
    skip: int = 0, 
    limit: int = 10, 
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_room_types"))
):
    return get_room_types(db, skip=skip, limit=limit)

@router.get("/facilities/{facility_id}", response_model=List[RoomType])
def get_facility_room_types_endpoint(
    facility_id: int,
    skip: int = 0,
    limit: int = 10,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_room_types"))
):
    return get_facility_room_types(db, facility_id, skip=skip, limit=limit)

@router.get("/{room_type_id}", response_model=RoomType)
def get_room_type_endpoint(
    room_type_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("view_room_type"))
):
    return get_room_type(db, room_type_id)

@router.put("/{room_type_id}", response_model=RoomTypeResponse)
def update_room_type_endpoint(
    room_type_id: int,
    room_type: RoomTypeUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_permission("update_room_type")),
    token: str = Depends(oauth2_scheme)
):
    db_room_type = update_room_type(db, room_type_id, room_type)
    return RoomTypeResponse(
        message="Room type updated successfully",
        room_type=db_room_type
    )

@router.delete("/{room_type_id}", response_model=RoomTypeResponse)
def delete_room_type_endpoint(
    room_type_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_permission("delete_room_type"))
):
    db_room_type = delete_room_type(db, room_type_id)
    return RoomTypeResponse(
        message="Room type deleted successfully",
        room_type=db_room_type
    )