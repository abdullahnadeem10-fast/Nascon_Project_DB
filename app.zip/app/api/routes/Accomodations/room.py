from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from api.deps import get_db
from core.permissions import require_permission
from crud.accomodation.room import (
    create_room,
    get_room,
    get_rooms,
    update_room,
    delete_room,
    get_room_by_number
)
from schemas.accomodation.Room import RoomCreate, RoomUpdate, RoomOut
from core.security import oauth2_scheme


router = APIRouter(prefix="/rooms", tags=["room"])

@router.post("/", response_model=RoomOut, status_code=status.HTTP_201_CREATED)
def create_new_room(room: RoomCreate, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme), _=Depends(require_permission("create_room"))):
    db_room = get_room_by_number(db, room_number=room.room_number)
    if db_room:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Room with this number already exists"
        )
    return create_room(db=db, room=room)

@router.get("/{room_id}", response_model=RoomOut)
def read_room(room_id: int, db: Session = Depends(get_db), _=Depends(require_permission("view_room")), token: str = Depends(oauth2_scheme)):
    db_room = get_room(db, room_id=room_id)
    if db_room is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Room not found"
        )
    return db_room

@router.get("/", response_model=List[RoomOut])
def read_rooms(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), _=Depends(require_permission("view_rooms")), token: str = Depends(oauth2_scheme)):
    rooms = get_rooms(db, skip=skip, limit=limit)
    return rooms

@router.put("/{room_id}", response_model=RoomOut)
def update_existing_room(
    room_id: int, 
    room: RoomUpdate, 
    db: Session = Depends(get_db), 
    _=Depends(require_permission("update_room")), 
    token: str = Depends(oauth2_scheme)
):
    db_room = update_room(db, room_id=room_id, room=room)
    if db_room is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Room not found"
        )
    return db_room

@router.delete("/{room_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_existing_room(room_id: int, db: Session = Depends(get_db), _=Depends(require_permission("delete_room")), token: str = Depends(oauth2_scheme)):
    success = delete_room(db, room_id=room_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Room not found"
        )
    return None