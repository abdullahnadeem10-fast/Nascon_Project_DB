from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query
from api.deps import get_db
from core.permissions import require_permission
from crud.accomodation.allocation import create_allocation, delete_allocation, get_active_allocations_for_room, get_allocation, get_allocations, update_allocation
from models.accommodation import RoomAllocation
from schemas.accomodation.Allocation import RoomAllocationCreate, RoomAllocationResponse
from core.security import oauth2_scheme


router = APIRouter(prefix="/room_allocations", tags=["Room Allocations"])

@router.post("/", response_model=RoomAllocationResponse)
def create_room_allocation(
    allocation: RoomAllocationCreate,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("create_room_allocation"))
) -> RoomAllocation:
    # Check if there are any conflicting allocations
    current_allocations = get_active_allocations_for_room(
        db=db,
        room_id=allocation.room_id,
        current_time=allocation.check_in_time
    )
    if current_allocations:
        raise HTTPException(
            status_code=400,
            detail="Room is already allocated for the specified time period"
        )
    return create_allocation(db=db, allocation=allocation)

@router.get("/{allocation_id}", response_model=RoomAllocationResponse)
def read_allocation(
    allocation_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("view_room_allocation"))
) -> RoomAllocation:
    db_allocation = get_allocation(db, allocation_id)
    if db_allocation is None:
        raise HTTPException(status_code=404, detail="Allocation not found")
    return db_allocation

@router.get("/", response_model=List[RoomAllocationResponse])
def read_allocations(
    skip: int = 0,
    limit: int = 100,
    room_id: Optional[int] = None,
    payment_status: Optional[str] = None,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("view_room_allocation"))
) -> List[RoomAllocation]:
    return get_allocations(
        db=db,
        skip=skip,
        limit=limit,
        room_id=room_id,
        payment_status=payment_status
    )

@router.put("/{allocation_id}", response_model=RoomAllocationResponse)
def update_room_allocation(
    allocation_id: int,
    check_in_time: Optional[datetime] = None,
    check_out_time: Optional[datetime] = None,
    payment_status: Optional[str] = None,
    total_cost: Optional[float] = None,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("manage_room_allocation"))
) -> RoomAllocation:
    db_allocation = update_allocation(
        db=db,
        allocation_id=allocation_id,
        check_in_time=check_in_time,
        check_out_time=check_out_time,
        payment_status=payment_status,
        total_cost=total_cost
    )
    if db_allocation is None:
        raise HTTPException(status_code=404, detail="Allocation not found")
    return db_allocation

@router.delete("/{allocation_id}")
def delete_room_allocation(
    allocation_id: int,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("manage_room_allocation"))
) -> dict:
    if not delete_allocation(db=db, allocation_id=allocation_id):
        raise HTTPException(status_code=404, detail="Allocation not found")
    return {"message": "Allocation deleted successfully"}

@router.get("/room/{room_id}/active", response_model=List[RoomAllocationResponse])
def read_active_room_allocations(
    room_id: int,
    current_time: Optional[datetime] = None,
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    _=Depends(require_permission("view_room_allocation"))
) -> List[RoomAllocation]:
    return get_active_allocations_for_room(
        db=db,
        room_id=room_id,
        current_time=current_time
    )