"""
Notification triggers for various events in the application.

This module contains SQLAlchemy event listeners that automatically generate
notifications for users when specific events occur in the system.
"""

from sqlalchemy import event
from sqlalchemy.orm import Session
from db.session import engine

from models.events import (
    EventRegistration, Team, TeamMember, Event, EventSchedule
)
from models.accommodation import (
    AccommodationRequest, RoomAllocation
)
from models.finance import (
    Payment, Expense
)
from models.judging import (
    Winner, Score
)
from models.sponsorship import (
    SponsorshipContract
)
from models.notifications import Notification
from models.rbac import User

from crud.notifications.Notification import create_system_notification


# ==================== EVENT REGISTRATION NOTIFICATIONS ====================

@event.listens_for(EventRegistration, 'after_insert')
def notify_event_registration(mapper, connection, target):
    """
    Notify user when they register for an event.
    Also notify event creator about new registration.
    """
    with Session(engine) as session:
        # Get the registration that was just created
        registration = session.query(EventRegistration).filter(
            EventRegistration.id == target.id
        ).first()

        if not registration:
            return

        # Get the event details
        event = session.query(Event).filter(
            Event.id == registration.event_id
        ).first()

        if not event:
            return

        # If it's an individual registration
        if registration.user_id:
            # Notify the user about their registration
            create_system_notification(
                session,
                registration.user_id,
                f"Registration Confirmed: {event.event_name}",
                f"Your registration for {event.event_name} has been confirmed. " +
                f"Your payment status is {registration.payment_status}. " +
                f"Confirmation code: {registration.confirmation_code}",
                "Event"
            )

        # If it's a team registration
        elif registration.team_id:
            # Get the team details
            team = session.query(Team).filter(
                Team.id == registration.team_id
            ).first()

            if not team:
                return

            # Get all team members
            team_members = session.query(TeamMember).filter(
                TeamMember.team_id == team.id
            ).all()

            # Notify all team members
            for member in team_members:
                create_system_notification(
                    session,
                    member.user_id,
                    f"Team Registration Confirmed: {event.event_name}",
                    f"Your team '{team.team_name}' has been registered for {event.event_name}. " +
                    f"Payment status: {registration.payment_status}. " +
                    f"Confirmation code: {registration.confirmation_code}",
                    "Event"
                )

        # Notify the event creator about the new registration
        create_system_notification(
            session,
            event.created_by,
            f"New Registration: {event.event_name}",
            f"A new {'team' if registration.team_id else 'participant'} has registered for your event {event.event_name}.",
            "Event"
        )


# ==================== PAYMENT NOTIFICATIONS ====================

@event.listens_for(Payment, 'after_update')
def notify_payment_status_change(mapper, connection, target):
    """
    Notify user when their payment status changes.
    """
    with Session(engine) as session:
        # Only proceed if the status has changed to Completed
        if target.status != "Completed":
            return

        # Notify the user who made the payment
        create_system_notification(
            session,
            target.user_id,
            "Payment Approved",
            f"Your payment of {target.amount} ({target.payment_method}) has been approved. " +
            f"Transaction ID: {target.transaction_id}",
            "Payment"
        )

        # If it's a registration payment, update the registration status
        if target.payment_type == "Registration" and target.registration_id:
            # Get the registration
            registration = session.query(EventRegistration).filter(
                EventRegistration.id == target.registration_id
            ).first()

            if registration:
                # Get the event
                event = session.query(Event).filter(
                    Event.id == registration.event_id
                ).first()

                if event:
                    # If it's an individual registration
                    if registration.user_id:
                        create_system_notification(
                            session,
                            registration.user_id,
                            f"Registration Payment Confirmed: {event.event_name}",
                            f"Your payment for {event.event_name} has been confirmed. " +
                            f"Your registration is now complete.",
                            "Event"
                        )

                    # If it's a team registration
                    elif registration.team_id:
                        # Get the team
                        team = session.query(Team).filter(
                            Team.id == registration.team_id
                        ).first()

                        if team:
                            # Get all team members
                            team_members = session.query(TeamMember).filter(
                                TeamMember.team_id == team.id
                            ).all()

                            # Notify all team members
                            for member in team_members:
                                create_system_notification(
                                    session,
                                    member.user_id,
                                    f"Team Registration Payment Confirmed: {event.event_name}",
                                    f"The payment for your team '{team.team_name}' for {event.event_name} " +
                                    f"has been confirmed. Your registration is now complete.",
                                    "Event"
                                )


# ==================== TEAM NOTIFICATIONS ====================

@event.listens_for(TeamMember, 'after_insert')
def notify_team_member_added(mapper, connection, target):
    """
    Notify user when they are added to a team.
    Also notify team lead about new member.
    """
    with Session(engine) as session:
        # Get the team member that was just created
        team_member = session.query(TeamMember).filter(
            TeamMember.id == target.id
        ).first()

        if not team_member:
            return

        # Get the team details
        team = session.query(Team).filter(
            Team.id == team_member.team_id
        ).first()

        if not team:
            return

        # Get the event details
        event = session.query(Event).filter(
            Event.id == team.event_id
        ).first()

        if not event:
            return

        # Get the team lead
        team_lead = session.query(TeamMember).filter(
            TeamMember.team_id == team.id,
            TeamMember.is_team_lead == True
        ).first()

        # Notify the user about being added to the team
        create_system_notification(
            session,
            team_member.user_id,
            f"Added to Team: {team.team_name}",
            f"You have been added to the team '{team.team_name}' for the event {event.event_name}.",
            "Event"
        )

        # If this user is not the team lead, notify the team lead
        if team_lead and team_lead.user_id != team_member.user_id:
            # Get the user's name
            user = session.query(User).filter(
                User.id == team_member.user_id
            ).first()

            if user:
                create_system_notification(
                    session,
                    team_lead.user_id,
                    f"New Team Member: {team.team_name}",
                    f"{user.username} has joined your team '{team.team_name}' for the event {event.event_name}.",
                    "Event"
                )


# ==================== ACCOMMODATION NOTIFICATIONS ====================

@event.listens_for(AccommodationRequest, 'after_insert')
def notify_accommodation_request(mapper, connection, target):
    """
    Notify user when they submit an accommodation request.
    Also notify accommodation managers about new request.
    """
    with Session(engine) as session:
        # Get the request that was just created
        request = session.query(AccommodationRequest).filter(
            AccommodationRequest.id == target.id
        ).first()

        if not request:
            return

        # Notify the user about their request
        create_system_notification(
            session,
            request.user_id,
            "Accommodation Request Submitted",
            f"Your accommodation request for {request.check_in_date} to {request.check_out_date} " +
            f"has been submitted and is pending approval.",
            "Accommodation"
        )

        # Notify accommodation managers (users with manage_accommodations permission)
        from models.rbac import Role, UserRole, RolePermission, Permission

        # Find the permission ID for managing accommodations
        permission = session.query(Permission).filter(
            Permission.permission_name == "manage_accommodations"
        ).first()

        if permission:
            # Find roles with this permission
            role_ids = session.query(RolePermission.role_id).filter(
                RolePermission.permission_id == permission.id
            ).all()

            if role_ids:
                # Find users with these roles
                role_ids = [r.role_id for r in role_ids]
                user_ids = session.query(UserRole.user_id).filter(
                    UserRole.role_id.in_(role_ids)
                ).distinct().all()

                # Notify each manager
                for user_record in user_ids:
                    create_system_notification(
                        session,
                        user_record.user_id,
                        "New Accommodation Request",
                        f"A new accommodation request has been submitted by {request.requester.username} " +
                        f"for {request.check_in_date} to {request.check_out_date}.",
                        "Accommodation"
                    )


@event.listens_for(AccommodationRequest, 'after_update')
def notify_accommodation_request_status_change(mapper, connection, target):
    """
    Notify user when their accommodation request status changes.
    """
    with Session(engine) as session:
        # Get the request that was updated
        request = session.query(AccommodationRequest).filter(
            AccommodationRequest.id == target.id
        ).first()

        if not request:
            return

        # Notify the user about the status change
        if request.status == "Approved":
            create_system_notification(
                session,
                request.user_id,
                "Accommodation Request Approved",
                f"Your accommodation request for {request.check_in_date} to {request.check_out_date} " +
                f"has been approved. Please check your allocations for details.",
                "Accommodation"
            )
        elif request.status == "Rejected":
            create_system_notification(
                session,
                request.user_id,
                "Accommodation Request Rejected",
                f"Your accommodation request for {request.check_in_date} to {request.check_out_date} " +
                f"has been rejected. Please contact the organizers for more information.",
                "Accommodation"
            )


@event.listens_for(RoomAllocation, 'after_insert')
def notify_room_allocation(mapper, connection, target):
    """
    Notify user when they are allocated a room.
    """
    with Session(engine) as session:
        # Get the allocation that was just created
        allocation = session.query(RoomAllocation).filter(
            RoomAllocation.id == target.id
        ).first()

        if not allocation or not allocation.request_id:
            return

        # Get the request
        request = session.query(AccommodationRequest).filter(
            AccommodationRequest.id == allocation.request_id
        ).first()

        if not request:
            return

        # Get the room details
        from models.accommodation import Room, RoomType, AccommodationFacility

        room = session.query(Room).filter(
            Room.id == allocation.room_id
        ).first()

        if not room:
            return

        room_type = session.query(RoomType).filter(
            RoomType.id == room.room_type_id
        ).first()

        facility = session.query(AccommodationFacility).filter(
            AccommodationFacility.id == room.facility_id
        ).first()

        if not room_type or not facility:
            return

        # Notify the user about their room allocation
        create_system_notification(
            session,
            request.user_id,
            "Room Allocated",
            f"You have been allocated room {room.room_number} ({room_type.type_name}) " +
            f"at {facility.facility_name} for your stay from {request.check_in_date} to {request.check_out_date}. " +
            f"Total cost: {allocation.total_cost}",
            "Accommodation"
        )


# ==================== EVENT SCHEDULE NOTIFICATIONS ====================

@event.listens_for(EventSchedule, 'after_insert')
def notify_event_schedule(mapper, connection, target):
    """
    Notify registered participants when an event schedule is created.
    """
    with Session(engine) as session:
        # Get the schedule that was just created
        schedule = session.query(EventSchedule).filter(
            EventSchedule.id == target.id
        ).first()

        if not schedule:
            return

        # Get the event details
        event = session.query(Event).filter(
            Event.id == schedule.event_id
        ).first()

        if not event:
            return

        # Get the venue details
        from models.events import Venue

        venue = session.query(Venue).filter(
            Venue.id == schedule.venue_id
        ).first()

        if not venue:
            return

        # Get all registrations for this event
        registrations = session.query(EventRegistration).filter(
            EventRegistration.event_id == event.id
        ).all()

        # Collect all user IDs who need to be notified
        user_ids = set()

        for registration in registrations:
            # If it's an individual registration
            if registration.user_id:
                user_ids.add(registration.user_id)

            # If it's a team registration
            elif registration.team_id:
                # Get all team members
                team_members = session.query(TeamMember).filter(
                    TeamMember.team_id == registration.team_id
                ).all()

                for member in team_members:
                    user_ids.add(member.user_id)

        # Notify all participants
        for user_id in user_ids:
            create_system_notification(
                session,
                user_id,
                f"Event Schedule: {event.event_name}",
                f"A new schedule has been added for {event.event_name}. " +
                f"Round: {schedule.round_name}, Venue: {venue.venue_name}, " +
                f"Time: {schedule.start_time.strftime('%Y-%m-%d %H:%M')} to {schedule.end_time.strftime('%H:%M')}",
                "Event"
            )


# ==================== WINNER NOTIFICATIONS ====================

@event.listens_for(Winner, 'after_insert')
def notify_winner_announcement(mapper, connection, target):
    """
    Notify winners and all participants when winners are announced.
    """
    with Session(engine) as session:
        # Get the winner record that was just created
        winner = session.query(Winner).filter(
            Winner.id == target.id
        ).first()

        if not winner:
            return

        # Get the event details
        event = session.query(Event).filter(
            Event.id == winner.event_id
        ).first()

        if not event:
            return

        # Get the registration details
        registration = session.query(EventRegistration).filter(
            EventRegistration.id == winner.registration_id
        ).first()

        if not registration:
            return

        # Determine who won (individual or team)
        if registration.user_id:
            # Individual winner
            user = session.query(User).filter(
                User.id == registration.user_id
            ).first()

            if user:
                # Notify the winner
                create_system_notification(
                    session,
                    user.id,
                    f"Congratulations! You won in {event.event_name}",
                    f"Congratulations! You have been awarded {winner.position} place in {event.event_name}. " +
                    f"Prize: {winner.prize_details}",
                    "Event"
                )

                # Notify all other participants
                registrations = session.query(EventRegistration).filter(
                    EventRegistration.event_id == event.id,
                    EventRegistration.id != registration.id
                ).all()

                for reg in registrations:
                    if reg.user_id:
                        create_system_notification(
                            session,
                            reg.user_id,
                            f"Winner Announced: {event.event_name}",
                            f"{user.username} has been awarded {winner.position} place in {event.event_name}.",
                            "Event"
                        )
                    elif reg.team_id:
                        team_members = session.query(TeamMember).filter(
                            TeamMember.team_id == reg.team_id
                        ).all()

                        for member in team_members:
                            create_system_notification(
                                session,
                                member.user_id,
                                f"Winner Announced: {event.event_name}",
                                f"{user.username} has been awarded {winner.position} place in {event.event_name}.",
                                "Event"
                            )

        elif registration.team_id:
            # Team winner
            team = session.query(Team).filter(
                Team.id == registration.team_id
            ).first()

            if team:
                # Notify all team members
                team_members = session.query(TeamMember).filter(
                    TeamMember.team_id == team.id
                ).all()

                for member in team_members:
                    create_system_notification(
                        session,
                        member.user_id,
                        f"Congratulations! Your team won in {event.event_name}",
                        f"Congratulations! Your team '{team.team_name}' has been awarded {winner.position} place " +
                        f"in {event.event_name}. Prize: {winner.prize_details}",
                        "Event"
                    )

                # Notify all other participants
                registrations = session.query(EventRegistration).filter(
                    EventRegistration.event_id == event.id,
                    EventRegistration.id != registration.id
                ).all()

                for reg in registrations:
                    if reg.user_id:
                        create_system_notification(
                            session,
                            reg.user_id,
                            f"Winner Announced: {event.event_name}",
                            f"Team '{team.team_name}' has been awarded {winner.position} place in {event.event_name}.",
                            "Event"
                        )
                    elif reg.team_id:
                        other_team_members = session.query(TeamMember).filter(
                            TeamMember.team_id == reg.team_id
                        ).all()

                        for member in other_team_members:
                            create_system_notification(
                                session,
                                member.user_id,
                                f"Winner Announced: {event.event_name}",
                                f"Team '{team.team_name}' has been awarded {winner.position} place in {event.event_name}.",
                                "Event"
                            )


# ==================== EXPENSE NOTIFICATIONS ====================

@event.listens_for(Expense, 'after_insert')
def notify_expense_created(mapper, connection, target):
    """
    Notify finance managers when a new expense is created.
    """
    with Session(engine) as session:
        # Get the expense that was just created
        expense = session.query(Expense).filter(
            Expense.id == target.id
        ).first()

        if not expense:
            return

        # Notify finance managers (users with approve_expenses permission)
        from models.rbac import Role, UserRole, RolePermission, Permission

        # Find the permission ID for approving expenses
        permission = session.query(Permission).filter(
            Permission.permission_name == "approve_expenses"
        ).first()

        if permission:
            # Find roles with this permission
            role_ids = session.query(RolePermission.role_id).filter(
                RolePermission.permission_id == permission.id
            ).all()

            if role_ids:
                # Find users with these roles
                role_ids = [r.role_id for r in role_ids]
                user_ids = session.query(UserRole.user_id).filter(
                    UserRole.role_id.in_(role_ids)
                ).distinct().all()

                # Get the creator's name
                creator = session.query(User).filter(
                    User.id == expense.created_by
                ).first()

                creator_name = creator.username if creator else "Unknown"

                # Notify each finance manager
                for user_record in user_ids:
                    # Skip notifying the creator if they are also an approver
                    if user_record.user_id == expense.created_by:
                        continue

                    create_system_notification(
                        session,
                        user_record.user_id,
                        "New Expense Requires Approval",
                        f"A new expense of {expense.amount} for {expense.expense_category} " +
                        f"has been submitted by {creator_name} and requires your approval.",
                        "Payment"
                    )

@event.listens_for(Expense, 'after_update')
def notify_expense_status_change(mapper, connection, target):
    """
    Notify expense creator when their expense status changes.
    """
    with Session(engine) as session:
        # Get the expense that was updated
        expense = session.query(Expense).filter(
            Expense.id == target.id
        ).first()

        if not expense:
            return

        # Only notify if the status has changed to Approved or Rejected
        if expense.approval_status == "Approved":
            # Get the approver's name
            approver = session.query(User).filter(
                User.id == expense.approved_by
            ).first()

            approver_name = approver.username if approver else "An administrator"

            create_system_notification(
                session,
                expense.created_by,
                "Expense Approved",
                f"Your expense of {expense.amount} for {expense.expense_category} " +
                f"has been approved by {approver_name}.",
                "Payment"
            )
        elif expense.approval_status == "Rejected":
            # Get the approver's name
            approver = session.query(User).filter(
                User.id == expense.approved_by
            ).first()

            approver_name = approver.username if approver else "An administrator"

            create_system_notification(
                session,
                expense.created_by,
                "Expense Rejected",
                f"Your expense of {expense.amount} for {expense.expense_category} " +
                f"has been rejected by {approver_name}. Please contact them for more information.",
                "Payment"
            )


# ==================== SPONSORSHIP NOTIFICATIONS ====================

@event.listens_for(SponsorshipContract, 'after_insert')
def notify_sponsorship_contract_created(mapper, connection, target):
    """
    Notify finance managers when a new sponsorship contract is created.
    """
    with Session(engine) as session:
        # Get the contract that was just created
        contract = session.query(SponsorshipContract).filter(
            SponsorshipContract.id == target.id
        ).first()

        if not contract:
            return

        # Get the sponsor details
        from models.sponsorship import Sponsor, SponsorshipPackage

        sponsor = session.query(Sponsor).filter(
            Sponsor.id == contract.sponsor_id
        ).first()

        package = session.query(SponsorshipPackage).filter(
            SponsorshipPackage.id == contract.package_id
        ).first()

        if not sponsor or not package:
            return

        # Notify finance managers (users with manage_sponsorships permission)
        from models.rbac import Role, UserRole, RolePermission, Permission

        # Find the permission ID for managing sponsorships
        permission = session.query(Permission).filter(
            Permission.permission_name == "manage_sponsorships"
        ).first()

        if permission:
            # Find roles with this permission
            role_ids = session.query(RolePermission.role_id).filter(
                RolePermission.permission_id == permission.id
            ).all()

            if role_ids:
                # Find users with these roles
                role_ids = [r.role_id for r in role_ids]
                user_ids = session.query(UserRole.user_id).filter(
                    UserRole.role_id.in_(role_ids)
                ).distinct().all()

                # Get the creator's name
                creator = session.query(User).filter(
                    User.id == contract.created_by
                ).first()

                creator_name = creator.username if creator else "Unknown"

                # Notify each sponsorship manager
                for user_record in user_ids:
                    # Skip notifying the creator if they are also a manager
                    if user_record.user_id == contract.created_by:
                        continue

                    create_system_notification(
                        session,
                        user_record.user_id,
                        "New Sponsorship Contract",
                        f"A new sponsorship contract has been created with {sponsor.company_name} " +
                        f"for the {package.package_name} package by {creator_name}. " +
                        f"Total amount: {contract.total_amount}, Status: {contract.status}",
                        "Sponsorship"
                    )