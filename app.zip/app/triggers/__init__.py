"""
Notification triggers initialization module.

This module imports all the notification triggers to ensure they are registered
with SQLAlchemy when the application starts.
"""

# Import all triggers to register them
from .notification_triggers import (
    # Event Registration Notifications
    notify_event_registration,
    
    # Payment Notifications
    notify_payment_status_change,
    
    # Team Notifications
    notify_team_member_added,
    
    # Accommodation Notifications
    notify_accommodation_request,
    notify_accommodation_request_status_change,
    notify_room_allocation,
    
    # Event Schedule Notifications
    notify_event_schedule,
    
    # Winner Notifications
    notify_winner_announcement,
    
    # Expense Notifications
    notify_expense_created,
    notify_expense_status_change,
    
    # Sponsorship Notifications
    notify_sponsorship_contract_created
)

# This function can be called from the main application to ensure all triggers are registered
def register_all_triggers():
    """
    Register all notification triggers with SQLAlchemy.
    
    This function doesn't actually need to do anything since the import statements
    above will register the triggers, but it provides a clear entry point for the
    main application to ensure triggers are registered.
    """
    print("All notification triggers registered successfully.")
