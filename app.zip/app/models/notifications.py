# models/notifications.py
import uuid
from sqlalchemy import (
    Column, Text, String, ForeignKey, Enum, Boolean,
    TIMESTAMP, text, Integer, Index, event
)
from sqlalchemy.orm import relationship, validates
from db.session import Base
from datetime import datetime

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(100), nullable=False)
    message = Column(Text, nullable=False)
    notification_type = Column(
        Enum('System', 'Event', 'Payment', 'Accommodation', 'Sponsorship',
             name='notification_type_enum'),
        nullable=False
    )
    is_read = Column(Boolean, default=False)
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Relationships
    user = relationship("User", back_populates="notifications")

    # Indexes for faster querying
    __table_args__ = (
        Index('idx_notification_user_created', user_id, created_at.desc()),
        Index('idx_notification_type', notification_type),
    )

    @validates('title')
    def validate_title(self, key, value):
        if not value or len(value.strip()) == 0:
            raise ValueError("Title cannot be empty")
        if len(value) > 100:
            raise ValueError("Title cannot exceed 100 characters")
        return value.strip()

class Announcement(Base):
    __tablename__ = "announcements"

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(100), nullable=False)
    content = Column(Text, nullable=False)
    target_audience = Column(
        Enum('All', 'Participants', 'Organizers', 'Sponsors', 'Judges',
             name='audience_type_enum'),
        nullable=False
    )
    event_id = Column(Integer, ForeignKey("events.id", ondelete="SET NULL"), nullable=True)
    published_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    published_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    is_active = Column(Boolean, default=True)

    # Relationships
    event = relationship("Event", back_populates="announcements")
    publisher = relationship("User", back_populates="published_announcements")

    # Indexes and constraints
    __table_args__ = (
        Index('idx_announcement_published', published_at.desc()),
        Index('idx_announcement_audience', target_audience),
    )

    @validates('title', 'content')
    def validate_announcement(self, key, value):
        if not value or len(value.strip()) == 0:
            raise ValueError(f"{key} cannot be empty")
        if key == 'title' and len(value) > 100:
            raise ValueError("Title cannot exceed 100 characters")
        return value.strip()

# Event listener for automatic notification creation when an announcement is published
@event.listens_for(Announcement, 'after_insert')
def create_notifications(mapper, connection, target):
    """
    Create notifications for relevant users based on the announcement's target_audience

    This function is called automatically after a new announcement is inserted into the database.
    It creates notifications for users based on the target audience of the announcement.
    """
    from sqlalchemy.orm import Session
    from db.session import engine
    from models.rbac import User, Role, UserRole
    from models.events import EventRegistration, TeamMember

    # Create a new session for this operation
    with Session(engine) as session:
        # Get the announcement that was just created
        announcement = session.query(Announcement).filter(Announcement.id == target.id).first()
        if not announcement:
            return

        # Get the title and content for the notification
        title = f"New Announcement: {announcement.title}"
        message = announcement.content

        # Determine which users should receive the notification based on target_audience
        user_ids = []

        if announcement.target_audience == 'All':
            # Get all active users
            users = session.query(User.id).filter(User.is_active == True).all()
            user_ids = [user.id for user in users]

        elif announcement.target_audience == 'Participants':
            # If the announcement is for a specific event
            if announcement.event_id:
                # Get all users registered for this event (directly or via team)
                # Direct registrations
                direct_registrations = session.query(EventRegistration.user_id)\
                    .filter(
                        EventRegistration.event_id == announcement.event_id,
                        EventRegistration.user_id != None
                    ).all()
                direct_user_ids = [reg.user_id for reg in direct_registrations]

                # Team registrations
                team_registrations = session.query(EventRegistration.team_id)\
                    .filter(
                        EventRegistration.event_id == announcement.event_id,
                        EventRegistration.team_id != None
                    ).all()
                team_ids = [reg.team_id for reg in team_registrations]

                # Get all team members
                team_members = session.query(TeamMember.user_id)\
                    .filter(TeamMember.team_id.in_(team_ids))\
                    .all()
                team_user_ids = [member.user_id for member in team_members]

                # Combine both sets of user IDs
                user_ids = list(set(direct_user_ids + team_user_ids))
            else:
                # If no specific event, get all users who have registered for any event
                registered_users = session.query(EventRegistration.user_id)\
                    .filter(EventRegistration.user_id != None)\
                    .distinct().all()
                direct_user_ids = [reg.user_id for reg in registered_users]

                # Get all team members
                team_members = session.query(TeamMember.user_id).distinct().all()
                team_user_ids = [member.user_id for member in team_members]

                # Combine both sets of user IDs
                user_ids = list(set(direct_user_ids + team_user_ids))

        elif announcement.target_audience == 'Organizers':
            # Get all users with organizer role
            organizer_role = session.query(Role.id).filter(Role.role_name == 'Organizer').first()
            if organizer_role:
                organizers = session.query(UserRole.user_id)\
                    .filter(UserRole.role_id == organizer_role.id)\
                    .all()
                user_ids = [org.user_id for org in organizers]

        elif announcement.target_audience == 'Sponsors':
            # Get all users with sponsor role
            sponsor_role = session.query(Role.id).filter(Role.role_name == 'Sponsor').first()
            if sponsor_role:
                sponsors = session.query(UserRole.user_id)\
                    .filter(UserRole.role_id == sponsor_role.id)\
                    .all()
                user_ids = [sponsor.user_id for sponsor in sponsors]

        elif announcement.target_audience == 'Judges':
            # Get all users with judge role
            judge_role = session.query(Role.id).filter(Role.role_name == 'Judge').first()
            if judge_role:
                judges = session.query(UserRole.user_id)\
                    .filter(UserRole.role_id == judge_role.id)\
                    .all()
                user_ids = [judge.user_id for judge in judges]

        # Create notifications for each user
        for user_id in user_ids:
            # Skip creating a notification for the publisher
            if user_id == announcement.published_by:
                continue

            notification = Notification(
                user_id=user_id,
                title=title,
                message=message,
                notification_type='System' if announcement.event_id is None else 'Event',
                is_read=False
            )
            session.add(notification)

        # Commit all the new notifications
        try:
            session.commit()
        except Exception:
            session.rollback()
