from sqlalchemy import (
    Column, Integer, String, Text, DECIMAL, ForeignKey, Enum, 
    TIMESTAMP, UniqueConstraint, text, BINARY, CheckConstraint
)
from sqlalchemy.orm import relationship, validates
from db.session import Base
from datetime import datetime

class JudgeAssignment(Base):
    __tablename__ = "judge_assignments"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    schedule_id = Column(Integer, ForeignKey("event_schedule.id", ondelete="CASCADE"), nullable=False)
    assigned_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(Enum('Active', 'Inactive', 'Completed', name='judge_status_enum'), default='Active')
    assigned_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    
    # Relationships
    judge = relationship("User", foreign_keys=[user_id], back_populates="judge_assignments")
    assigner = relationship("User", foreign_keys=[assigned_by], back_populates="assigned_judges")
    event = relationship("Event", back_populates="judge_assignments")
    schedule = relationship("EventSchedule", back_populates="judge_assignments")
    
    __table_args__ = (
        UniqueConstraint('user_id', 'schedule_id', name='uix_judge_schedule'),
    )

class EvaluationCriteria(Base):
    __tablename__ = "evaluation_criteria"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    criteria_name = Column(String(100), nullable=False)
    description = Column(Text)
    max_score = Column(DECIMAL(5, 2), nullable=False)
    weight = Column(DECIMAL(3, 2), default=1.00)
    
    # Relationships
    event = relationship("Event", back_populates="evaluation_criteria")
    scores = relationship("Score", back_populates="criteria")
    
    __table_args__ = (
        UniqueConstraint('event_id', 'criteria_name', name='uix_event_criteria'),
        CheckConstraint('max_score > 0', name='check_max_score_positive'),
        CheckConstraint('weight > 0 AND weight <= 1', name='check_weight_range')
    )

    @validates('max_score', 'weight')
    def validate_criteria(self, key, value):
        if key == 'max_score' and float(value) <= 0:
            raise ValueError("max_score must be positive")
        if key == 'weight' and (float(value) <= 0 or float(value) > 1):
            raise ValueError("weight must be between 0 and 1")
        return value

class Score(Base):
    __tablename__ = "scores"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    judge_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    registration_id = Column(Integer, ForeignKey("event_registrations.id", ondelete="CASCADE"), nullable=False)
    criteria_id = Column(Integer, ForeignKey("evaluation_criteria.id", ondelete="CASCADE"), nullable=False)
    schedule_id = Column(Integer, ForeignKey("event_schedule.id", ondelete="CASCADE"), nullable=False)
    score_value = Column(DECIMAL(5, 2), nullable=False)
    comments = Column(Text)
    submitted_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    
    # Relationships
    registration = relationship("EventRegistration", back_populates="scores")
    criteria = relationship("EvaluationCriteria", back_populates="scores")
    judge = relationship(
        "User",
        back_populates="given_scores",
        foreign_keys=[judge_id]
    )
    schedule = relationship("EventSchedule", back_populates="scores")
    
    __table_args__ = (
        UniqueConstraint('registration_id', 'criteria_id', 'judge_id', 'schedule_id', name='uix_score'),
        CheckConstraint('score_value >= 0', name='check_score_positive')
    )

    @validates('score_value')
    def validate_score(self, key, value):
        if float(value) < 0:
            raise ValueError("score_value cannot be negative")
        # Check if score is within criteria max_score
        if hasattr(self, 'criteria') and float(value) > float(self.criteria.max_score):
            raise ValueError(f"score_value cannot exceed criteria max_score of {self.criteria.max_score}")
        return value

class Winner(Base):
    __tablename__ = "winners"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    registration_id = Column(Integer, ForeignKey("event_registrations.id", ondelete="CASCADE"), nullable=False)
    declared_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    position = Column(Integer, nullable=False)
    prize_description = Column(Text)
    declared_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    
    # Relationships
    event = relationship("Event", back_populates="winners")
    registration = relationship("EventRegistration", back_populates="winner_info")
    declarer = relationship("User", back_populates="declared_winners")
    
    __table_args__ = (
        UniqueConstraint('event_id', 'position', name='uix_event_position'),
        CheckConstraint('position > 0', name='check_position_positive')
    )

    @validates('position')
    def validate_position(self, key, value):
        if value <= 0:
            raise ValueError("position must be positive")
        return value
