# models/events.py
import uuid
from sqlalchemy import (
    Column, Integer, String, Text, DECIMAL, DateTime, Boolean, 
    ForeignKey, Enum, TIMESTAMP, CheckConstraint, UniqueConstraint, 
    text, BINARY
)
from sqlalchemy.orm import relationship
from db.session import Base

class EventCategory(Base):
    __tablename__ = "event_categories"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    category_name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    
    # Relationships
    events = relationship("Event", back_populates="category")

class Event(Base):
    __tablename__ = "events"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_name = Column(String(100), nullable=False)
    description = Column(Text)
    rules = Column(Text)
    max_participants = Column(Integer, nullable=False)
    registration_fee = Column(DECIMAL(10, 2), nullable=False)
    registration_deadline = Column(DateTime, nullable=False)
    category_id = Column(Integer, ForeignKey("event_categories.id"), nullable=False)
    is_team_event = Column(Boolean, default=False)
    min_team_size = Column(Integer, default=1)
    max_team_size = Column(Integer, default=1)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP(3)"))
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Relationships
    category = relationship("EventCategory", back_populates="events")
    creator = relationship("User", back_populates="created_events")
    schedules = relationship("EventSchedule", back_populates="event")
    teams = relationship("Team", back_populates="event")
    registrations = relationship("EventRegistration", back_populates="event")
    judge_assignments = relationship("JudgeAssignment", back_populates="event")
    evaluation_criteria = relationship("EvaluationCriteria", back_populates="event")
    winners = relationship("Winner", back_populates="event")
    announcements = relationship("Announcement", back_populates="event")

class Venue(Base):
    __tablename__ = "venues"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    venue_name = Column(String(100), nullable=False)
    location = Column(String(255), nullable=False)
    capacity = Column(Integer, nullable=False)
    description = Column(Text)
    venue_type = Column(Enum('Auditorium', 'Hall', 'Lab', 'Outdoor', name='venue_type'), nullable=False)
    
    # Relationships
    schedules = relationship("EventSchedule", back_populates="venue")

class EventSchedule(Base):
    __tablename__ = "event_schedule"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    venue_id = Column(Integer, ForeignKey("venues.id", ondelete="CASCADE"), nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    round_name = Column(Enum('Preliminary', 'Semi-Final', 'Final', name='round_types'), nullable=False)
    
    # Relationships
    event = relationship("Event", back_populates="schedules")
    venue = relationship("Venue", back_populates="schedules")
    judge_assignments = relationship("JudgeAssignment", back_populates="schedule")
    scores = relationship("Score", back_populates="schedule")

class Team(Base):
    __tablename__ = "teams"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    team_name = Column(String(100), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP(3)"))
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Relationships
    event = relationship("Event", back_populates="teams")
    creator = relationship("User", back_populates="created_teams")
    members = relationship("TeamMember", back_populates="team")
    registrations = relationship("EventRegistration", back_populates="team")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('team_name', 'event_id', name='uix_team_name_event'),
    )

class TeamMember(Base):
    __tablename__ = "team_members"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    team_id = Column(Integer, ForeignKey("teams.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    is_team_lead = Column(Boolean, default=False)
    joined_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP(3)"))
    
    # Relationships
    team = relationship("Team", back_populates="members")
    user = relationship("User", back_populates="team_memberships")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('team_id', 'user_id', name='uix_team_user'),
    )

class EventRegistration(Base):
    __tablename__ = "event_registrations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=True)
    team_id = Column(Integer, ForeignKey("teams.id", ondelete="CASCADE"), nullable=True)
    registration_date = Column(DateTime, server_default=text("CURRENT_TIMESTAMP(3)"))
    payment_status = Column(Enum('Pending', 'Paid', 'Cancelled', name='payment_status_types'), default='Pending')
    confirmation_code = Column(String(50), unique=True)
    
    # Relationships
    event = relationship("Event", back_populates="registrations")
    participant = relationship(  # Changed from "user" to "participant"
        "User",
        back_populates="event_registrations",
        foreign_keys=[user_id]
    )
    team = relationship("Team", back_populates="registrations")
    scores = relationship("Score", back_populates="registration")
    winner_info = relationship("Winner", back_populates="registration")
    payments = relationship("Payment", back_populates="registration")
    
    # Constraints
    __table_args__ = (
        CheckConstraint('(user_id IS NULL AND team_id IS NOT NULL) OR (user_id IS NOT NULL AND team_id IS NULL)',
                        name='check_user_or_team'),
    )