from db.session import Base
from .rbac import Permission, Role, User, UserRole,RolePermission
from .events import EventCategory, Event, Venue, EventSchedule, Team, TeamMember, EventRegistration
from .judging import JudgeAssignment, EvaluationCriteria, Score, Winner
from .sponsorship import SponsorshipPackage, Sponsor, SponsorshipContract, SponsorshipPayment
from .accommodation import AccommodationFacility, RoomType, Room, AccommodationRequest, RoomAllocation
from .finance import Payment, FinancialReport, Expense
from .notifications import Notification, Announcement