# models/accommodation.py
import uuid
from sqlalchemy import (
    Column, DateTime, Integer, String, Text, DECIMAL, Date, ForeignKey, 
    Enum, TIMESTAMP, CheckConstraint, UniqueConstraint, text, event
)
from sqlalchemy.orm import relationship, validates
from db.session import Base
from datetime import datetime, date

class AccommodationFacility(Base):
    __tablename__ = "accommodation_facilities"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    facility_name = Column(String(100), nullable=False)
    address = Column(Text, nullable=False)
    total_rooms = Column(Integer, nullable=False)
    contact_person = Column(String(100))
    contact_number = Column(String(20))
    description = Column(Text)
    
    # Relationships
    room_types = relationship("RoomType", back_populates="facility")
    rooms = relationship("Room", back_populates="facility")
    accommodation_requests = relationship("AccommodationRequest", back_populates="preferred_facility")

class RoomType(Base):
    __tablename__ = "room_types"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    facility_id = Column(Integer, ForeignKey("accommodation_facilities.id", ondelete="CASCADE"), nullable=False)
    type_name = Column(String(50), nullable=False)
    description = Column(Text)
    capacity = Column(Integer, nullable=False)
    price_per_night = Column(DECIMAL(8, 2), nullable=False)
    amenities = Column(Text)
    
    # Relationships
    facility = relationship("AccommodationFacility", back_populates="room_types")
    rooms = relationship("Room", back_populates="room_type")
    accommodation_requests = relationship("AccommodationRequest", back_populates="preferred_room_type")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('facility_id', 'type_name', name='uix_facility_type'),
    )

class Room(Base):
    __tablename__ = "rooms"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    facility_id = Column(Integer, ForeignKey("accommodation_facilities.id", ondelete="CASCADE"), nullable=False)
    room_type_id = Column(Integer, ForeignKey("room_types.id", ondelete="CASCADE"), nullable=False)
    room_number = Column(String(20), nullable=False)
    status = Column(Enum('Available', 'Occupied', 'Maintenance', name='room_status_types'), default='Available')
    capacity = Column(Integer, nullable=False,default=1)
    # Relationships
    facility = relationship("AccommodationFacility", back_populates="rooms")
    room_type = relationship("RoomType", back_populates="rooms")
    allocations = relationship("RoomAllocation", back_populates="room")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('facility_id', 'room_number', name='uix_facility_room'),
    )

class AccommodationRequest(Base):
    __tablename__ = "accommodation_requests"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    check_in_date = Column(Date, nullable=False)
    check_out_date = Column(Date, nullable=False)
    number_of_people = Column(Integer, nullable=False)
    preferred_facility_id = Column(Integer, ForeignKey("accommodation_facilities.id"), nullable=True)
    preferred_room_type_id = Column(Integer, ForeignKey("room_types.id"), nullable=True)
    special_requests = Column(Text)
    status = Column(Enum('Pending', 'Approved', 'Rejected', 'Cancelled', name='accommodation_status_types'), default='Pending')
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    
    # Relationships
    requester = relationship("User", back_populates="accommodation_requests")
    preferred_facility = relationship("AccommodationFacility", back_populates="accommodation_requests")
    preferred_room_type = relationship("RoomType", back_populates="accommodation_requests")
    allocation = relationship("RoomAllocation", back_populates="request", uselist=False)
    
    # Constraints
    __table_args__ = (
        CheckConstraint('check_out_date > check_in_date', name='check_dates'),
    )

    @validates('check_in_date', 'check_out_date', 'number_of_people')
    def validate_request(self, key, value):
        if key in ('check_in_date', 'check_out_date'):
            if isinstance(value, date) and value < date.today():
                raise ValueError(f"{key} cannot be in the past")
            if key == 'check_out_date' and hasattr(self, 'check_in_date'):
                if value <= self.check_in_date:
                    raise ValueError("check_out_date must be after check_in_date")
        elif key == 'number_of_people':
            if value <= 0:
                raise ValueError("number_of_people must be positive")
        return value

class RoomAllocation(Base):
    __tablename__ = "room_allocations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    request_id = Column(Integer, ForeignKey("accommodation_requests.id", ondelete="CASCADE"), nullable=False, unique=True)
    room_id = Column(Integer, ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False)
    check_in_time = Column(TIMESTAMP, nullable=True)
    check_out_time = Column(TIMESTAMP, nullable=True)
    total_cost = Column(DECIMAL(10, 2), nullable=False)
    payment_status = Column(Enum('Pending', 'Paid', 'Cancelled', name='allocation_payment_status_types'), default='Pending')
    allocated_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    allocated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    
    # Relationships
    request = relationship("AccommodationRequest", back_populates="allocation")
    room = relationship("Room", back_populates="allocations")
    allocator = relationship("User", back_populates="allocated_rooms")
    # Add relationship to payments
    payments = relationship(
        "Payment",
        back_populates="room_allocation",
        primaryjoin="and_(RoomAllocation.id==Payment.accommodation_id, "
                   "Payment.payment_type=='Accommodation')"
    )


# Add event listener to check room availability
@event.listens_for(RoomAllocation, 'before_insert')
def check_room_availability(mapper, connection, target):
    stmt = text("""
        SELECT COUNT(*) FROM room_allocations 
        WHERE room_id = :room_id 
        AND (
            (:check_in BETWEEN check_in_time AND check_out_time)
            OR (:check_out BETWEEN check_in_time AND check_out_time)
        )
    """)
    
    result = connection.execute(
        stmt,
        {
            'room_id': target.room_id,  # No need for str conversion with integers
            'check_in': target.check_in_time,
            'check_out': target.check_out_time
        }
    ).scalar()
    
    if result > 0:
        raise ValueError("Room is not available for the selected dates")