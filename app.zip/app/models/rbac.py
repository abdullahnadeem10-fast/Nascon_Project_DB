# models/rbac.py
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, ForeignKey, 
    UniqueConstraint, TIMESTAMP, text, Boolean, event, Index
)
from sqlalchemy.orm import relationship, validates
from db.session import Base

class Permission(Base):
    __tablename__ = "permissions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    permission_name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Relationships with overlaps
    role_permissions = relationship("RolePermission", back_populates="permission")
    roles = relationship("Role", secondary="role_permissions", back_populates="permissions", overlaps="role_permissions")

    # Validations
    @validates('permission_name')
    def validate_permission(self, key, value):
        if not value or len(value.strip()) == 0:
            raise ValueError("permission_name cannot be empty")
        if len(value) > 100:
            raise ValueError("permission_name cannot exceed 100 characters")
        return value.strip()

class Role(Base):
    __tablename__ = "roles"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    role_name = Column(String(50), nullable=False, unique=True)
    description = Column(Text)
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Relationships with overlaps
    user_roles = relationship("UserRole", back_populates="role")
    users = relationship("User", secondary="user_roles", back_populates="roles", overlaps="user_roles")
    role_permissions = relationship("RolePermission", back_populates="role")
    permissions = relationship("Permission", secondary="role_permissions", back_populates="roles", overlaps="role_permissions")

    @validates('role_name')
    def validate_role(self, key, value):
        if not value or len(value.strip()) == 0:
            raise ValueError("role_name cannot be empty")
        if len(value) > 50:
            raise ValueError("role_name cannot exceed 50 characters")
        return value.strip()

class RolePermission(Base):
    __tablename__ = "role_permissions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    role_id = Column(Integer, ForeignKey("roles.id", ondelete="CASCADE"), nullable=False)
    permission_id = Column(Integer, ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Relationships with overlaps
    role = relationship("Role", back_populates="role_permissions", overlaps="permissions,roles")
    permission = relationship("Permission", back_populates="role_permissions", overlaps="permissions,roles")

    # Add unique constraint
    __table_args__ = (
        UniqueConstraint('role_id', 'permission_id', name='uix_role_permission'),
    )

class BlacklistedToken(Base):
    __tablename__ = "blacklisted_tokens"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    token = Column(String(500), nullable=False, unique=True)
    expires_at = Column(DateTime, nullable=False)
    blacklisted_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Add index for faster token lookup and automatic cleanup
    __table_args__ = (
        Index('idx_token_expiry', 'expires_at'),
    )

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), nullable=False, unique=True)
    password = Column(String(255), nullable=False)
    email = Column(String(100), nullable=False, unique=True)
    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    phone_number = Column(String(20))
    address = Column(Text)
    university = Column(String(100))
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP(3)"))
    last_login = Column(DateTime, nullable=True, server_default=text("CURRENT_TIMESTAMP(3)"))
    is_active = Column(Boolean, default=True)
    
    # Relationships
    judge_assignments = relationship(
        "JudgeAssignment",
        foreign_keys="[JudgeAssignment.user_id]",
        back_populates="judge"
    )
    assigned_judges = relationship(
        "JudgeAssignment",
        foreign_keys="[JudgeAssignment.assigned_by]",
        back_populates="assigner"
    )

    # Other existing relationships...
    user_roles = relationship("UserRole", back_populates="user")
    roles = relationship("Role", secondary="user_roles", back_populates="users", overlaps="user_roles")
    payments_made = relationship(
        "Payment",
        foreign_keys="[Payment.user_id]",
        back_populates="user"
    )
    payments_received = relationship(
        "Payment",
        foreign_keys="[Payment.received_by]",
        back_populates="receiver"
    )
    event_registrations = relationship(
        "EventRegistration",
        back_populates="participant",  # Changed from "user" to "participant"
        foreign_keys="[EventRegistration.user_id]"
    )
    created_events = relationship("Event", back_populates="creator")
    created_teams = relationship("Team", back_populates="creator")
    declared_winners = relationship("Winner", back_populates="declarer")
    created_contracts = relationship("SponsorshipContract", back_populates="creator")
    received_payments = relationship("SponsorshipPayment", back_populates="receiver")
    allocated_rooms = relationship("RoomAllocation", back_populates="allocator")
    created_expenses = relationship("Expense", foreign_keys="Expense.created_by", back_populates="creator")
    approved_expenses = relationship("Expense", foreign_keys="Expense.approved_by", back_populates="approver")
    generated_reports = relationship("FinancialReport", back_populates="generator")
    published_announcements = relationship("Announcement", back_populates="publisher")
    accommodation_requests = relationship("AccommodationRequest", back_populates="requester")
    team_memberships = relationship("TeamMember", back_populates="user")
    notifications = relationship("Notification", back_populates="user")

    # Add scoring relationships
    given_scores = relationship(
        "Score",
        back_populates="judge",
        foreign_keys="[Score.judge_id]"
    )

    @validates('username', 'email', 'first_name', 'last_name', 'phone_number')
    def validate_user(self, key, value):
        if key in ('username', 'email', 'first_name', 'last_name') and (not value or len(value.strip()) == 0):
            raise ValueError(f"{key} cannot be empty")
        
        if key == 'username':
            if len(value) > 50:
                raise ValueError("username cannot exceed 50 characters")
            if not value.isalnum():
                raise ValueError("username must be alphanumeric")
        
        elif key == 'email':
            if len(value) > 100:
                raise ValueError("email cannot exceed 100 characters")
            if '@' not in value:
                raise ValueError("invalid email format")
        
        elif key in ('first_name', 'last_name'):
            if len(value) > 50:
                raise ValueError(f"{key} cannot exceed 50 characters")
        
        elif key == 'phone_number' and value:
            if len(value) > 20:
                raise ValueError("phone_number cannot exceed 20 characters")
            if not value.replace('+', '').replace('-', '').isdigit():
                raise ValueError("invalid phone number format")
        
        return value.strip() if isinstance(value, str) else value

class UserRole(Base):
    __tablename__ = "user_roles"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    role_id = Column(Integer, ForeignKey("roles.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Add relationships
    user = relationship("User", back_populates="user_roles")
    role = relationship("Role", back_populates="user_roles")

    # Add unique constraint
    __table_args__ = (
        UniqueConstraint('user_id', 'role_id', name='uix_user_role'),
    )

