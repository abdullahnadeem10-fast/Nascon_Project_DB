from sqlalchemy import (
    Column, Integer, String, Text, DECIMAL, Date, ForeignKey,
    Enum, TIMESTAMP, CheckConstraint, text
)
from sqlalchemy.orm import relationship, validates
from db.session import Base
from datetime import date

class SponsorshipPackage(Base):
    __tablename__ = "sponsorship_packages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    package_name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    price = Column(DECIMAL(10, 2), nullable=False)
    benefits = Column(Text)
    max_sponsors = Column(Integer)

    # Relationships
    contracts = relationship("SponsorshipContract", back_populates="package")

    @validates('package_name', 'price', 'max_sponsors')
    def validate_package(self, key, value):
        if key == 'package_name':
            if not value or len(value.strip()) == 0:
                raise ValueError("package_name cannot be empty")
            if len(value) > 100:
                raise ValueError("package_name cannot exceed 100 characters")
            return value.strip()
        elif key == 'price':
            if float(value) <= 0:
                raise ValueError("price must be positive")
            return value
        elif key == 'max_sponsors':
            if value and value <= 0:
                raise ValueError("max_sponsors must be positive")
            return value

class Sponsor(Base):
    __tablename__ = "sponsors"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(100), nullable=False)
    contact_person_name = Column(String(100), nullable=False)
    email = Column(String(100), nullable=False)
    phone_number = Column(String(20), nullable=False)
    address = Column(Text)
    logo_url = Column(Text)  # Changed from String(255) to Text to accommodate large base64 encoded images
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Relationships
    contracts = relationship("SponsorshipContract", back_populates="sponsor")

    @validates('company_name', 'contact_person_name', 'email', 'phone_number')
    def validate_sponsor(self, key, value):
        if not value or len(value.strip()) == 0:
            raise ValueError(f"{key} cannot be empty")

        if key in ['company_name', 'contact_person_name'] and len(value) > 100:
            raise ValueError(f"{key} cannot exceed 100 characters")
        elif key == 'email':
            if len(value) > 100:
                raise ValueError("email cannot exceed 100 characters")
            if '@' not in value:
                raise ValueError("invalid email format")
        elif key == 'phone_number':
            if len(value) > 20:
                raise ValueError("phone_number cannot exceed 20 characters")
            if not value.replace('+', '').replace('-', '').isdigit():
                raise ValueError("invalid phone number format")
        return value.strip()

class SponsorshipContract(Base):
    __tablename__ = "sponsorship_contracts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sponsor_id = Column(Integer, ForeignKey("sponsors.id", ondelete="CASCADE"), nullable=False)
    package_id = Column(Integer, ForeignKey("sponsorship_packages.id", ondelete="CASCADE"), nullable=False)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    status = Column(Enum('Pending', 'Active', 'Completed', 'Cancelled', name='contract_status_types'), default='Pending')
    payment_status = Column(Enum('Pending', 'Partial', 'Completed', name='contract_payment_status_types'), default='Pending')
    total_amount = Column(DECIMAL(10, 2), nullable=False)
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    # Relationships
    sponsor = relationship("Sponsor", back_populates="contracts")
    package = relationship("SponsorshipPackage", back_populates="contracts")
    creator = relationship("User", back_populates="created_contracts")
    # Update relationship name to be more specific
    sponsorship_payments = relationship(
        "SponsorshipPayment",
        back_populates="contract",
        cascade="all, delete-orphan"
    )
    # General payments relationship remains unchanged
    payments = relationship("Payment", back_populates="sponsorship")

    __table_args__ = (
        CheckConstraint('end_date > start_date', name='check_end_date_greater_start_date'),
    )

class SponsorshipPayment(Base):
    __tablename__ = "sponsorship_payments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    contract_id = Column(Integer, ForeignKey("sponsorship_contracts.id", ondelete="CASCADE"), nullable=False)
    amount = Column(DECIMAL(10, 2), nullable=False)
    payment_date = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    payment_method = Column(Enum('Bank Transfer', 'Credit Card', 'Cash', 'Check', name='payment_method_types'), nullable=False)
    transaction_reference = Column(String(100))
    received_by = Column(Integer, ForeignKey("users.id"), nullable=False)

    # Relationships
    # Update relationship to match new name
    contract = relationship(
        "SponsorshipContract",
        back_populates="sponsorship_payments"  # Changed from "payments" to "sponsorship_payments"
    )
    receiver = relationship("User", back_populates="received_payments")

