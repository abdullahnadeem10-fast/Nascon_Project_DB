# models/finance.py
import uuid
from enum import Enum as PyEnum
from sqlalchemy import (
    Column, Integer, String, Text, DECIMAL, Date, DateTime, ForeignKey, 
    Enum, JSON, TIMESTAMP, text, event, BINARY
)
from sqlalchemy.orm import relationship, validates
from db.session import Base
from datetime import datetime

# Import related models
from .events import EventRegistration
from .accommodation import AccommodationRequest  
from .sponsorship import SponsorshipContract

class ExpenseCategory(PyEnum):
    VENUE = "Venue"
    CATERING = "Catering"
    MARKETING = "Marketing"
    EQUIPMENT = "Equipment"
    TRANSPORT = "Transport"
    MISCELLANEOUS = "Miscellaneous"

class Payment(Base):
    __tablename__ = "payments"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sponsorship_id = Column(Integer, ForeignKey("sponsorship_contracts.id", ondelete="CASCADE"), nullable=True)
    accommodation_id = Column(Integer, ForeignKey("room_allocations.id"), nullable=True)
    payment_type = Column(Enum('Registration', 'Accommodation', 'Sponsorship', name='payment_type_enum'), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    received_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    registration_id = Column(Integer, ForeignKey("event_registrations.id", ondelete="CASCADE"), nullable=True)
    transaction_id = Column(String(50), nullable=False, unique=True)  # Changed from BINARY to String for readability
    amount = Column(DECIMAL(10, 2), nullable=False)
    payment_date = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    payment_method = Column(Enum('Online', 'Bank Transfer', 'Cash', 'Credit Card', name='payment_method_enum'), nullable=False)
    status = Column(Enum('Pending', 'Completed', 'Failed', 'Refunded', name='payment_status_enum'), default='Pending')
    notes = Column(Text)

    # Update relationships
    user = relationship(
        "User",
        foreign_keys=[user_id],
        back_populates="payments_made"
    )
    receiver = relationship(
        "User",
        foreign_keys=[received_by],
        back_populates="payments_received"
    )
    registration = relationship("EventRegistration", back_populates="payments")
    # Update accommodation relationship
    room_allocation = relationship(
        "RoomAllocation",
        back_populates="payments",
        foreign_keys=[accommodation_id]
    )
    # Update sponsorship relationship
    sponsorship = relationship(
        "SponsorshipContract", 
        back_populates="payments",
        foreign_keys=[sponsorship_id]  # Now sponsorship_id is defined
    )

    @validates('payment_type', 'registration_id', 'accommodation_id', 'sponsorship_id')
    def validate_payment_relations(self, key, value):
        if key == 'payment_type':
            self._payment_type = value
            return value
        
        if key == 'registration_id' and value and self._payment_type != 'Registration':
            raise ValueError("registration_id can only be set for Registration payment type")
        if key == 'accommodation_id' and value and self._payment_type != 'Accommodation':
            raise ValueError("accommodation_id can only be set for Accommodation payment type")
        if key == 'sponsorship_id' and value and self._payment_type != 'Sponsorship':
            raise ValueError("sponsorship_id can only be set for Sponsorship payment type")
        return value

class FinancialReport(Base):
    __tablename__ = "financial_reports"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    report_name = Column(String(100), nullable=False)
    report_type = Column(Enum('Daily', 'Weekly', 'Monthly', 'Event-specific', 'Custom', name='report_type_enum'), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    total_income = Column(DECIMAL(12, 2), nullable=False)
    total_expense = Column(DECIMAL(12, 2), nullable=False)
    net_profit = Column(DECIMAL(12, 2), nullable=False)
    report_data = Column(JSON)
    generated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    generated_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Relationships
    generator = relationship("User", back_populates="generated_reports")

    @validates('start_date', 'end_date')
    def validate_dates(self, key, value):
        if key == 'start_date':
            self._start_date = value
            return value
        if key == 'end_date':
            if value < self._start_date:
                raise ValueError("end_date cannot be before start_date")
            return value

class Expense(Base):
    __tablename__ = "expenses"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    expense_category = Column(
        Enum(ExpenseCategory, name='expense_category_enum', 
             values_callable=lambda obj: [e.value for e in obj]),
        nullable=False
    )
    description = Column(Text, nullable=False)
    amount = Column(DECIMAL(10, 2), nullable=False)
    expense_date = Column(Date, nullable=False)
    receipt_url = Column(String(255))
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approval_status = Column(Enum('Pending', 'Approved', 'Rejected', name='approval_status_enum'), default='Pending')
    
    # Relationships
    creator = relationship("User", foreign_keys=[created_by], back_populates="created_expenses")
    approver = relationship("User", foreign_keys=[approved_by], back_populates="approved_expenses")

    @validates('expense_date')
    def validate_expense_date(self, key, value):
        if value > datetime.now().date():
            raise ValueError("Expense date cannot be in the future")
        return value

