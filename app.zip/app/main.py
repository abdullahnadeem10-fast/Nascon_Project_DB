from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import permissions, roles, roles_permissions, users
from api.routes.Accomodations import accommodation, room_types, room, accomodation_requests
from api.routes.Accomodations import allocation
from api.routes.Events import EventCategory, Events, Venue, EventSchedule, Team, TeamMember, EventRegistration
from api.routes.Finance import payment_router, financial_report_router, expense_router
from api.routes.Judging import judge_assignment_router, evaluation_criteria_router, score_router, winner_router
from api.routes.notifications import notification_router, announcement_router
from api.routes.sponsorship import package_router, sponsor_router, contract_router, payment_router as sponsorship_payment_router
from db.session import Base, engine, get_db
from core.permissions import ensure_admin_role_exists
from crud.rbac.user import create_user, get_user_by_username
from schemas.rbac.user import UserCreate
import models
from triggers import register_all_triggers

app = FastAPI()

# Create the database tables
Base.metadata.create_all(bind=engine)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Add frontend origins here
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

@app.on_event("startup")
async def startup_event():
    # Get a database session
    db = next(get_db())
    try:
        # Ensure Admin role exists with all permissions
        ensure_admin_role_exists(db)

        # Create default admin user if it doesn't exist
        admin = get_user_by_username(db, "Admin")
        if not admin:
            admin_user = UserCreate(
                username="Admin",
                email="admin@nascon.com",
                password="password123",
                first_name="Admin",
                last_name="User",
                phone_number=None,
                address=None,
                university=None
            )
            admin = create_user(db, admin_user)
            # Assign admin role to the user
            roles = db.query(models.Role).filter(models.Role.role_name == "Admin").first()
            models.UserRole(user_id=admin.id, role_id=roles.id)
            db.commit()

        # Register all notification triggers
        register_all_triggers()
        print("Notification system initialized successfully.")
    finally:
        db.close()

# Register the routers with correct prefixes and tags
app.include_router(roles.router, prefix="/api/v1", tags=["roles"])
app.include_router(permissions.router, prefix="/api/v1", tags=["permissions"])
app.include_router(roles_permissions.router, prefix="/api/v1", tags=["roles_permissions"])
app.include_router(users.router, prefix="/api/v1", tags=["users"])
app.include_router(accommodation.router, prefix="/api/v1", tags=["accommodation"])
app.include_router(room_types.router, prefix="/api/v1", tags=["room_types"])
app.include_router(room.router, prefix="/api/v1", tags=["room"])
app.include_router(accomodation_requests.router, prefix="/api/v1", tags=["accommodation_requests"])
app.include_router(allocation.router, prefix="/api/v1", tags=["Room Allocations"])
app.include_router(EventCategory.router, prefix="/api/v1", tags=["event_categories"])
app.include_router(Events.router, prefix="/api/v1", tags=["events"])
app.include_router(Venue.router, prefix="/api/v1", tags=["venues"])
app.include_router(EventSchedule.router, prefix="/api/v1", tags=["event_schedules"])
app.include_router(Team.router, prefix="/api/v1", tags=["teams"])
app.include_router(TeamMember.router, prefix="/api/v1", tags=["team_members"])
app.include_router(payment_router, prefix="/api/v1", tags=["payments"])
app.include_router(financial_report_router, prefix="/api/v1", tags=["financial_reports"])
app.include_router(expense_router, prefix="/api/v1", tags=["expenses"])
app.include_router(EventRegistration.router, prefix="/api/v1", tags=["event_registrations"])
app.include_router(judge_assignment_router, prefix="/api/v1")
app.include_router(evaluation_criteria_router, prefix="/api/v1")
app.include_router(score_router, prefix="/api/v1")
app.include_router(winner_router, prefix="/api/v1")
app.include_router(notification_router, prefix="/api/v1", tags=["notifications"])
app.include_router(announcement_router, prefix="/api/v1", tags=["announcements"])
app.include_router(package_router, prefix="/api/v1/sponsorship", tags=["sponsorship_packages"])
app.include_router(sponsor_router, prefix="/api/v1/sponsorship", tags=["sponsors"])
app.include_router(contract_router, prefix="/api/v1/sponsorship", tags=["sponsorship_contracts"])
app.include_router(sponsorship_payment_router, prefix="/api/v1/sponsorship", tags=["sponsorship_payments"])

