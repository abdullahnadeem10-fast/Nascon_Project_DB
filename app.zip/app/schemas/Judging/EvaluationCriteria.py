from typing import Optional, List, Dict
from pydantic import BaseModel, Field, validator
from decimal import Decimal

# Base model for shared attributes
class EvaluationCriteriaBase(BaseModel):
    event_id: int
    criteria_name: str
    description: Optional[str] = None
    max_score: Decimal = Field(gt=0)
    weight: Decimal = Field(gt=0, le=1, default=1.00)

    @validator('max_score')
    def validate_max_score(cls, v):
        if v <= 0:
            raise ValueError('max_score must be positive')
        return v

    @validator('weight')
    def validate_weight(cls, v):
        if v <= 0 or v > 1:
            raise ValueError('weight must be between 0 and 1')
        return v

# Model for creating an evaluation criteria
class EvaluationCriteriaCreate(EvaluationCriteriaBase):
    pass

# Model for updating an evaluation criteria
class EvaluationCriteriaUpdate(BaseModel):
    criteria_name: Optional[str] = None
    description: Optional[str] = None
    max_score: Optional[Decimal] = Field(None, gt=0)
    weight: Optional[Decimal] = Field(None, gt=0, le=1)

    @validator('max_score')
    def validate_max_score(cls, v):
        if v is not None and v <= 0:
            raise ValueError('max_score must be positive')
        return v

    @validator('weight')
    def validate_weight(cls, v):
        if v is not None and (v <= 0 or v > 1):
            raise ValueError('weight must be between 0 and 1')
        return v

# Model for API responses
class EvaluationCriteria(EvaluationCriteriaBase):
    id: int
    
    class Config:
        from_attributes = True

# Response with message
class EvaluationCriteriaResponse(BaseModel):
    message: str
    criteria: EvaluationCriteria
    
    class Config:
        from_attributes = True

# Evaluation criteria list response
class EvaluationCriteriaList(BaseModel):
    criteria: List[EvaluationCriteria]
    total: int
    
    class Config:
        from_attributes = True

# Evaluation criteria with event details
class EvaluationCriteriaWithEvent(EvaluationCriteria):
    event_name: str
    
    class Config:
        from_attributes = True

# Evaluation criteria with event details list response
class EvaluationCriteriaWithEventList(BaseModel):
    criteria: List[EvaluationCriteriaWithEvent]
    total: int
    
    class Config:
        from_attributes = True
