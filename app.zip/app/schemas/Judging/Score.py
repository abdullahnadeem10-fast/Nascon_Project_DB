from typing import Optional, List, Dict
from pydantic import BaseModel, Field, validator
from datetime import datetime
from decimal import Decimal

# Base model for shared attributes
class ScoreBase(BaseModel):
    judge_id: int
    registration_id: int
    criteria_id: int
    schedule_id: int
    score_value: Decimal = Field(ge=0)
    comments: Optional[str] = None

    @validator('score_value')
    def validate_score_value(cls, v):
        if v < 0:
            raise ValueError('score_value cannot be negative')
        return v

# Model for creating a score
class ScoreCreate(ScoreBase):
    pass

# Model for updating a score
class ScoreUpdate(BaseModel):
    score_value: Optional[Decimal] = Field(None, ge=0)
    comments: Optional[str] = None

    @validator('score_value')
    def validate_score_value(cls, v):
        if v is not None and v < 0:
            raise ValueError('score_value cannot be negative')
        return v

# Model for API responses
class Score(ScoreBase):
    id: int
    submitted_at: datetime
    
    class Config:
        from_attributes = True

# Response with message
class ScoreResponse(BaseModel):
    message: str
    score: Score
    
    class Config:
        from_attributes = True

# Score list response
class ScoreList(BaseModel):
    scores: List[Score]
    total: int
    
    class Config:
        from_attributes = True

# Score with details
class ScoreDetail(Score):
    judge_name: str
    participant_name: str
    event_name: str
    criteria_name: str
    max_score: Decimal
    schedule_date: datetime
    
    class Config:
        from_attributes = True

# Score detail list response
class ScoreDetailList(BaseModel):
    scores: List[ScoreDetail]
    total: int
    
    class Config:
        from_attributes = True

# Batch score submission
class BatchScoreCreate(BaseModel):
    registration_id: int
    schedule_id: int
    scores: List[Dict]  # List of {criteria_id, score_value, comments}

# Batch score response
class BatchScoreResponse(BaseModel):
    message: str
    scores: List[Score]
    
    class Config:
        from_attributes = True

# Score summary for a participant
class ParticipantScoreSummary(BaseModel):
    registration_id: int
    participant_name: str
    event_name: str
    total_score: Decimal
    average_score: Decimal
    judge_count: int
    criteria_scores: Dict[str, Decimal]  # Criteria name to average score
    rank: Optional[int] = None
    
    class Config:
        from_attributes = True

# Score summary list
class ParticipantScoreSummaryList(BaseModel):
    summaries: List[ParticipantScoreSummary]
    total: int
    
    class Config:
        from_attributes = True
