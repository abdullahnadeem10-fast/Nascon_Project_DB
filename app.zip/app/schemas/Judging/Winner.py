from typing import Optional, List
from pydantic import BaseModel, Field, validator
from datetime import datetime

# Base model for shared attributes
class WinnerBase(BaseModel):
    event_id: int
    registration_id: int
    position: int = Field(gt=0)
    prize_description: Optional[str] = None

    @validator('position')
    def validate_position(cls, v):
        if v <= 0:
            raise ValueError('position must be positive')
        return v

# Model for creating a winner
class WinnerCreate(WinnerBase):
    pass

# Model for updating a winner
class WinnerUpdate(BaseModel):
    registration_id: Optional[int] = None
    position: Optional[int] = Field(None, gt=0)
    prize_description: Optional[str] = None

    @validator('position')
    def validate_position(cls, v):
        if v is not None and v <= 0:
            raise ValueError('position must be positive')
        return v

# Model for API responses
class Winner(WinnerBase):
    id: int
    declared_by: int
    declared_at: datetime
    
    class Config:
        from_attributes = True

# Response with message
class WinnerResponse(BaseModel):
    message: str
    winner: Winner
    
    class Config:
        from_attributes = True

# Winner list response
class WinnerList(BaseModel):
    winners: List[Winner]
    total: int
    
    class Config:
        from_attributes = True

# Winner with details
class WinnerDetail(Winner):
    event_name: str
    participant_name: str
    declarer_name: str
    total_score: Optional[float] = None
    
    class Config:
        from_attributes = True

# Winner detail list response
class WinnerDetailList(BaseModel):
    winners: List[WinnerDetail]
    total: int
    
    class Config:
        from_attributes = True

# Batch winner declaration
class BatchWinnerCreate(BaseModel):
    event_id: int
    winners: List[dict]  # List of {registration_id, position, prize_description}
