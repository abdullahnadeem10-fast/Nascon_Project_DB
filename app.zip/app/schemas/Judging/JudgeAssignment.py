from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

# Enum for judge status
class JudgeStatus(str, Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"
    COMPLETED = "Completed"

# Base model for shared attributes
class JudgeAssignmentBase(BaseModel):
    user_id: int
    event_id: int
    schedule_id: int

# Model for creating a judge assignment
class JudgeAssignmentCreate(JudgeAssignmentBase):
    pass

# Model for updating a judge assignment
class JudgeAssignmentUpdate(BaseModel):
    status: Optional[JudgeStatus] = None

# Model for API responses
class JudgeAssignment(JudgeAssignmentBase):
    id: int
    assigned_by: int
    status: JudgeStatus
    assigned_at: datetime
    
    class Config:
        from_attributes = True

# Response with message
class JudgeAssignmentResponse(BaseModel):
    message: str
    assignment: JudgeAssignment
    
    class Config:
        from_attributes = True

# Judge assignment list response
class JudgeAssignmentList(BaseModel):
    assignments: List[JudgeAssignment]
    total: int
    
    class Config:
        from_attributes = True

# Extended judge assignment with related data
class JudgeAssignmentDetail(JudgeAssignment):
    judge_name: str
    event_name: str
    schedule_date: datetime
    assigner_name: str
    
    class Config:
        from_attributes = True

# Judge assignment detail list response
class JudgeAssignmentDetailList(BaseModel):
    assignments: List[JudgeAssignmentDetail]
    total: int
    
    class Config:
        from_attributes = True
