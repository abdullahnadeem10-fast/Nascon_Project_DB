from pydantic import BaseModel, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum

class TargetAudience(str, Enum):
    ALL = "All"
    PARTICIPANTS = "Participants"
    ORGANIZERS = "Organizers"
    SPONSORS = "Sponsors"
    JUDGES = "Judges"

# Base schema
class AnnouncementBase(BaseModel):
    title: str
    content: str
    target_audience: TargetAudience
    event_id: Optional[int] = None
    is_active: Optional[bool] = True

# Create schema
class AnnouncementCreate(AnnouncementBase):
    pass

# Update schema
class AnnouncementUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    target_audience: Optional[TargetAudience] = None
    event_id: Optional[int] = None
    is_active: Optional[bool] = None

    @validator('title')
    def validate_title(cls, v):
        if v is not None:
            if not v or len(v.strip()) == 0:
                raise ValueError("Title cannot be empty")
            if len(v) > 100:
                raise ValueError("Title cannot exceed 100 characters")
            return v.strip()
        return v

    @validator('content')
    def validate_content(cls, v):
        if v is not None:
            if not v or len(v.strip()) == 0:
                raise ValueError("Content cannot be empty")
            return v.strip()
        return v

# Response schema
class Announcement(AnnouncementBase):
    id: int
    published_at: datetime
    published_by: int

    class Config:
        from_attributes = True

# Response with publisher details
class AnnouncementWithPublisher(Announcement):
    publisher_name: str

    class Config:
        from_attributes = True

# Response models
class AnnouncementResponse(BaseModel):
    message: str
    announcement: Announcement

    class Config:
        from_attributes = True

class AnnouncementList(BaseModel):
    announcements: List[Announcement]
    total: int

    class Config:
        from_attributes = True
