from pydantic import BaseModel, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum

class NotificationType(str, Enum):
    SYSTEM = "System"
    EVENT = "Event"
    PAYMENT = "Payment"
    ACCOMMODATION = "Accommodation"
    SPONSORSHIP = "Sponsorship"

# Base schema
class NotificationBase(BaseModel):
    title: str
    message: str
    notification_type: NotificationType
    is_read: Optional[bool] = False

# Create schema
class NotificationCreate(NotificationBase):
    user_id: int

# Update schema
class NotificationUpdate(BaseModel):
    title: Optional[str] = None
    message: Optional[str] = None
    notification_type: Optional[NotificationType] = None
    is_read: Optional[bool] = None

    @validator('title')
    def validate_title(cls, v):
        if v is not None:
            if not v or len(v.strip()) == 0:
                raise ValueError("Title cannot be empty")
            if len(v) > 100:
                raise ValueError("Title cannot exceed 100 characters")
            return v.strip()
        return v

# Response schema
class Notification(NotificationBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Response models
class NotificationResponse(BaseModel):
    message: str
    notification: Notification

    class Config:
        from_attributes = True

class NotificationList(BaseModel):
    notifications: List[Notification]
    total: int
    unread_count: int

    class Config:
        from_attributes = True
