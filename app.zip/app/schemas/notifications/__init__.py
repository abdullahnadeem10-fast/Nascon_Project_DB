# Import schemas for easier access
from .Notification import (
    NotificationType,
    NotificationBase,
    NotificationCreate,
    NotificationUpdate,
    Notification,
    NotificationResponse,
    NotificationList
)

from .Announcement import (
    TargetAudience,
    AnnouncementBase,
    AnnouncementCreate,
    AnnouncementUpdate,
    Announcement,
    AnnouncementWithPublisher,
    AnnouncementResponse,
    AnnouncementList
)
