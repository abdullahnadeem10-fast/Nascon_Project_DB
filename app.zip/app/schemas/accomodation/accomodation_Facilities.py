from typing import Optional, List, ForwardRef
from pydantic import BaseModel, constr, Field
from datetime import datetime

# Base model for shared attributes
class AccommodationFacilityBase(BaseModel):
    facility_name: str
    address: str
    total_rooms: int = Field(gt=0)
    contact_person: Optional[str] = None
    contact_number: Optional[str] = None
    description: Optional[str] = None

# Model for creating a facility
class AccommodationFacilityCreate(AccommodationFacilityBase):
    pass

# Model for updating a facility - all fields optional
class AccommodationFacilityUpdate(BaseModel):
    facility_name: Optional[str] = None
    address: Optional[str] = None
    total_rooms: Optional[int] = Field(None, gt=0)
    contact_person: Optional[str] = None
    contact_number: Optional[str] = None
    description: Optional[str] = None

# Model for API responses
class AccommodationFacility(AccommodationFacilityBase):
    id: int

    class Config:
        from_attributes = True
class AccommodationFacilityResponse(BaseModel):
    message: str
    facility: AccommodationFacility

    class Config:
        orm_mode = True