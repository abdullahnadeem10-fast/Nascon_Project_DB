from typing import Optional
from pydantic import BaseModel, Field
from decimal import Decimal

# Base model for shared attributes
class RoomTypeBase(BaseModel):
    type_name: str
    description: Optional[str] = None
    capacity: int = Field(gt=0)
    price_per_night: Decimal = Field(gt=0, decimal_places=2)
    amenities: Optional[str] = None
    facility_id: int

# Model for creating a room type
class RoomTypeCreate(RoomTypeBase):
    pass

# Model for updating a room type - all fields optional
class RoomTypeUpdate(BaseModel):
    type_name: Optional[str] = None
    description: Optional[str] = None
    capacity: Optional[int] = Field(None, gt=0)
    price_per_night: Optional[Decimal] = Field(None, gt=0, decimal_places=2)
    amenities: Optional[str] = None
    facility_id: Optional[int] = None

# Model for API responses
class RoomType(RoomTypeBase):
    id: int

    class Config:
        from_attributes = True

class RoomTypeResponse(BaseModel):
    message: str
    room_type: RoomType

    class Config:
        from_attributes = True