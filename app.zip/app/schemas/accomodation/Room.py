from typing import Optional
from pydantic import BaseModel, Field
from decimal import Decimal
from .accomodation_Facilities import AccommodationFacility
from .room_type import RoomType

class RoomBase(BaseModel):
    room_number: str
    status: str
    capacity: int 

class RoomCreate(RoomBase):
    facility_id: int
    room_type_id: int

class RoomUpdate(BaseModel):
    status: Optional[str] = None
    capacity: Optional[int] = None

class RoomOut(RoomBase):
    id: int
    facility: AccommodationFacility
    room_type: RoomType
    facility_id: int
    room_type_id: int

    class Config:
        from_attributes = True
