from datetime import datetime
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, validator
from enum import Enum

class PaymentStatusEnum(str, Enum):
    PENDING = 'Pending'
    PAID = 'Paid'
    CANCELLED = 'Cancelled'

class RoomAllocationBase(BaseModel):
    request_id: int
    room_id: int
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    total_cost: Decimal
    payment_status: PaymentStatusEnum = PaymentStatusEnum.PENDING


class RoomAllocationCreate(RoomAllocationBase):
    allocated_by: int

class RoomAllocationResponse(RoomAllocationBase):
    id: int
    allocated_by: int
    allocated_at: datetime

    class Config:
        orm_mode = True