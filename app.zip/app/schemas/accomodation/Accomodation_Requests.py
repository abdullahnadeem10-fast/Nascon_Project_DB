from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, validator
from enum import Enum

class AccommodationStatus(str, Enum):
    PENDING = "Pending"
    APPROVED = "Approved"
    REJECTED = "Rejected"
    CANCELLED = "Cancelled"

class AccommodationRequestBase(BaseModel):
    check_in_date: date
    check_out_date: date
    number_of_people: int
    preferred_facility_id: Optional[int] = None
    preferred_room_type_id: Optional[int] = None
    special_requests: Optional[str] = None

    @validator('number_of_people')
    def validate_number_of_people(cls, v):
        if v <= 0:
            raise ValueError("Number of people must be positive")
        return v

class AccommodationRequestCreate(AccommodationRequestBase):
    pass

class AccommodationRequestUpdate(BaseModel):
    check_in_date: Optional[date] = None
    check_out_date: Optional[date] = None
    number_of_people: Optional[int] = None
    preferred_facility_id: Optional[int] = None
    preferred_room_type_id: Optional[int] = None
    special_requests: Optional[str] = None
    status: Optional[AccommodationStatus] = None

    @validator('number_of_people')
    def validate_number_of_people(cls, v):
        if v is not None and v <= 0:
            raise ValueError("Number of people must be positive")
        return v

class AccommodationRequestResponse(AccommodationRequestBase):
    id: int
    user_id: int
    user_name: str  # Added username field
    status: AccommodationStatus
    created_at: datetime

    class Config:
        from_attributes = True

# Response with message
class AccommodationRequestWithMessage(BaseModel):
    message: str
    request: AccommodationRequestResponse

    class Config:
        from_attributes = True