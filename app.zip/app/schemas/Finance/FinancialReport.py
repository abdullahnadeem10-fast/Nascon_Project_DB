from typing import Optional, List, Dict, Any
from pydantic import BaseModel, condecimal, validator
from datetime import datetime, date
from enum import Enum

# Enum for report types
class ReportType(str, Enum):
    DAILY = "Daily"
    WEEKLY = "Weekly"
    MONTHLY = "Monthly"
    EVENT = "Event"
    CUSTOM = "Custom"

# Base model for shared attributes
class FinancialReportBase(BaseModel):
    report_name: str
    report_type: ReportType
    start_date: date
    end_date: date
    event_id: Optional[int] = None
    total_income: float
    total_expense: float
    net_profit: float
    report_data: Optional[Dict[str, Any]] = None

    @validator('end_date')
    def end_date_must_be_after_start_date(cls, v, values):
        if 'start_date' in values and v < values['start_date']:
            raise ValueError('end_date cannot be before start_date')
        return v

    @validator('net_profit')
    def validate_net_profit(cls, v, values):
        if 'total_income' in values and 'total_expense' in values:
            calculated_profit = values['total_income'] - values['total_expense']
            if v != calculated_profit:
                raise ValueError('net_profit must equal total_income - total_expense')
        return v

# Model for creating a financial report
class FinancialReportCreate(FinancialReportBase):
    generated_by: int

# Model for updating a financial report
class FinancialReportUpdate(BaseModel):
    report_name: Optional[str] = None
    report_type: Optional[ReportType] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    event_id: Optional[int] = None
    total_income: Optional[float] = None
    total_expense: Optional[float] = None
    net_profit: Optional[float] = None
    report_data: Optional[Dict[str, Any]] = None

# Model for API responses
class FinancialReport(FinancialReportBase):
    id: int
    generated_at: datetime
    generated_by: int

    class Config:
        from_attributes = True

# Response with message
class FinancialReportResponse(BaseModel):
    message: str
    report: FinancialReport

    class Config:
        from_attributes = True

# Financial report list response
class FinancialReportList(BaseModel):
    reports: List[FinancialReport]
    total: int
    
    class Config:
        from_attributes = True

# Financial report with generator details
class FinancialReportWithGenerator(FinancialReport):
    generator_username: str
    generator_name: str
    
    class Config:
        from_attributes = True
