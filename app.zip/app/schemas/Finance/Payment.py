from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

# Enum for payment methods
class PaymentMethod(str, Enum):
    CASH = "Cash"
    CREDIT_CARD = "Credit Card"
    DEBIT_CARD = "Debit Card"
    BANK_TRANSFER = "Bank Transfer"
    ONLINE_PAYMENT = "Online Payment"

# Enum for payment status
class PaymentStatus(str, Enum):
    PENDING = "Pending"
    COMPLETED = "Completed"
    FAILED = "Failed"
    REFUNDED = "Refunded"

# Enum for payment types
class PaymentType(str, Enum):
    EVENT_REGISTRATION = "Event Registration"
    ACCOMMODATION = "Accommodation"
    MERCHANDISE = "Merchandise"
    SPONSORSHIP = "Sponsorship"
    OTHER = "Other"

# Base model for shared attributes
class PaymentBase(BaseModel):
    amount: float
    payment_method: PaymentMethod
    payment_type: PaymentType
    registration_id: Optional[int] = None  # ID of the related entity (e.g., registration_id, accommodation_id)
    notes: Optional[str] = None
    user_id: int

# Model for creating a payment
class PaymentCreate(PaymentBase):
    pass

# Model for updating a payment
class PaymentUpdate(BaseModel):
    amount: Optional[float] = None
    payment_method: Optional[PaymentMethod] = None
    payment_type: Optional[PaymentType] = None
    registration_id: Optional[int] = None
    notes: Optional[str] = None
    status: Optional[PaymentStatus] = None
    transaction_id: Optional[str] = None

# Model for API responses
class Payment(PaymentBase):
    id: int
    status: PaymentStatus
    transaction_id: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Response with message
class PaymentResponse(BaseModel):
    message: str
    payment: Payment

    class Config:
        from_attributes = True

# Payment list response
class PaymentList(BaseModel):
    payments: List[Payment]
    total: int

    class Config:
        from_attributes = True

# Payment summary
class PaymentSummary(BaseModel):
    total_amount: float
    completed_amount: float
    pending_amount: float
    payment_count: int
    completed_count: int
    pending_count: int
