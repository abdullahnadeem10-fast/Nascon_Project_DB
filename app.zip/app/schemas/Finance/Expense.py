from typing import Optional, List
from pydantic import BaseModel, Field
from datetime import datetime, date
from enum import Enum

# Enum for expense categories
class ExpenseCategory(str, Enum):
    VENUE = "Venue"
    CATERING = "Catering"
    MARKETING = "Marketing"
    EQUIPMENT = "Equipment"
    TRANSPORT = "Transport"
    MISCELLANEOUS = "Miscellaneous"

# Enum for approval status
class ApprovalStatus(str, Enum):
    PENDING = "Pending"
    APPROVED = "Approved"
    REJECTED = "Rejected"

# Base model for shared attributes
class ExpenseBase(BaseModel):
    expense_category: ExpenseCategory
    description: str
    amount: float = Field(gt=0)
    expense_date: date
    receipt_url: Optional[str] = None

# Model for creating an expense
class ExpenseCreate(ExpenseBase):
    pass

# Model for updating an expense
class ExpenseUpdate(BaseModel):
    expense_category: Optional[ExpenseCategory] = None
    description: Optional[str] = None
    amount: Optional[float] = Field(None, gt=0)
    expense_date: Optional[date] = None
    receipt_url: Optional[str] = None

# Model for API responses
class Expense(ExpenseBase):
    id: int
    created_by: int
    created_at: datetime
    approved_by: Optional[int] = None
    approval_status: ApprovalStatus

    class Config:
        from_attributes = True

# Response with message
class ExpenseResponse(BaseModel):
    message: str
    expense: Expense

    class Config:
        from_attributes = True

# Expense list response
class ExpenseList(BaseModel):
    expenses: List[Expense]
    total: int
    
    class Config:
        from_attributes = True

# Expense summary
class ExpenseSummary(BaseModel):
    total_amount: float
    approved_amount: float
    pending_amount: float
    rejected_amount: float
    expense_count: int
    approved_count: int
    pending_count: int
    rejected_count: int
    by_category: dict
