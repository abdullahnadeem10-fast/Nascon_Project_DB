from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from .permission import Permission

# Base schemas
class RoleBase(BaseModel):
    role_name: str
    description: Optional[str] = None

# Create schemas
class RoleCreate(RoleBase):
    pass

class RolePermissionCreate(BaseModel):
    role_id: int
    permission_id: int

# Update schemas
class RoleUpdate(BaseModel):
    role_name: Optional[str] = None
    description: Optional[str] = None

# Response schemas
class Role(RoleBase):
    id: int
    created_at: datetime
    permissions: List[Permission] = []

    class Config:
        from_attributes = True

class RoleWithPermissions(Role):
    permissions: List[Permission]

    class Config:
        from_attributes = True

class RolePermission(BaseModel):
    role_id: int
    permission_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Response messages
class RoleResponse(BaseModel):
    message: str
    role: Role

