import uuid
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# Base schema
class PermissionBase(BaseModel):
    permission_name: str
    description: Optional[str] = None


# Create schema
class PermissionCreate(PermissionBase):
    pass

# Update schema
class PermissionUpdate(BaseModel):
    permission_name: Optional[str] = None
    description: Optional[str] = None


# Response schema
class Permission(PermissionBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Response messages
class PermissionResponse(BaseModel):
    permission: Permission
