from pydantic import BaseModel, EmailStr, constr, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum
from .role import Role

class UserRoleType(str, Enum):
    EVENT_ORGANIZER = "Event Organizer"
    PARTICIPANT = "Participant"
    SPONSOR = "Sponsor"
    JUDGE = "Judge"
    USER = "User"  # Default role

class UserBase(BaseModel):
    username: str
    email: EmailStr
    first_name: str
    last_name: str
    phone_number: Optional[str] = None
    address: Optional[str] = None
    university: Optional[str] = None

class UserCreate(UserBase):
    password: str
    role_type: UserRoleType = UserRoleType.USER

class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    address: Optional[str] = None
    university: Optional[str] = None
    password: Optional[str] = None
    is_active: Optional[bool] = None

class User(UserBase):
    id: int
    is_active: bool
    created_at: datetime
    roles: List[Role] = []

    class Config:
        from_attributes = True

class UserResponse(BaseModel):
    message: str
    user: User

    class Config:
        from_attributes = True

class UserRoleCreate(BaseModel):
    user_id: int
    role_id: int

    class Config:
        from_attributes = True
