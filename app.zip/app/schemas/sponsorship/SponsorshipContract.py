from pydantic import BaseModel, validator, Field
from typing import Optional, List
from datetime import datetime, date
from decimal import Decimal
from enum import Enum

# Enums for contract status and payment status
class ContractStatus(str, Enum):
    PENDING = "Pending"
    ACTIVE = "Active"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"

class ContractPaymentStatus(str, Enum):
    PENDING = "Pending"
    PARTIAL = "Partial"
    COMPLETED = "Completed"

# Base schema
class SponsorshipContractBase(BaseModel):
    sponsor_id: int
    package_id: int
    start_date: date
    end_date: date
    total_amount: Decimal = Field(gt=0)
    status: ContractStatus = ContractStatus.PENDING
    payment_status: ContractPaymentStatus = ContractPaymentStatus.PENDING

    @validator('end_date')
    def validate_end_date(cls, v, values):
        if 'start_date' in values and v <= values['start_date']:
            raise ValueError("end_date must be after start_date")
        return v

# Create schema
class SponsorshipContractCreate(SponsorshipContractBase):
    pass

# Update schema
class SponsorshipContractUpdate(BaseModel):
    sponsor_id: Optional[int] = None
    package_id: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    total_amount: Optional[Decimal] = None
    status: Optional[ContractStatus] = None
    payment_status: Optional[ContractPaymentStatus] = None

    @validator('end_date')
    def validate_end_date(cls, v, values):
        if v is not None and 'start_date' in values and values['start_date'] is not None and v <= values['start_date']:
            raise ValueError("end_date must be after start_date")
        return v

    @validator('total_amount')
    def validate_total_amount(cls, v):
        if v is not None and v <= 0:
            raise ValueError("total_amount must be positive")
        return v

# Response schema
class SponsorshipContract(SponsorshipContractBase):
    id: int
    created_by: int
    created_at: datetime

    class Config:
        from_attributes = True

# Response with related entities
class SponsorshipContractDetail(SponsorshipContract):
    sponsor_name: str
    package_name: str
    creator_name: str
    payments_total: Decimal
    payments_count: int

    class Config:
        from_attributes = True

# Response models
class SponsorshipContractResponse(BaseModel):
    message: str
    contract: SponsorshipContract

    class Config:
        from_attributes = True

class SponsorshipContractDetailResponse(BaseModel):
    message: str
    contract: SponsorshipContractDetail

    class Config:
        from_attributes = True

class SponsorshipContractList(BaseModel):
    contracts: List[SponsorshipContract]
    total: int

    class Config:
        from_attributes = True
