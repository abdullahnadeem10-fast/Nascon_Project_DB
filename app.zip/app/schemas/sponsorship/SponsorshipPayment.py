from pydantic import BaseModel, validator, Field
from typing import Optional, List
from datetime import datetime
from decimal import Decimal
from enum import Enum

# Enum for payment methods
class PaymentMethod(str, Enum):
    BANK_TRANSFER = "Bank Transfer"
    CREDIT_CARD = "Credit Card"
    CASH = "Cash"
    CHECK = "Check"

# Base schema
class SponsorshipPaymentBase(BaseModel):
    contract_id: int
    amount: Decimal = Field(gt=0)
    payment_method: PaymentMethod
    transaction_reference: Optional[str] = None

# Create schema
class SponsorshipPaymentCreate(SponsorshipPaymentBase):
    pass

# Update schema
class SponsorshipPaymentUpdate(BaseModel):
    amount: Optional[Decimal] = None
    payment_method: Optional[PaymentMethod] = None
    transaction_reference: Optional[str] = None

    @validator('amount')
    def validate_amount(cls, v):
        if v is not None and v <= 0:
            raise ValueError("amount must be positive")
        return v

# Response schema
class SponsorshipPayment(SponsorshipPaymentBase):
    id: int
    payment_date: datetime
    received_by: int

    class Config:
        from_attributes = True

# Response with related entities
class SponsorshipPaymentDetail(SponsorshipPayment):
    contract_reference: str
    sponsor_name: str
    receiver_name: str

    class Config:
        from_attributes = True

# Response models
class SponsorshipPaymentResponse(BaseModel):
    message: str
    payment: SponsorshipPayment

    class Config:
        from_attributes = True

class SponsorshipPaymentDetailResponse(BaseModel):
    message: str
    payment: SponsorshipPaymentDetail

    class Config:
        from_attributes = True

class SponsorshipPaymentList(BaseModel):
    payments: List[SponsorshipPayment]
    total: int
    total_amount: Decimal

    class Config:
        from_attributes = True
