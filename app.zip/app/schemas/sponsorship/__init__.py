# Import schemas for easier access
from .SponsorshipPackage import (
    SponsorshipPackageBase,
    SponsorshipPackageCreate,
    SponsorshipPackageUpdate,
    SponsorshipPackage,
    SponsorshipPackageWithStats,
    SponsorshipPackageResponse,
    SponsorshipPackageList
)

from .Sponsor import (
    SponsorBase,
    SponsorCreate,
    SponsorUpdate,
    Sponsor,
    SponsorWithStats,
    SponsorResponse,
    SponsorList
)

from .SponsorshipContract import (
    ContractStatus,
    ContractPaymentStatus,
    SponsorshipContractBase,
    SponsorshipContractCreate,
    SponsorshipContractUpdate,
    SponsorshipContract,
    SponsorshipContractDetail,
    SponsorshipContractResponse,
    SponsorshipContractDetailResponse,
    SponsorshipContractList
)

from .SponsorshipPayment import (
    PaymentMethod,
    SponsorshipPaymentBase,
    SponsorshipPaymentCreate,
    SponsorshipPaymentUpdate,
    SponsorshipPayment,
    SponsorshipPaymentDetail,
    SponsorshipPaymentResponse,
    SponsorshipPaymentDetailResponse,
    SponsorshipPaymentList
)
