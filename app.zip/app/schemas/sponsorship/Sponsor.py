from pydantic import BaseModel, validator, EmailStr
from typing import Optional, List
from datetime import datetime

# Base schema
class SponsorBase(BaseModel):
    company_name: str
    contact_person_name: str
    email: EmailStr
    phone_number: str
    address: Optional[str] = None
    logo_url: Optional[str] = None

    @validator('phone_number')
    def validate_phone_number(cls, v):
        if not v.replace('+', '').replace('-', '').isdigit():
            raise ValueError("invalid phone number format")
        return v

# Create schema
class SponsorCreate(SponsorBase):
    pass

# Update schema
class SponsorUpdate(BaseModel):
    company_name: Optional[str] = None
    contact_person_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone_number: Optional[str] = None
    address: Optional[str] = None
    logo_url: Optional[str] = None

    @validator('phone_number')
    def validate_phone_number(cls, v):
        if v is not None and not v.replace('+', '').replace('-', '').isdigit():
            raise ValueError("invalid phone number format")
        return v

# Response schema
class Sponsor(SponsorBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Response with contracts count
class SponsorWithStats(Sponsor):
    active_contracts: int
    total_contracts: int

    class Config:
        from_attributes = True

# Response models
class SponsorResponse(BaseModel):
    message: str
    sponsor: Sponsor

    class Config:
        from_attributes = True

class SponsorList(BaseModel):
    sponsors: List[Sponsor]
    total: int

    class Config:
        from_attributes = True
