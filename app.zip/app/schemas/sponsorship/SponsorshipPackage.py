from pydantic import BaseModel, validator, Field
from typing import Optional, List
from datetime import datetime
from decimal import Decimal

# Base schema
class SponsorshipPackageBase(BaseModel):
    package_name: str
    description: Optional[str] = None
    price: Decimal = Field(gt=0)
    benefits: Optional[str] = None
    max_sponsors: Optional[int] = None

    @validator('max_sponsors')
    def validate_max_sponsors(cls, v):
        if v is not None and v <= 0:
            raise ValueError("max_sponsors must be positive")
        return v

# Create schema
class SponsorshipPackageCreate(SponsorshipPackageBase):
    pass

# Update schema
class SponsorshipPackageUpdate(BaseModel):
    package_name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[Decimal] = None
    benefits: Optional[str] = None
    max_sponsors: Optional[int] = None

    @validator('price')
    def validate_price(cls, v):
        if v is not None and v <= 0:
            raise ValueError("price must be positive")
        return v

    @validator('max_sponsors')
    def validate_max_sponsors(cls, v):
        if v is not None and v <= 0:
            raise ValueError("max_sponsors must be positive")
        return v

# Response schema
class SponsorshipPackage(SponsorshipPackageBase):
    id: int

    class Config:
        from_attributes = True

# Response with contracts count
class SponsorshipPackageWithStats(SponsorshipPackage):
    active_contracts: int
    total_contracts: int

    class Config:
        from_attributes = True

# Response models
class SponsorshipPackageResponse(BaseModel):
    message: str
    package: SponsorshipPackage

    class Config:
        from_attributes = True

class SponsorshipPackageList(BaseModel):
    packages: List[SponsorshipPackage]
    total: int

    class Config:
        from_attributes = True
