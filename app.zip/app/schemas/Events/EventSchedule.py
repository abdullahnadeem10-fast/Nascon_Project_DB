from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

# Enum for round types
class RoundType(str, Enum):
    preliminary = "Preliminary"
    semifinal = "Semi-Final"
    final = "Final"

# Base model for shared attributes
class EventScheduleBase(BaseModel):
    event_id: int
    venue_id: int
    start_time: datetime
    end_time: datetime
    round_name: RoundType

# Model for creating a schedule
class EventScheduleCreate(EventScheduleBase):
    pass

# Model for updating a schedule - all fields optional
class EventScheduleUpdate(BaseModel):
    event_id: Optional[int] = None
    venue_id: Optional[int] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    round_name: Optional[RoundType] = None

# Model for API responses
class EventSchedule(EventScheduleBase):
    id: int

    class Config:
        from_attributes = True

# Response with message
class EventScheduleResponse(BaseModel):
    message: str
    schedule: EventSchedule

    class Config:
        from_attributes = True

# Schedule with event and venue names
class EventScheduleWithNames(EventSchedule):
    event_name: str
    venue_name: str

    class Config:
        from_attributes = True

# Schedule list response
class EventScheduleList(BaseModel):
    schedules: List[EventScheduleWithNames]
    total: int

    class Config:
        from_attributes = True

# Detailed schedule with event and venue information
class EventScheduleDetail(EventSchedule):
    event_name: str
    venue_name: str

    class Config:
        from_attributes = True
