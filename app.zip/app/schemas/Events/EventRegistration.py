from typing import Optional, List, Union
from pydantic import BaseModel, validator
from datetime import datetime
from enum import Enum

# Enum for payment status
class PaymentStatus(str, Enum):
    PENDING = "Pending"
    PAID = "Paid"
    CANCELLED = "Cancelled"

# Base model for shared attributes
class EventRegistrationBase(BaseModel):
    event_id: int
    user_id: Optional[int] = None
    team_id: Optional[int] = None
    payment_status: PaymentStatus = PaymentStatus.PENDING
    confirmation_code: Optional[str] = None

    @validator('user_id', 'team_id')
    def validate_user_or_team(cls, v, values):
        # Ensure either user_id or team_id is provided, but not both
        if 'user_id' in values and 'team_id' in values:
            if (values['user_id'] is None and v is None) or (values['user_id'] is not None and v is not None):
                raise ValueError("Either user_id or team_id must be provided, but not both")
        return v

# Model for creating a registration
class EventRegistrationCreate(EventRegistrationBase):
    pass

# Model for updating a registration
class EventRegistrationUpdate(BaseModel):
    payment_status: Optional[PaymentStatus] = None
    confirmation_code: Optional[str] = None

# Model for API responses
class EventRegistration(EventRegistrationBase):
    id: int
    registration_date: datetime

    class Config:
        from_attributes = True

# Response with message
class EventRegistrationResponse(BaseModel):
    message: str
    registration: EventRegistration

    class Config:
        from_attributes = True

# Registration with names
class EventRegistrationWithNames(EventRegistration):
    event_name: str
    user_name: Optional[str] = None
    team_name: Optional[str] = None

    class Config:
        from_attributes = True

# Registration list response
class EventRegistrationList(BaseModel):
    registrations: List[EventRegistration]
    total: int

    class Config:
        from_attributes = True

# Registration list with names response
class EventRegistrationWithNamesList(BaseModel):
    registrations: List[EventRegistrationWithNames]
    total: int

    class Config:
        from_attributes = True

# Detailed registration with event, user, and team information
class EventRegistrationDetail(EventRegistration):
    event_name: str
    user_name: Optional[str] = None
    team_name: Optional[str] = None

    class Config:
        from_attributes = True
