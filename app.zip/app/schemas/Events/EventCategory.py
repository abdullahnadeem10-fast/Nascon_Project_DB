from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime

# Base model for shared attributes
class EventCategoryBase(BaseModel):
    category_name: str
    description: Optional[str] = None

# Model for creating a category
class EventCategoryCreate(EventCategoryBase):
    pass

# Model for updating a category - all fields optional
class EventCategoryUpdate(BaseModel):
    category_name: Optional[str] = None
    description: Optional[str] = None

# Model for API responses
class EventCategory(EventCategoryBase):
    id: int

    class Config:
        from_attributes = True

# Response with message
class EventCategoryResponse(BaseModel):
    message: str
    category: EventCategory

    class Config:
        from_attributes = True
