from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime

# Base model for shared attributes
class TeamBase(BaseModel):
    team_name: str
    event_id: int

# Model for creating a team
class TeamCreate(TeamBase):
    pass

# Model for updating a team - all fields optional
class TeamUpdate(BaseModel):
    team_name: Optional[str] = None
    event_id: Optional[int] = None

# Model for API responses
class Team(TeamBase):
    id: int
    created_at: datetime
    created_by: int

    class Config:
        from_attributes = True

# Response with message
class TeamResponse(BaseModel):
    message: str
    team: Team

    class Config:
        from_attributes = True

# Team list response
class TeamList(BaseModel):
    teams: List[Team]
    total: int

    class Config:
        from_attributes = True

# Team member base model
class TeamMemberBase(BaseModel):
    team_id: int
    user_id: int
    is_team_lead: bool = False

# Team member create model
class TeamMemberCreate(TeamMemberBase):
    pass

# Team member update model
class TeamMemberUpdate(BaseModel):
    is_team_lead: Optional[bool] = None

# Team member response model
class TeamMember(TeamMemberBase):
    id: int
    joined_at: datetime

    class Config:
        from_attributes = True

# Team member response with message
class TeamMemberResponse(BaseModel):
    message: str
    member: TeamMember

    class Config:
        from_attributes = True

# Team with members response
class TeamWithMembers(Team):
    members: List[TeamMember] = []

    class Config:
        from_attributes = True
