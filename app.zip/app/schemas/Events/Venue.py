from typing import Optional, List
from pydantic import BaseModel, Field
from enum import Enum

# Enum for venue types
class VenueType(str, Enum):
    auditorium = "Auditorium"
    hall = "Hall"
    lab = "Lab"
    outdoor = "Outdoor"

# Base model for shared attributes
class VenueBase(BaseModel):
    venue_name: str
    location: str
    capacity: int
    description: Optional[str] = None
    venue_type: VenueType

# Model for creating a venue
class VenueCreate(VenueBase):
    pass

# Model for updating a venue - all fields optional
class VenueUpdate(BaseModel):
    venue_name: Optional[str] = None
    location: Optional[str] = None
    capacity: Optional[int] = None
    description: Optional[str] = None
    venue_type: Optional[VenueType] = None

# Model for API responses
class Venue(VenueBase):
    id: int

    class Config:
        from_attributes = True

# Response with message
class VenueResponse(BaseModel):
    message: str
    venue: Venue

    class Config:
        from_attributes = True

# Venue list response
class VenueList(BaseModel):
    venues: List[Venue]
    total: int
    
    class Config:
        from_attributes = True
