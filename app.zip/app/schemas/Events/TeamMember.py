from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime

# Base model for shared attributes
class TeamMemberBase(BaseModel):
    team_id: int
    user_id: int
    is_team_lead: bool = False

# Model for creating a team member
class TeamMemberCreate(TeamMemberBase):
    pass

# Model for updating a team member - only is_team_lead can be updated
class TeamMemberUpdate(BaseModel):
    is_team_lead: Optional[bool] = None

# Model for API responses
class TeamMember(TeamMemberBase):
    id: int
    joined_at: datetime

    class Config:
        from_attributes = True

# Response with message
class TeamMemberResponse(BaseModel):
    message: str
    member: TeamMember

    class Config:
        from_attributes = True

# Team member list response
class TeamMemberList(BaseModel):
    members: List[TeamMember]
    total: int
    
    class Config:
        from_attributes = True

# Extended team member with user details
class TeamMemberWithUser(TeamMember):
    username: str
    first_name: str
    last_name: str
    
    class Config:
        from_attributes = True
