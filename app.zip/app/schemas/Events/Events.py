from typing import Optional, List, Union
from pydantic import BaseModel, condecimal
from datetime import datetime

# Base model for shared attributes
class EventBase(BaseModel):
    event_name: str
    description: Optional[str] = None
    rules: Optional[str] = None
    max_participants: int
    registration_fee: float
    registration_deadline: datetime
    category_id: int
    is_team_event: bool = False
    min_team_size: int = 1
    max_team_size: int = 1

# Model for creating an event
class EventCreate(EventBase):
    pass

# Model for updating an event - all fields optional
class EventUpdate(BaseModel):
    event_name: Optional[str] = None
    description: Optional[str] = None
    rules: Optional[str] = None
    max_participants: Optional[int] = None
    registration_fee: Optional[float] = None
    registration_deadline: Optional[datetime] = None
    category_id: Optional[int] = None
    is_team_event: Optional[bool] = None
    min_team_size: Optional[int] = None
    max_team_size: Optional[int] = None

# Model for API responses
class Event(EventBase):
    id: int
    created_at: datetime
    created_by: int

    class Config:
        from_attributes = True

# Response with message
class EventResponse(BaseModel):
    message: str
    event: Event

    class Config:
        from_attributes = True

# Event list response
class EventList(BaseModel):
    events: List[Event]
    total: int

    class Config:
        from_attributes = True
        arbitrary_types_allowed = True
