from sqlalchemy.orm import Session
from db.session import get_db
from crud.rbac.roles import get_role_by_name, assign_permission
from crud.rbac.permissions import get_permission_by_name, create_permission
from schemas.rbac.permission import PermissionCreate
from fastapi import HTTPException

def assign_basic_permissions():
    """
    Assign basic permissions to roles
    """
    db = next(get_db())
    
    # Define role-permission mappings
    role_permissions = {
        "Participant": [
            "view_me",
            "view_events",
            "view_event_schedules",
            "view_venues",
            "register_for_event"
        ],
        "Event Organizer": [
            "view_me",
            "create_event",
            "update_event",
            "delete_event",
            "view_events",
            "create_venue",
            "update_venue",
            "delete_venue",
            "view_venues",
            "create_event_schedule",
            "update_event_schedule",
            "delete_event_schedule",
            "view_event_schedules"
        ],
        "Judge": [
            "view_me",
            "view_events",
            "view_event_schedules",
            "view_venues",
            "score_participants"
        ],
        "Sponsor": [
            "view_me",
            "view_events",
            "view_event_schedules",
            "view_venues",
            "create_sponsorship"
        ]
    }
    
    # Assign permissions to roles
    for role_name, permissions in role_permissions.items():
        role = get_role_by_name(db, role_name)
        if not role:
            print(f"Role '{role_name}' not found, skipping...")
            continue
            
        for permission_name in permissions:
            # Check if permission exists, if not create it
            permission = get_permission_by_name(db, permission_name)
            if not permission:
                try:
                    perm_create = PermissionCreate(
                        permission_name=permission_name,
                        description=f"Auto-generated permission: {permission_name}"
                    )
                    permission = create_permission(db, perm_create)
                    print(f"Created permission: {permission_name}")
                except Exception as e:
                    print(f"Error creating permission '{permission_name}': {str(e)}")
                    continue
            
            # Assign permission to role
            try:
                assign_permission(db, role.id, permission.id)
                print(f"Assigned permission '{permission_name}' to role '{role_name}'")
            except HTTPException as e:
                if "Permission already assigned to role" in str(e.detail):
                    print(f"Permission '{permission_name}' already assigned to role '{role_name}'")
                else:
                    print(f"Error assigning permission '{permission_name}' to role '{role_name}': {str(e.detail)}")
            except Exception as e:
                print(f"Error assigning permission '{permission_name}' to role '{role_name}': {str(e)}")

if __name__ == "__main__":
    assign_basic_permissions()
