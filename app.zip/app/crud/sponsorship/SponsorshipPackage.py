from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, case
from typing import List, Optional, Dict

from models.sponsorship import SponsorshipPackage as SponsorshipPackageModel
from models.sponsorship import SponsorshipContract
from schemas.sponsorship.SponsorshipPackage import SponsorshipPackageCreate, SponsorshipPackageUpdate

def create_sponsorship_package(db: Session, package: SponsorshipPackageCreate) -> SponsorshipPackageModel:
    """
    Create a new sponsorship package
    """
    try:
        db_package = SponsorshipPackageModel(
            package_name=package.package_name,
            description=package.description,
            price=package.price,
            benefits=package.benefits,
            max_sponsors=package.max_sponsors
        )
        db.add(db_package)
        db.commit()
        db.refresh(db_package)
        return db_package
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Package with this name already exists")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_sponsorship_package(db: Session, package_id: int) -> SponsorshipPackageModel:
    """
    Get a sponsorship package by ID
    """
    package = db.query(SponsorshipPackageModel).filter(SponsorshipPackageModel.id == package_id).first()
    if not package:
        raise HTTPException(status_code=404, detail="Sponsorship package not found")
    return package

def get_sponsorship_package_by_name(db: Session, package_name: str) -> Optional[SponsorshipPackageModel]:
    """
    Get a sponsorship package by name
    """
    return db.query(SponsorshipPackageModel).filter(SponsorshipPackageModel.package_name == package_name).first()

def get_sponsorship_packages(db: Session, skip: int = 0, limit: int = 100) -> List[SponsorshipPackageModel]:
    """
    Get all sponsorship packages
    """
    return db.query(SponsorshipPackageModel).offset(skip).limit(limit).all()

def get_sponsorship_packages_with_stats(db: Session, skip: int = 0, limit: int = 100) -> List[Dict]:
    """
    Get all sponsorship packages with contract statistics
    """
    # Subquery to count active contracts
    active_contracts = db.query(
        SponsorshipContract.package_id,
        func.count(SponsorshipContract.id).label('active_count')
    ).filter(
        SponsorshipContract.status == 'Active'
    ).group_by(
        SponsorshipContract.package_id
    ).subquery()

    # Subquery to count all contracts
    total_contracts = db.query(
        SponsorshipContract.package_id,
        func.count(SponsorshipContract.id).label('total_count')
    ).group_by(
        SponsorshipContract.package_id
    ).subquery()

    # Main query
    packages = db.query(
        SponsorshipPackageModel,
        func.coalesce(active_contracts.c.active_count, 0).label('active_contracts'),
        func.coalesce(total_contracts.c.total_count, 0).label('total_contracts')
    ).outerjoin(
        active_contracts, SponsorshipPackageModel.id == active_contracts.c.package_id
    ).outerjoin(
        total_contracts, SponsorshipPackageModel.id == total_contracts.c.package_id
    ).offset(skip).limit(limit).all()

    # Convert to dictionary
    result = []
    for package, active_count, total_count in packages:
        package_dict = {
            **package.__dict__,
            'active_contracts': active_count,
            'total_contracts': total_count
        }
        if '_sa_instance_state' in package_dict:
            del package_dict['_sa_instance_state']
        result.append(package_dict)

    return result

def update_sponsorship_package(db: Session, package_id: int, package: SponsorshipPackageUpdate) -> SponsorshipPackageModel:
    """
    Update a sponsorship package
    """
    db_package = get_sponsorship_package(db, package_id)
    
    update_data = package.model_dump(exclude_unset=True)
    
    try:
        for key, value in update_data.items():
            setattr(db_package, key, value)
        
        db.commit()
        db.refresh(db_package)
        return db_package
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Package with this name already exists")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_sponsorship_package(db: Session, package_id: int) -> SponsorshipPackageModel:
    """
    Delete a sponsorship package
    """
    db_package = get_sponsorship_package(db, package_id)
    
    # Check if there are any contracts using this package
    contracts_count = db.query(func.count(SponsorshipContract.id)).filter(
        SponsorshipContract.package_id == package_id
    ).scalar()
    
    if contracts_count > 0:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot delete package: {contracts_count} contracts are using this package"
        )
    
    try:
        db.delete(db_package)
        db.commit()
        return db_package
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting sponsorship package: {str(e)}")
