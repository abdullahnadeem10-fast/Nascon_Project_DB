from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, case
from typing import List, Optional, Dict

from models.sponsorship import Sponsor as SponsorModel
from models.sponsorship import SponsorshipContract
from schemas.sponsorship.Sponsor import SponsorCreate, SponsorUpdate

def create_sponsor(db: Session, sponsor: SponsorCreate) -> SponsorModel:
    """
    Create a new sponsor
    """
    try:
        db_sponsor = SponsorModel(
            company_name=sponsor.company_name,
            contact_person_name=sponsor.contact_person_name,
            email=sponsor.email,
            phone_number=sponsor.phone_number,
            address=sponsor.address,
            logo_url=sponsor.logo_url
        )
        db.add(db_sponsor)
        db.commit()
        db.refresh(db_sponsor)
        return db_sponsor
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating sponsor")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_sponsor(db: Session, sponsor_id: int) -> SponsorModel:
    """
    Get a sponsor by ID
    """
    sponsor = db.query(SponsorModel).filter(SponsorModel.id == sponsor_id).first()
    if not sponsor:
        raise HTTPException(status_code=404, detail="Sponsor not found")
    return sponsor

def get_sponsor_by_email(db: Session, email: str) -> Optional[SponsorModel]:
    """
    Get a sponsor by email
    """
    return db.query(SponsorModel).filter(SponsorModel.email == email).first()

def get_sponsors(db: Session, skip: int = 0, limit: int = 100) -> List[SponsorModel]:
    """
    Get all sponsors
    """
    return db.query(SponsorModel).offset(skip).limit(limit).all()

def get_sponsors_with_stats(db: Session, skip: int = 0, limit: int = 100) -> List[Dict]:
    """
    Get all sponsors with contract statistics
    """
    # Subquery to count active contracts
    active_contracts = db.query(
        SponsorshipContract.sponsor_id,
        func.count(SponsorshipContract.id).label('active_count')
    ).filter(
        SponsorshipContract.status == 'Active'
    ).group_by(
        SponsorshipContract.sponsor_id
    ).subquery()

    # Subquery to count all contracts
    total_contracts = db.query(
        SponsorshipContract.sponsor_id,
        func.count(SponsorshipContract.id).label('total_count')
    ).group_by(
        SponsorshipContract.sponsor_id
    ).subquery()

    # Main query
    sponsors = db.query(
        SponsorModel,
        func.coalesce(active_contracts.c.active_count, 0).label('active_contracts'),
        func.coalesce(total_contracts.c.total_count, 0).label('total_contracts')
    ).outerjoin(
        active_contracts, SponsorModel.id == active_contracts.c.sponsor_id
    ).outerjoin(
        total_contracts, SponsorModel.id == total_contracts.c.sponsor_id
    ).offset(skip).limit(limit).all()

    # Convert to dictionary
    result = []
    for sponsor, active_count, total_count in sponsors:
        sponsor_dict = {
            **sponsor.__dict__,
            'active_contracts': active_count,
            'total_contracts': total_count
        }
        if '_sa_instance_state' in sponsor_dict:
            del sponsor_dict['_sa_instance_state']
        result.append(sponsor_dict)

    return result

def update_sponsor(db: Session, sponsor_id: int, sponsor: SponsorUpdate) -> SponsorModel:
    """
    Update a sponsor
    """
    db_sponsor = get_sponsor(db, sponsor_id)
    
    update_data = sponsor.model_dump(exclude_unset=True)
    
    try:
        for key, value in update_data.items():
            setattr(db_sponsor, key, value)
        
        db.commit()
        db.refresh(db_sponsor)
        return db_sponsor
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating sponsor")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_sponsor(db: Session, sponsor_id: int) -> SponsorModel:
    """
    Delete a sponsor
    """
    db_sponsor = get_sponsor(db, sponsor_id)
    
    # Check if there are any contracts for this sponsor
    contracts_count = db.query(func.count(SponsorshipContract.id)).filter(
        SponsorshipContract.sponsor_id == sponsor_id
    ).scalar()
    
    if contracts_count > 0:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot delete sponsor: {contracts_count} contracts are associated with this sponsor"
        )
    
    try:
        db.delete(db_sponsor)
        db.commit()
        return db_sponsor
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting sponsor: {str(e)}")
