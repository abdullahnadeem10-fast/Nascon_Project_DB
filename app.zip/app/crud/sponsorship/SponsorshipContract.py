from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, case, and_
from typing import List, Optional, Dict

from models.sponsorship import SponsorshipContract as SponsorshipContractModel
from models.sponsorship import SponsorshipPackage, Sponsor, SponsorshipPayment
from models.rbac import User
from schemas.sponsorship.SponsorshipContract import SponsorshipContractCreate, SponsorshipContractUpdate

def create_sponsorship_contract(db: Session, contract: SponsorshipContractCreate, user_id: int) -> SponsorshipContractModel:
    """
    Create a new sponsorship contract
    """
    # Check if sponsor exists
    sponsor = db.query(Sponsor).filter(Sponsor.id == contract.sponsor_id).first()
    if not sponsor:
        raise HTTPException(status_code=404, detail="Sponsor not found")
    
    # Check if package exists
    package = db.query(SponsorshipPackage).filter(SponsorshipPackage.id == contract.package_id).first()
    if not package:
        raise HTTPException(status_code=404, detail="Sponsorship package not found")
    
    # Check if max_sponsors limit is reached
    if package.max_sponsors:
        active_contracts = db.query(func.count(SponsorshipContractModel.id)).filter(
            SponsorshipContractModel.package_id == contract.package_id,
            SponsorshipContractModel.status.in_(['Pending', 'Active'])
        ).scalar()
        
        if active_contracts >= package.max_sponsors:
            raise HTTPException(
                status_code=400, 
                detail=f"Maximum number of sponsors ({package.max_sponsors}) for this package has been reached"
            )
    
    try:
        db_contract = SponsorshipContractModel(
            sponsor_id=contract.sponsor_id,
            package_id=contract.package_id,
            created_by=user_id,
            start_date=contract.start_date,
            end_date=contract.end_date,
            status=contract.status,
            payment_status=contract.payment_status,
            total_amount=contract.total_amount
        )
        db.add(db_contract)
        db.commit()
        db.refresh(db_contract)
        return db_contract
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating sponsorship contract")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_sponsorship_contract(db: Session, contract_id: int) -> SponsorshipContractModel:
    """
    Get a sponsorship contract by ID
    """
    contract = db.query(SponsorshipContractModel).filter(SponsorshipContractModel.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Sponsorship contract not found")
    return contract

def get_sponsorship_contract_with_details(db: Session, contract_id: int) -> Dict:
    """
    Get a sponsorship contract with related details
    """
    # Get contract with related entities
    result = db.query(
        SponsorshipContractModel,
        Sponsor.company_name.label('sponsor_name'),
        SponsorshipPackage.package_name.label('package_name'),
        func.concat(User.first_name, ' ', User.last_name).label('creator_name'),
        func.coalesce(func.sum(SponsorshipPayment.amount), 0).label('payments_total'),
        func.count(SponsorshipPayment.id).label('payments_count')
    ).join(
        Sponsor, SponsorshipContractModel.sponsor_id == Sponsor.id
    ).join(
        SponsorshipPackage, SponsorshipContractModel.package_id == SponsorshipPackage.id
    ).join(
        User, SponsorshipContractModel.created_by == User.id
    ).outerjoin(
        SponsorshipPayment, SponsorshipContractModel.id == SponsorshipPayment.contract_id
    ).filter(
        SponsorshipContractModel.id == contract_id
    ).group_by(
        SponsorshipContractModel.id,
        Sponsor.company_name,
        SponsorshipPackage.package_name,
        func.concat(User.first_name, ' ', User.last_name)
    ).first()
    
    if not result:
        raise HTTPException(status_code=404, detail="Sponsorship contract not found")
    
    contract, sponsor_name, package_name, creator_name, payments_total, payments_count = result
    
    # Convert to dictionary
    contract_dict = {
        **contract.__dict__,
        'sponsor_name': sponsor_name,
        'package_name': package_name,
        'creator_name': creator_name,
        'payments_total': payments_total,
        'payments_count': payments_count
    }
    
    if '_sa_instance_state' in contract_dict:
        del contract_dict['_sa_instance_state']
    
    return contract_dict

def get_sponsorship_contracts(
    db: Session, 
    skip: int = 0, 
    limit: int = 100,
    sponsor_id: Optional[int] = None,
    package_id: Optional[int] = None,
    status: Optional[str] = None
) -> List[SponsorshipContractModel]:
    """
    Get all sponsorship contracts with optional filters
    """
    query = db.query(SponsorshipContractModel)
    
    if sponsor_id:
        query = query.filter(SponsorshipContractModel.sponsor_id == sponsor_id)
    
    if package_id:
        query = query.filter(SponsorshipContractModel.package_id == package_id)
    
    if status:
        query = query.filter(SponsorshipContractModel.status == status)
    
    return query.offset(skip).limit(limit).all()

def update_sponsorship_contract(db: Session, contract_id: int, contract: SponsorshipContractUpdate) -> SponsorshipContractModel:
    """
    Update a sponsorship contract
    """
    db_contract = get_sponsorship_contract(db, contract_id)
    
    update_data = contract.model_dump(exclude_unset=True)
    
    # If updating package_id, check max_sponsors limit
    if 'package_id' in update_data and update_data['package_id'] != db_contract.package_id:
        package = db.query(SponsorshipPackage).filter(SponsorshipPackage.id == update_data['package_id']).first()
        if not package:
            raise HTTPException(status_code=404, detail="Sponsorship package not found")
        
        if package.max_sponsors:
            active_contracts = db.query(func.count(SponsorshipContractModel.id)).filter(
                SponsorshipContractModel.package_id == update_data['package_id'],
                SponsorshipContractModel.status.in_(['Pending', 'Active']),
                SponsorshipContractModel.id != contract_id
            ).scalar()
            
            if active_contracts >= package.max_sponsors:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Maximum number of sponsors ({package.max_sponsors}) for this package has been reached"
                )
    
    try:
        for key, value in update_data.items():
            setattr(db_contract, key, value)
        
        # Update payment_status based on payments
        if 'payment_status' not in update_data:
            total_paid = db.query(func.sum(SponsorshipPayment.amount)).filter(
                SponsorshipPayment.contract_id == contract_id
            ).scalar() or 0
            
            if total_paid >= db_contract.total_amount:
                db_contract.payment_status = 'Completed'
            elif total_paid > 0:
                db_contract.payment_status = 'Partial'
            else:
                db_contract.payment_status = 'Pending'
        
        db.commit()
        db.refresh(db_contract)
        return db_contract
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating sponsorship contract")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_sponsorship_contract(db: Session, contract_id: int) -> SponsorshipContractModel:
    """
    Delete a sponsorship contract
    """
    db_contract = get_sponsorship_contract(db, contract_id)
    
    # Check if there are any payments for this contract
    payments_count = db.query(func.count(SponsorshipPayment.id)).filter(
        SponsorshipPayment.contract_id == contract_id
    ).scalar()
    
    if payments_count > 0:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot delete contract: {payments_count} payments are associated with this contract"
        )
    
    try:
        db.delete(db_contract)
        db.commit()
        return db_contract
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting sponsorship contract: {str(e)}")

def update_contract_payment_status(db: Session, contract_id: int) -> SponsorshipContractModel:
    """
    Update the payment status of a contract based on its payments
    """
    db_contract = get_sponsorship_contract(db, contract_id)
    
    # Calculate total payments
    total_paid = db.query(func.sum(SponsorshipPayment.amount)).filter(
        SponsorshipPayment.contract_id == contract_id
    ).scalar() or 0
    
    try:
        if total_paid >= db_contract.total_amount:
            db_contract.payment_status = 'Completed'
        elif total_paid > 0:
            db_contract.payment_status = 'Partial'
        else:
            db_contract.payment_status = 'Pending'
        
        db.commit()
        db.refresh(db_contract)
        return db_contract
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
