# Import CRUD functions for easier access
from .SponsorshipPackage import (
    create_sponsorship_package,
    get_sponsorship_package,
    get_sponsorship_package_by_name,
    get_sponsorship_packages,
    get_sponsorship_packages_with_stats,
    update_sponsorship_package,
    delete_sponsorship_package
)

from .Sponsor import (
    create_sponsor,
    get_sponsor,
    get_sponsor_by_email,
    get_sponsors,
    get_sponsors_with_stats,
    update_sponsor,
    delete_sponsor
)

from .SponsorshipContract import (
    create_sponsorship_contract,
    get_sponsorship_contract,
    get_sponsorship_contract_with_details,
    get_sponsorship_contracts,
    update_sponsorship_contract,
    delete_sponsorship_contract,
    update_contract_payment_status
)

from .SponsorshipPayment import (
    create_sponsorship_payment,
    get_sponsorship_payment,
    get_sponsorship_payment_with_details,
    get_sponsorship_payments,
    get_sponsorship_payments_summary,
    update_sponsorship_payment,
    delete_sponsorship_payment
)
