from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, case
from typing import List, Optional, Dict

from models.sponsorship import SponsorshipPayment as SponsorshipPaymentModel
from models.sponsorship import SponsorshipContract, Sponsor
from models.rbac import User
from schemas.sponsorship.SponsorshipPayment import SponsorshipPaymentCreate, SponsorshipPaymentUpdate
from .SponsorshipContract import update_contract_payment_status

def create_sponsorship_payment(db: Session, payment: SponsorshipPaymentCreate, user_id: int) -> SponsorshipPaymentModel:
    """
    Create a new sponsorship payment
    """
    # Check if contract exists
    contract = db.query(SponsorshipContract).filter(SponsorshipContract.id == payment.contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Sponsorship contract not found")
    
    # Check if contract is active
    if contract.status not in ['Pending', 'Active']:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot add payment to a contract with status '{contract.status}'"
        )
    
    # Check if payment would exceed the total amount
    total_paid = db.query(func.sum(SponsorshipPaymentModel.amount)).filter(
        SponsorshipPaymentModel.contract_id == payment.contract_id
    ).scalar() or 0
    
    if total_paid + payment.amount > contract.total_amount:
        raise HTTPException(
            status_code=400, 
            detail=f"Payment would exceed the total contract amount. Remaining amount: {contract.total_amount - total_paid}"
        )
    
    try:
        db_payment = SponsorshipPaymentModel(
            contract_id=payment.contract_id,
            amount=payment.amount,
            payment_method=payment.payment_method,
            transaction_reference=payment.transaction_reference,
            received_by=user_id
        )
        db.add(db_payment)
        db.commit()
        db.refresh(db_payment)
        
        # Update contract payment status
        update_contract_payment_status(db, payment.contract_id)
        
        return db_payment
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating sponsorship payment")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_sponsorship_payment(db: Session, payment_id: int) -> SponsorshipPaymentModel:
    """
    Get a sponsorship payment by ID
    """
    payment = db.query(SponsorshipPaymentModel).filter(SponsorshipPaymentModel.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Sponsorship payment not found")
    return payment

def get_sponsorship_payment_with_details(db: Session, payment_id: int) -> Dict:
    """
    Get a sponsorship payment with related details
    """
    # Get payment with related entities
    result = db.query(
        SponsorshipPaymentModel,
        func.concat('Contract #', SponsorshipContract.id).label('contract_reference'),
        Sponsor.company_name.label('sponsor_name'),
        func.concat(User.first_name, ' ', User.last_name).label('receiver_name')
    ).join(
        SponsorshipContract, SponsorshipPaymentModel.contract_id == SponsorshipContract.id
    ).join(
        Sponsor, SponsorshipContract.sponsor_id == Sponsor.id
    ).join(
        User, SponsorshipPaymentModel.received_by == User.id
    ).filter(
        SponsorshipPaymentModel.id == payment_id
    ).first()
    
    if not result:
        raise HTTPException(status_code=404, detail="Sponsorship payment not found")
    
    payment, contract_reference, sponsor_name, receiver_name = result
    
    # Convert to dictionary
    payment_dict = {
        **payment.__dict__,
        'contract_reference': contract_reference,
        'sponsor_name': sponsor_name,
        'receiver_name': receiver_name
    }
    
    if '_sa_instance_state' in payment_dict:
        del payment_dict['_sa_instance_state']
    
    return payment_dict

def get_sponsorship_payments(
    db: Session, 
    skip: int = 0, 
    limit: int = 100,
    contract_id: Optional[int] = None
) -> List[SponsorshipPaymentModel]:
    """
    Get all sponsorship payments with optional filters
    """
    query = db.query(SponsorshipPaymentModel)
    
    if contract_id:
        query = query.filter(SponsorshipPaymentModel.contract_id == contract_id)
    
    return query.order_by(SponsorshipPaymentModel.payment_date.desc()).offset(skip).limit(limit).all()

def get_sponsorship_payments_summary(db: Session, contract_id: int) -> Dict:
    """
    Get summary of payments for a contract
    """
    # Check if contract exists
    contract = db.query(SponsorshipContract).filter(SponsorshipContract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Sponsorship contract not found")
    
    # Get payments
    payments = db.query(SponsorshipPaymentModel).filter(
        SponsorshipPaymentModel.contract_id == contract_id
    ).order_by(SponsorshipPaymentModel.payment_date.desc()).all()
    
    # Calculate total
    total_amount = sum(payment.amount for payment in payments)
    
    return {
        'payments': payments,
        'total': len(payments),
        'total_amount': total_amount,
        'contract_amount': contract.total_amount,
        'remaining_amount': contract.total_amount - total_amount
    }

def update_sponsorship_payment(db: Session, payment_id: int, payment: SponsorshipPaymentUpdate) -> SponsorshipPaymentModel:
    """
    Update a sponsorship payment
    """
    db_payment = get_sponsorship_payment(db, payment_id)
    
    update_data = payment.model_dump(exclude_unset=True)
    
    # Check if amount change would exceed the total contract amount
    if 'amount' in update_data and update_data['amount'] != db_payment.amount:
        contract = db.query(SponsorshipContract).filter(SponsorshipContract.id == db_payment.contract_id).first()
        
        total_paid = db.query(func.sum(SponsorshipPaymentModel.amount)).filter(
            SponsorshipPaymentModel.contract_id == db_payment.contract_id,
            SponsorshipPaymentModel.id != payment_id
        ).scalar() or 0
        
        if total_paid + update_data['amount'] > contract.total_amount:
            raise HTTPException(
                status_code=400, 
                detail=f"Payment would exceed the total contract amount. Maximum allowed: {contract.total_amount - total_paid}"
            )
    
    try:
        for key, value in update_data.items():
            setattr(db_payment, key, value)
        
        db.commit()
        db.refresh(db_payment)
        
        # Update contract payment status
        update_contract_payment_status(db, db_payment.contract_id)
        
        return db_payment
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating sponsorship payment")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_sponsorship_payment(db: Session, payment_id: int) -> SponsorshipPaymentModel:
    """
    Delete a sponsorship payment
    """
    db_payment = get_sponsorship_payment(db, payment_id)
    contract_id = db_payment.contract_id
    
    try:
        db.delete(db_payment)
        db.commit()
        
        # Update contract payment status
        update_contract_payment_status(db, contract_id)
        
        return db_payment
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting sponsorship payment: {str(e)}")
