from fastapi import HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional, Union
from models.rbac import Role, RolePermission, Permission
from schemas.rbac.role import RoleCreate, RoleUpdate

def get_role(db: Session, role_id: int) -> Optional[Role]:
    return db.query(Role).filter(Role.id == role_id).first()

def get_role_by_name(db: Session, name: str) -> Optional[Role]:
    return db.query(Role).filter(Role.role_name == name).first()

def get_roles(db: Session, skip: int = 0, limit: int = 10) -> List[Role]:
    return db.query(Role).offset(skip).limit(limit).all()

def create_role(db: Session, role: RoleCreate) -> Role:
    db_role = get_role_by_name(db, role.role_name)
    if db_role:
        raise HTTPException(status_code=400, detail="Role already exists")

    try:
        db_role = Role(
            role_name=role.role_name,
            description=role.description
        )
        db.add(db_role)
        db.commit()
        db.refresh(db_role)
        return db_role
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

def update_role(db: Session, role_id: int, role: RoleUpdate) -> Role:
    db_role = get_role(db, role_id)
    if not db_role:
        raise HTTPException(status_code=404, detail="Role not found")

    try:
        if role.role_name:
            existing = get_role_by_name(db, role.role_name)
            if existing and existing.id != role_id:
                raise HTTPException(status_code=400, detail="Role name already exists")
            db_role.role_name = role.role_name

        if role.description is not None:
            db_role.description = role.description

        db.commit()
        db.refresh(db_role)
        return db_role
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

def delete_role(db: Session, role_id: int) -> Role:
    db_role = get_role(db, role_id)
    if not db_role:
        raise HTTPException(status_code=404, detail="Role not found")

    try:
        db.delete(db_role)
        db.commit()
        return db_role
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

def assign_permission(db: Session, role_id: int, permission_id: int) -> RolePermission:
    existing = db.query(RolePermission).filter(
        RolePermission.role_id == role_id,
        RolePermission.permission_id == permission_id
    ).first()

    if existing:
        raise HTTPException(status_code=400, detail="Permission already assigned to role")

    try:
        role_permission = RolePermission(role_id=role_id, permission_id=permission_id)
        db.add(role_permission)
        db.commit()
        db.refresh(role_permission)
        return role_permission
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

def get_permissions_of_role(db: Session, role_id: Union[int, List[int]]) -> List[str]:
    """
    Get all permissions assigned to a role or list of roles
    Returns a list of permission names
    """
    if isinstance(role_id, int):
        # Single role ID
        role = get_role(db, role_id)
        if not role:
            raise HTTPException(status_code=404, detail="Role not found")

        role_permissions = db.query(RolePermission).join(
            Permission, RolePermission.permission_id == Permission.id
        ).filter(
            RolePermission.role_id == role_id
        ).with_entities(Permission.permission_name).all()

        return [rp[0] for rp in role_permissions]
    else:
        # List of role IDs
        if not role_id:  # Empty list
            return []

        role_permissions = db.query(RolePermission).join(
            Permission, RolePermission.permission_id == Permission.id
        ).filter(
            RolePermission.role_id.in_(role_id)
        ).with_entities(Permission.permission_name).all()

        return [rp[0] for rp in role_permissions]