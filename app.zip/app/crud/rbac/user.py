import uuid
from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from typing import List, Optional
from core.security import get_password_hash, verify_password
from models.rbac import User, Role, UserRole
from schemas.rbac.user import UserCreate, UserUpdate, UserRoleCreate

def create_user(db: Session, user_create: UserCreate) -> User:
    # Check if user already exists
    if get_user_by_email(db, user_create.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    if get_user_by_username(db, user_create.username):
        raise HTTPException(status_code=400, detail="Username already taken")
    
    # Hash the password before storing it
    hashed_password = get_password_hash(user_create.password)
    
    try:
        db_user = User(
            username=user_create.username,
            email=user_create.email,
            password=hashed_password,
            is_active=True,  # Default to active
            first_name=user_create.first_name,  # Fixed field name
            last_name=user_create.last_name,    # Fixed field name
            phone_number=user_create.phone_number,
            address=user_create.address,
            university=user_create.university
        )
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        return db_user
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating user")

def get_user(db: Session, user_id: int) -> Optional[User]:
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

def get_users(db: Session, skip: int = 0, limit: int = 10) -> List[User]:
    return db.query(User).offset(skip).limit(limit).all()

def get_user_by_email(db: Session, email: str) -> Optional[User]:
    return db.query(User).filter(User.email == email.lower().strip()).first()

def get_user_by_username(db: Session, username: str) -> Optional[User]:
    return db.query(User).filter(User.username == username.strip()).first()

def update_user(db: Session, user_id: int, user_update: UserUpdate) -> User:
    db_user = get_user(db, user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    try:
        update_data = user_update.dict(exclude_unset=True)
        
        # Handle password hashing if password is being updated
        if "password" in update_data:
            update_data["password"] = get_password_hash(update_data["password"])
            
        # Handle email lowercase if email is being updated
        if "email" in update_data:
            update_data["email"] = update_data["email"].lower()
            
        for field, value in update_data.items():
            setattr(db_user, field, value)
            
        db.commit()
        db.refresh(db_user)
        return db_user
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating user")

def delete_user(db: Session, user_id: int) -> None:
    db_user = get_user(db, user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    try:
        db.delete(db_user)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error deleting user")

def assign_role_to_user(db: Session, user_id: int, role_id: int) -> dict:
    user = get_user(db, user_id)
    role = db.query(Role).filter(Role.id == role_id).first()
    
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    
    # Check if the role is already assigned
    existing_role = db.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.role_id == role_id
    ).first()
    
    if existing_role:
        raise HTTPException(
            status_code=400,
            detail=f"Role '{role.role_name}' is already assigned to user '{user.username}'"
        )
    
    try:
        user_role = UserRole(user_id=user_id, role_id=role_id)
        db.add(user_role)
        db.commit()
        return {"message": f"Role '{role.role_name}' assigned to user '{user.username}' successfully"}
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error assigning role")

def remove_role_from_user(db: Session, user_id: int, role_id: int) -> dict:
    user = get_user(db, user_id)
    role = db.query(Role).filter(Role.id == role_id).first()
    
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    
    user_role = db.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.role_id == role_id
    ).first()
    
    if not user_role:
        raise HTTPException(
            status_code=400,
            detail=f"Role '{role.role_name}' is not assigned to user '{user.username}'"
        )
    
    try:
        db.delete(user_role)
        db.commit()
        return {"message": f"Role '{role.role_name}' removed from user '{user.username}' successfully"}
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error removing role")

def change_password(db: Session, user_id: int, current_password: str, new_password: str) -> dict:
    user = get_user(db, user_id)
    
    if not verify_password(current_password, user.password):
        raise HTTPException(status_code=400, detail="Incorrect password")
    
    try:
        user.password = get_password_hash(new_password)
        db.commit()
        return {"message": "Password updated successfully"}
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating password")

