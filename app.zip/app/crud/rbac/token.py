from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_
from models.rbac import BlacklistedToken

def blacklist_token(db: Session, token: str, expires_at: datetime) -> BlacklistedToken:
    """Store the token in the blacklist table"""
    blacklisted_token = BlacklistedToken(token=token, expires_at=expires_at)
    db.add(blacklisted_token)
    db.commit()
    db.refresh(blacklisted_token)
    return blacklisted_token

def is_token_blacklisted(db: Session, token: str) -> bool:
    """Check if a token is blacklisted and not expired"""
    return db.query(BlacklistedToken).filter(
        and_(
            BlacklistedToken.token == token,
            BlacklistedToken.expires_at > datetime.utcnow()
        )
    ).first() is not None

def cleanup_expired_tokens(db: Session) -> None:
    """Remove expired tokens from the blacklist"""
    db.query(BlacklistedToken).filter(
        BlacklistedToken.expires_at <= datetime.utcnow()
    ).delete()
    db.commit()