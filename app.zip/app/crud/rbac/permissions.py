from sqlalchemy.orm import Session
from models import Permission
from schemas.rbac.permission import PermissionCreate, PermissionUpdate
from fastapi import HTTPException
from typing import Optional

def get_permission(db: Session, permission_id: int) -> Optional[Permission]:
    try:
        return db.query(Permission).filter(Permission.id == permission_id).first()
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving permission: {str(e)}"
        )

def get_permission_by_name(db: Session, name: str) -> Optional[Permission]:
    return db.query(Permission).filter(Permission.permission_name == name).first()

def get_permissions(db: Session, skip: int = 0, limit: int = 10):
    return db.query(Permission).offset(skip).limit(limit).all()

def create_permission(db: Session, permission: PermissionCreate) -> Permission:
    db_permission = get_permission_by_name(db, permission.permission_name)
    if db_permission:
        raise HTTPException(status_code=400, detail="Permission already exists")

    try:
        db_permission = Permission(
            permission_name=permission.permission_name,
            description=permission.description
        )
        db.add(db_permission)
        db.commit()
        db.refresh(db_permission)
        return db_permission
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Error creating permission: {str(e)}"
        )

def update_permission(db: Session, permission_id: int, permission: PermissionUpdate) -> Permission:
    try:
        db_permission = get_permission(db, permission_id)
        if not db_permission:
            raise HTTPException(status_code=404, detail="Permission not found")

        if permission.permission_name:
            existing = get_permission_by_name(db, permission.permission_name)
            if existing and existing.id != permission_id:
                raise HTTPException(status_code=400, detail="Permission name already exists")
            db_permission.permission_name = permission.permission_name

        if permission.description is not None:
            db_permission.description = permission.description

        db.commit()
        db.refresh(db_permission)
        return db_permission
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Error updating permission: {str(e)}"
        )

def delete_permission(db: Session, permission_id: int) -> Permission:
    try:
        db_permission = get_permission(db, permission_id)
        if not db_permission:
            raise HTTPException(status_code=404, detail="Permission not found")

        db.delete(db_permission)
        db.commit()
        return db_permission
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting permission: {str(e)}"
        )
