from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from typing import List, Optional

from models.accommodation import AccommodationFacility as AccommodationFacilityModel
from schemas.accomodation.accomodation_Facilities import (
    AccommodationFacilityCreate, 
    AccommodationFacilityUpdate
)

def create_facility(db: Session, facility: AccommodationFacilityCreate) -> AccommodationFacilityModel:
    try:
        db_facility = AccommodationFacilityModel(
            facility_name=facility.facility_name,
            address=facility.address,
            total_rooms=facility.total_rooms,
            contact_person=facility.contact_person,
            contact_number=facility.contact_number,
            description=facility.description
        )
        db.add(db_facility)
        db.commit()
        db.refresh(db_facility)
        return db_facility
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Facility with this name already exists")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_facility(db: Session, facility_id: int) -> Optional[AccommodationFacilityModel]:
    facility = db.query(AccommodationFacilityModel).filter(AccommodationFacilityModel.id == facility_id).first()
    if not facility:
        raise HTTPException(status_code=404, detail="Facility not found")
    return facility

def get_facility_by_name(db: Session, facility_name: str) -> Optional[AccommodationFacilityModel]:
    return db.query(AccommodationFacilityModel).filter(AccommodationFacilityModel.facility_name == facility_name).first()

def get_facilities(db: Session, skip: int = 0, limit: int = 10) -> List[AccommodationFacilityModel]:
    return db.query(AccommodationFacilityModel).offset(skip).limit(limit).all()

def update_facility(
    db: Session, 
    facility_id: int, 
    facility_update: AccommodationFacilityUpdate
) -> AccommodationFacilityModel:
    db_facility = get_facility(db, facility_id)
    if not db_facility:
        raise HTTPException(status_code=404, detail="Facility not found")
    
    try:
        update_data = facility_update.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            setattr(db_facility, field, value)
            
        db.commit()
        db.refresh(db_facility)
        return db_facility
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Facility with this name already exists")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_facility(db: Session, facility_id: int) -> AccommodationFacilityModel:
    db_facility = db.query(AccommodationFacilityModel).filter(AccommodationFacilityModel.id == facility_id).first()
    if not db_facility:
        raise HTTPException(status_code=404, detail="Facility not found")
    
    try:
        # First check if there are any active requests or allocations
        active_requests = any(
            request.status in ['Pending', 'Approved']
            for request in db_facility.accommodation_requests
        )
        
        if active_requests:
            raise HTTPException(
                status_code=400, 
                detail="Cannot delete facility with active accommodation requests"
            )

        # Due to ondelete="CASCADE", this will automatically delete:
        # 1. All room types (cascade to room_types table)
        # 2. All rooms (cascade to rooms table)
        # 3. All room allocations (cascade from rooms)
        # 4. All accommodation requests will be preserved but with null preferred_facility_id
        db.delete(db_facility)
        db.commit()
        return db_facility

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting facility: {str(e)}"
        )