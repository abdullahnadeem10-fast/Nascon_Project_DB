from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_
from datetime import datetime
from models.accommodation import Room, RoomAllocation
from schemas.accomodation.Room import RoomCreate, RoomUpdate, RoomOut

def create_room(db: Session, room: RoomCreate) -> Room:
    db_room = Room(
        room_number=room.room_number,
        status=room.status,
        facility_id=room.facility_id,
        room_type_id=room.room_type_id,
        capacity=room.capacity
    )
    db.add(db_room)
    db.commit()
    db.refresh(db_room)
    return db_room

def get_room(db: Session, room_id: int) -> Optional[Room]:
    return db.query(Room)\
        .join(Room.facility)\
        .join(Room.room_type)\
        .options(
            joinedload(Room.facility),
            joinedload(Room.room_type)
        )\
        .filter(Room.id == room_id)\
        .first()

def get_rooms(db: Session, skip: int = 0, limit: int = 100) -> List[Room]:
    return db.query(Room)\
        .join(Room.facility)\
        .join(Room.room_type)\
        .options(
            joinedload(Room.facility),
            joinedload(Room.room_type)
        )\
        .offset(skip)\
        .limit(limit)\
        .all()

def get_room_by_number(db: Session, room_number: str) -> Optional[Room]:
    return db.query(Room)\
        .join(Room.facility)\
        .join(Room.room_type)\
        .options(
            joinedload(Room.facility),
            joinedload(Room.room_type)
        )\
        .filter(Room.room_number == room_number)\
        .first()

def update_room(db: Session, room_id: int, room: RoomUpdate) -> Optional[Room]:
    db_room = db.query(Room)\
        .join(Room.facility)\
        .join(Room.room_type)\
        .options(
            joinedload(Room.facility),
            joinedload(Room.room_type)
        )\
        .filter(Room.id == room_id)\
        .first()

    if db_room:
        update_data = room.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_room, field, value)
        db.commit()
        db.refresh(db_room)
    return db_room

def delete_room(db: Session, room_id: int) -> bool:
    db_room = db.query(Room).filter(Room.id == room_id).first()
    if db_room:
        db.delete(db_room)
        db.commit()
        return True
    return False

def find_available_room_by_type(
    db: Session,
    room_type_id: int,
    check_in_time: datetime,
    check_out_time: datetime
) -> Optional[Room]:
    """
    Find an available room of a specific room type for a given date range.
    Returns the first available room or None if no rooms are available.
    """
    # Get all rooms of the specified type
    rooms_of_type = db.query(Room)\
        .filter(
            Room.room_type_id == room_type_id,
            Room.status == 'Available'  # Only consider rooms marked as available
        )\
        .all()

    # For each room, check if it has any conflicting allocations
    for room in rooms_of_type:
        # Check if there are any allocations that overlap with the requested period
        conflicting_allocations = db.query(RoomAllocation).filter(
            RoomAllocation.room_id == room.id,
            RoomAllocation.payment_status != 'Cancelled',  # Ignore cancelled allocations
            # Check for date range overlap
            # Either the check-in time is between an existing allocation's check-in and check-out
            # Or the check-out time is between an existing allocation's check-in and check-out
            # Or the requested period completely encompasses an existing allocation
            or_(
                and_(
                    RoomAllocation.check_in_time <= check_in_time,
                    RoomAllocation.check_out_time >= check_in_time
                ),
                and_(
                    RoomAllocation.check_in_time <= check_out_time,
                    RoomAllocation.check_out_time >= check_out_time
                ),
                and_(
                    RoomAllocation.check_in_time >= check_in_time,
                    RoomAllocation.check_out_time <= check_out_time
                )
            )
        ).first()

        # If no conflicting allocations, this room is available
        if not conflicting_allocations:
            return room

    # No available rooms found
    return None