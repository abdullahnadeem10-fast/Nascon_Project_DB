from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_
from datetime import date

from models.accommodation import AccommodationRequest
from schemas.accomodation.Accomodation_Requests import AccommodationRequestCreate, AccommodationRequestUpdate

def create_accommodation_request(
    db: Session,
    request: AccommodationRequestCreate,
    user_id: int
) -> AccommodationRequest:
    db_request = AccommodationRequest(
        user_id=user_id,
        check_in_date=request.check_in_date,
        check_out_date=request.check_out_date,
        number_of_people=request.number_of_people,
        preferred_facility_id=request.preferred_facility_id,
        preferred_room_type_id=request.preferred_room_type_id,
        special_requests=request.special_requests
    )
    db.add(db_request)
    db.commit()
    db.refresh(db_request)
    return db_request

def get_accommodation_request(
    db: Session,
    request_id: int
) -> Optional[AccommodationRequest]:
    request = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.id == request_id)\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .first()

    if request:
        request.user_name = request.requester.username

    return request

def get_user_accommodation_requests(
    db: Session,
    user_id: int,
    skip: int = 0,
    limit: int = 100
) -> List[AccommodationRequest]:
    # Join with User model to get username
    requests = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.user_id == user_id)\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .offset(skip)\
        .limit(limit)\
        .all()

    # Add username as user_name attribute to each request
    for request in requests:
        request.user_name = request.requester.username

    return requests

def get_all_accommodation_requests(
    db: Session,
    skip: int = 0,
    limit: int = 100
) -> List[AccommodationRequest]:
    # Join with User model to get username
    requests = db.query(AccommodationRequest)\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .offset(skip)\
        .limit(limit)\
        .all()

    # Add username as user_name attribute to each request
    for request in requests:
        request.user_name = request.requester.username

    return requests

def update_accommodation_request(
    db: Session,
    request_id: int,
    update_data: AccommodationRequestUpdate
) -> Optional[AccommodationRequest]:
    db_request = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.id == request_id)\
        .first()

    if not db_request:
        return None

    # Use model_dump instead of dict (which is deprecated)
    update_dict = update_data.model_dump(exclude_unset=True)
    for field, value in update_dict.items():
        setattr(db_request, field, value)

    db.commit()
    db.refresh(db_request)

    # Re-fetch the request with user information
    updated_request = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.id == request_id)\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .first()

    updated_request.user_name = updated_request.requester.username

    return updated_request

def delete_accommodation_request(
    db: Session,
    request_id: int
) -> bool:
    db_request = db.query(AccommodationRequest).filter(AccommodationRequest.id == request_id).first()
    if not db_request:
        return False

    db.delete(db_request)
    db.commit()
    return True

def get_requests_by_date_range(
    db: Session,
    start_date: date,
    end_date: date,
    facility_id: Optional[int] = None,
    status: Optional[str] = None
) -> List[AccommodationRequest]:
    query = db.query(AccommodationRequest).filter(
        and_(
            AccommodationRequest.check_in_date >= start_date,
            AccommodationRequest.check_out_date <= end_date
        )
    ).join(AccommodationRequest.requester).options(joinedload(AccommodationRequest.requester))

    if facility_id:
        query = query.filter(AccommodationRequest.preferred_facility_id == facility_id)

    if status:
        query = query.filter(AccommodationRequest.status == status)

    requests = query.all()

    # Add username as user_name attribute to each request
    for request in requests:
        request.user_name = request.requester.username

    return requests

def get_pending_requests(
    db: Session,
    skip: int = 0,
    limit: int = 100
) -> List[AccommodationRequest]:
    requests = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.status == "Pending")\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .offset(skip)\
        .limit(limit)\
        .all()

    # Add username as user_name attribute to each request
    for request in requests:
        request.user_name = request.requester.username

    return requests

def update_request_status(
    db: Session,
    request_id: int,
    new_status: str
) -> Optional[AccommodationRequest]:
    db_request = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.id == request_id)\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .first()

    if not db_request:
        return None

    db_request.status = new_status
    db.commit()
    db.refresh(db_request)

    # Re-fetch the request with user information
    updated_request = db.query(AccommodationRequest)\
        .filter(AccommodationRequest.id == request_id)\
        .join(AccommodationRequest.requester)\
        .options(joinedload(AccommodationRequest.requester))\
        .first()

    updated_request.user_name = updated_request.requester.username

    return updated_request