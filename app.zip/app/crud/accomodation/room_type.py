from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from typing import List, Optional

from models.accommodation import RoomType as RoomTypeModel
from schemas.accomodation.room_type import RoomTypeCreate, RoomTypeUpdate

def create_room_type(db: Session, room_type: RoomTypeCreate) -> RoomTypeModel:
    try:
        db_room_type = RoomTypeModel(
            facility_id=room_type.facility_id,
            type_name=room_type.type_name,
            description=room_type.description,
            capacity=room_type.capacity,
            price_per_night=room_type.price_per_night,
            amenities=room_type.amenities
        )
        db.add(db_room_type)
        db.commit()
        db.refresh(db_room_type)
        return db_room_type
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Room type with this name already exists in the facility")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_room_type(db: Session, room_type_id: int) -> Optional[RoomTypeModel]:
    room_type = db.query(RoomTypeModel).filter(RoomTypeModel.id == room_type_id).first()
    if not room_type:
        raise HTTPException(status_code=404, detail="Room type not found")
    return room_type

def get_room_type_by_name(db: Session, facility_id: int, type_name: str) -> Optional[RoomTypeModel]:
    return db.query(RoomTypeModel).filter(
        RoomTypeModel.facility_id == facility_id,
        RoomTypeModel.type_name == type_name
    ).first()

def get_room_types(db: Session, skip: int = 0, limit: int = 10) -> List[RoomTypeModel]:
    return db.query(RoomTypeModel).offset(skip).limit(limit).all()

def get_facility_room_types(db: Session, facility_id: int, skip: int = 0, limit: int = 10) -> List[RoomTypeModel]:
    return db.query(RoomTypeModel).filter(
        RoomTypeModel.facility_id == facility_id
    ).offset(skip).limit(limit).all()

def update_room_type(
    db: Session, 
    room_type_id: int, 
    room_type_update: RoomTypeUpdate
) -> RoomTypeModel:
    db_room_type = get_room_type(db, room_type_id)
    if not db_room_type:
        raise HTTPException(status_code=404, detail="Room type not found")
    
    try:
        update_data = room_type_update.dict(exclude_unset=True)
        
        # If facility_id or type_name is being updated, check for uniqueness
        if 'facility_id' in update_data or 'type_name' in update_data:
            facility_id = update_data.get('facility_id', db_room_type.facility_id)
            type_name = update_data.get('type_name', db_room_type.type_name)
            existing = get_room_type_by_name(db, facility_id, type_name)
            if existing and existing.id != room_type_id:
                raise HTTPException(
                    status_code=400, 
                    detail="Room type with this name already exists in the facility"
                )
        
        for field, value in update_data.items():
            setattr(db_room_type, field, value)
            
        db.commit()
        db.refresh(db_room_type)
        return db_room_type
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Room type with this name already exists in the facility")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_room_type(db: Session, room_type_id: int) -> RoomTypeModel:
    db_room_type = get_room_type(db, room_type_id)
    if not db_room_type:
        raise HTTPException(status_code=404, detail="Room type not found")
    
    try:
        db.delete(db_room_type)
        db.commit()
        return db_room_type
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))