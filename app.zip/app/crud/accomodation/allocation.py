from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime

from models.accommodation import RoomAllocation
from schemas.accomodation.Allocation import RoomAllocationCreate

def create_allocation(db: Session, allocation: RoomAllocationCreate) -> RoomAllocation:
    db_allocation = RoomAllocation(**allocation.dict())
    db.add(db_allocation)
    db.commit()
    db.refresh(db_allocation)
    return db_allocation

def get_allocation(db: Session, allocation_id: int) -> Optional[RoomAllocation]:
    return db.query(RoomAllocation).filter(RoomAllocation.id == allocation_id).first()

def get_allocation_by_request(db: Session, request_id: int) -> Optional[RoomAllocation]:
    return db.query(RoomAllocation).filter(RoomAllocation.request_id == request_id).first()

def get_allocations(
    db: Session, 
    skip: int = 0, 
    limit: int = 100,
    room_id: Optional[int] = None,
    payment_status: Optional[str] = None
) -> List[RoomAllocation]:
    query = db.query(RoomAllocation)
    
    if room_id:
        query = query.filter(RoomAllocation.room_id == room_id)
    if payment_status:
        query = query.filter(RoomAllocation.payment_status == payment_status)
        
    return query.offset(skip).limit(limit).all()

def update_allocation(
    db: Session,
    allocation_id: int,
    check_in_time: Optional[datetime] = None,
    check_out_time: Optional[datetime] = None,
    payment_status: Optional[str] = None,
    total_cost: Optional[float] = None
) -> Optional[RoomAllocation]:
    db_allocation = get_allocation(db, allocation_id)
    if not db_allocation:
        return None
    
    if check_in_time is not None:
        db_allocation.check_in_time = check_in_time
    if check_out_time is not None:
        db_allocation.check_out_time = check_out_time
    if payment_status is not None:
        db_allocation.payment_status = payment_status
    if total_cost is not None:
        db_allocation.total_cost = total_cost
    
    db.commit()
    db.refresh(db_allocation)
    return db_allocation

def delete_allocation(db: Session, allocation_id: int) -> bool:
    db_allocation = get_allocation(db, allocation_id)
    if not db_allocation:
        return False
    
    db.delete(db_allocation)
    db.commit()
    return True

def get_active_allocations_for_room(
    db: Session,
    room_id: int,
    current_time: Optional[datetime] = None
) -> List[RoomAllocation]:
    if current_time is None:
        current_time = datetime.now()
        
    return db.query(RoomAllocation).filter(
        RoomAllocation.room_id == room_id,
        RoomAllocation.check_in_time <= current_time,
        RoomAllocation.check_out_time >= current_time,
        RoomAllocation.payment_status != 'Cancelled'
    ).all()