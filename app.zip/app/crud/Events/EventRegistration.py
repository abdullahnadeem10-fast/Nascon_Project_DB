from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple
import uuid
from datetime import datetime

from models.events import EventRegistration as EventRegistrationModel
from models.events import Event as EventModel
from models.events import Team as TeamModel
from models.rbac import User as UserModel
from schemas.Events.EventRegistration import EventRegistrationCreate, EventRegistrationUpdate, PaymentStatus
from schemas.Finance.Payment import PaymentCreate, PaymentType, PaymentMethod

def generate_confirmation_code():
    """Generate a unique confirmation code"""
    return str(uuid.uuid4())[:8].upper()

def create_event_registration(db: Session, registration: EventRegistrationCreate) -> EventRegistrationModel:
    """
    Create a new event registration
    """
    try:
        # Check if event exists
        event = db.query(EventModel).filter(EventModel.id == registration.event_id).first()
        if not event:
            raise HTTPException(status_code=404, detail="Event not found")

        # Validate user or team
        if registration.user_id is not None and registration.team_id is not None:
            raise HTTPException(status_code=400, detail="Either user_id or team_id must be provided, but not both")

        if registration.user_id is None and registration.team_id is None:
            raise HTTPException(status_code=400, detail="Either user_id or team_id must be provided")

        # Check if user exists
        if registration.user_id is not None:
            user = db.query(UserModel).filter(UserModel.id == registration.user_id).first()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")

            # Check if user is already registered for this event
            existing_registration = db.query(EventRegistrationModel).filter(
                EventRegistrationModel.event_id == registration.event_id,
                EventRegistrationModel.user_id == registration.user_id
            ).first()

            if existing_registration:
                raise HTTPException(status_code=400, detail="User is already registered for this event")

            # Check if event is a team event
            if event.is_team_event:
                raise HTTPException(status_code=400, detail="This is a team event. Please register with a team.")

        # Check if team exists
        if registration.team_id is not None:
            team = db.query(TeamModel).filter(TeamModel.id == registration.team_id).first()
            if not team:
                raise HTTPException(status_code=404, detail="Team not found")

            # Check if team is already registered for this event
            existing_registration = db.query(EventRegistrationModel).filter(
                EventRegistrationModel.event_id == registration.event_id,
                EventRegistrationModel.team_id == registration.team_id
            ).first()

            if existing_registration:
                raise HTTPException(status_code=400, detail="Team is already registered for this event")

            # Check if event is not a team event
            if not event.is_team_event:
                raise HTTPException(status_code=400, detail="This is not a team event. Please register as an individual.")

            # Allow teams to register for any team event
            # No longer checking if team.event_id matches registration.event_id

        # Check if event has reached maximum participants
        current_registrations_count = db.query(EventRegistrationModel).filter(
            EventRegistrationModel.event_id == registration.event_id
        ).count()

        if current_registrations_count >= event.max_participants:
            raise HTTPException(status_code=400, detail="Event has reached maximum number of participants")

        # Generate confirmation code if not provided
        confirmation_code = registration.confirmation_code
        if not confirmation_code:
            confirmation_code = generate_confirmation_code()

            # Ensure confirmation code is unique
            while db.query(EventRegistrationModel).filter(
                EventRegistrationModel.confirmation_code == confirmation_code
            ).first():
                confirmation_code = generate_confirmation_code()

        # Always set payment status to PENDING initially
        # This will be updated to PAID only when the payment is approved
        payment_status = PaymentStatus.PENDING

        # Create new registration
        db_registration = EventRegistrationModel(
            event_id=registration.event_id,
            user_id=registration.user_id,
            team_id=registration.team_id,
            payment_status=payment_status,
            confirmation_code=confirmation_code
        )
        db.add(db_registration)
        db.commit()
        db.refresh(db_registration)

        # Create a payment record for this registration
        from crud.Finance.Payment import create_payment

        # Determine the user_id (either from individual registration or team leader)
        user_id = registration.user_id
        if registration.team_id is not None:
            # Get team leader's user_id
            team = db.query(TeamModel).filter(TeamModel.id == registration.team_id).first()
            team_members = team.members
            for member in team_members:
                if member.is_team_lead:
                    user_id = member.user_id
                    break

        # Create payment with PENDING status
        payment_data = PaymentCreate(
            amount=event.registration_fee,
            payment_method=PaymentMethod.CASH,  # Default payment method
            payment_type=PaymentType.EVENT_REGISTRATION,
            registration_id=db_registration.id,
            notes=f"Payment for event registration: {event.event_name}",
            user_id=user_id
        )

        create_payment(db, payment_data)

        return db_registration
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating event registration")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def get_event_registration(db: Session, registration_id: int) -> Optional[EventRegistrationModel]:
    """
    Get an event registration by ID
    """
    registration = db.query(EventRegistrationModel).filter(EventRegistrationModel.id == registration_id).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Event registration not found")
    return registration

def get_event_registration_with_details(db: Session, registration_id: int) -> Optional[EventRegistrationModel]:
    """
    Get an event registration by ID with related event, user, and team details
    """
    registration = db.query(EventRegistrationModel)\
        .options(
            joinedload(EventRegistrationModel.event),
            joinedload(EventRegistrationModel.participant),
            joinedload(EventRegistrationModel.team)
        )\
        .filter(EventRegistrationModel.id == registration_id)\
        .first()

    if not registration:
        raise HTTPException(status_code=404, detail="Event registration not found")
    return registration

def get_event_registration_by_confirmation_code(db: Session, confirmation_code: str) -> Optional[EventRegistrationModel]:
    """
    Get an event registration by confirmation code
    """
    registration = db.query(EventRegistrationModel)\
        .filter(EventRegistrationModel.confirmation_code == confirmation_code)\
        .first()

    if not registration:
        raise HTTPException(status_code=404, detail="Event registration not found")
    return registration

def get_event_registrations(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    filters: Dict[str, Any] = None
) -> Tuple[List[EventRegistrationModel], int]:
    """
    Get all event registrations with pagination and optional filtering
    """
    query = db.query(EventRegistrationModel)

    # Apply filters if provided
    if filters:
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(EventRegistrationModel.event_id == filters['event_id'])
        if 'user_id' in filters and filters['user_id']:
            query = query.filter(EventRegistrationModel.user_id == filters['user_id'])
        if 'team_id' in filters and filters['team_id']:
            # Handle team_id as a list or a single value
            if isinstance(filters['team_id'], list):
                query = query.filter(EventRegistrationModel.team_id.in_(filters['team_id']))
            else:
                query = query.filter(EventRegistrationModel.team_id == filters['team_id'])
        if 'payment_status' in filters and filters['payment_status']:
            query = query.filter(EventRegistrationModel.payment_status == filters['payment_status'])

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    registrations = query.offset(skip).limit(limit).all()

    return registrations, total

def get_event_registrations_with_names(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    filters: Dict[str, Any] = None
) -> Tuple[List[Dict], int]:
    """
    Get all event registrations with event and team names
    """
    # First get the registrations using the base function
    registrations, total = get_event_registrations(db, skip, limit, filters)

    # Now load the related entities and create detailed response
    result = []
    for reg in registrations:
        # Load event details if not already loaded
        if not hasattr(reg, 'event') or reg.event is None:
            event = db.query(EventModel).filter(EventModel.id == reg.event_id).first()
            event_name = event.event_name if event else "Unknown Event"
        else:
            event_name = reg.event.event_name

        # Load team details if applicable and not already loaded
        team_name = None
        if reg.team_id:
            if not hasattr(reg, 'team') or reg.team is None:
                team = db.query(TeamModel).filter(TeamModel.id == reg.team_id).first()
                team_name = team.team_name if team else "Unknown Team"
            else:
                team_name = reg.team.team_name

        # Load user details if applicable and not already loaded
        user_name = None
        if reg.user_id:
            if not hasattr(reg, 'participant') or reg.participant is None:
                from models.rbac import User
                user = db.query(User).filter(User.id == reg.user_id).first()
                user_name = user.username if user else "Unknown User"
            else:
                user_name = reg.participant.username

        # Create detailed registration object
        detail = {
            "id": reg.id,
            "event_id": reg.event_id,
            "user_id": reg.user_id,
            "team_id": reg.team_id,
            "payment_status": reg.payment_status,
            "confirmation_code": reg.confirmation_code,
            "registration_date": reg.registration_date,
            "event_name": event_name,
            "user_name": user_name,
            "team_name": team_name
        }
        result.append(detail)

    return result, total

def get_event_registrations_with_details(
    db: Session,
    event_id: int,
    skip: int = 0,
    limit: int = 100
) -> Tuple[List[Dict], int]:
    """
    Get all registrations for a specific event with user/team details
    """
    query = db.query(EventRegistrationModel)\
        .options(
            joinedload(EventRegistrationModel.event),
            joinedload(EventRegistrationModel.participant),
            joinedload(EventRegistrationModel.team)
        )\
        .filter(EventRegistrationModel.event_id == event_id)

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    registrations = query.offset(skip).limit(limit).all()

    # Create detailed response
    result = []
    for reg in registrations:
        detail = {
            "id": reg.id,
            "event_id": reg.event_id,
            "event_name": reg.event.event_name,
            "user_id": reg.user_id,
            "team_id": reg.team_id,
            "payment_status": reg.payment_status,
            "confirmation_code": reg.confirmation_code,
            "registration_date": reg.registration_date,
            "user_name": reg.participant.username if reg.participant else None,
            "team_name": reg.team.team_name if reg.team else None
        }
        result.append(detail)

    return result, total

def update_event_registration(db: Session, registration_id: int, registration: EventRegistrationUpdate) -> EventRegistrationModel:
    """
    Update an event registration
    """
    db_registration = get_event_registration(db, registration_id)

    try:
        # Update fields if provided
        if registration.payment_status is not None:
            db_registration.payment_status = registration.payment_status
        if registration.confirmation_code is not None:
            # Check if confirmation code is unique
            existing = db.query(EventRegistrationModel).filter(
                EventRegistrationModel.confirmation_code == registration.confirmation_code,
                EventRegistrationModel.id != registration_id
            ).first()

            if existing:
                raise HTTPException(status_code=400, detail="Confirmation code already exists")

            db_registration.confirmation_code = registration.confirmation_code

        db.commit()
        db.refresh(db_registration)
        return db_registration
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating event registration")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def update_payment_status(db: Session, registration_id: int, status: str) -> EventRegistrationModel:
    """
    Update the payment status of an event registration
    """
    db_registration = get_event_registration(db, registration_id)

    try:
        db_registration.payment_status = status
        db.commit()
        db.refresh(db_registration)
        return db_registration
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating payment status: {str(e)}")

def delete_event_registration(db: Session, registration_id: int) -> EventRegistrationModel:
    """
    Delete an event registration
    """
    db_registration = get_event_registration(db, registration_id)

    try:
        db.delete(db_registration)
        db.commit()
        return db_registration
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting event registration: {str(e)}")
