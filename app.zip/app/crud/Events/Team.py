from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple

from models.events import Team as TeamModel, TeamMember as TeamMemberModel, Event as EventModel
from schemas.Events.Team import TeamCreate, TeamUpdate
from schemas.Events.TeamMember import TeamMemberCreate
from crud.Events.TeamMember import create_team_member

def create_team(db: Session, team: TeamCreate, user_id: int) -> TeamModel:
    """
    Create a new team
    """
    try:
        # Check if event exists and is a team event
        event = db.query(EventModel).filter(EventModel.id == team.event_id).first()
        if not event:
            raise HTTPException(status_code=404, detail="Event not found")
        if not event.is_team_event:
            raise HTTPException(status_code=400, detail="This event does not support teams")

        # Check if team name already exists for this event
        existing_team = db.query(TeamModel).filter(
            TeamModel.team_name == team.team_name,
            TeamModel.event_id == team.event_id
        ).first()

        if existing_team:
            raise HTTPException(status_code=400, detail="Team with this name already exists for this event")

        # Create new team
        db_team = TeamModel(
            team_name=team.team_name,
            event_id=team.event_id,
            created_by=user_id
        )
        db.add(db_team)
        db.commit()
        db.refresh(db_team)

        # Add the creator as a team member
        create_team_member(db, TeamMemberCreate(
            team_id=db_team.id,
            user_id=user_id,
            is_team_lead=True  # Creator is the team lead
        ))

        return db_team
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating team")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def get_team(db: Session, team_id: int) -> Optional[TeamModel]:
    """
    Get a team by ID
    """
    team = db.query(TeamModel).filter(TeamModel.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")
    return team

def get_team_with_members(db: Session, team_id: int) -> Optional[TeamModel]:
    """
    Get a team by ID with all members
    """
    team = db.query(TeamModel)\
        .options(
            joinedload(TeamModel.members),
            joinedload(TeamModel.event)
        )\
        .filter(TeamModel.id == team_id)\
        .first()

    if not team:
        raise HTTPException(status_code=404, detail="Team not found")
    return team

def get_teams(db: Session, skip: int = 0, limit: int = 100, filters: Dict[str, Any] = None) -> Tuple[List[TeamModel], int]:
    """
    Get all teams with pagination and optional filtering
    """
    query = db.query(TeamModel)

    # Apply filters if provided
    if filters:
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(TeamModel.event_id == filters['event_id'])
        if 'created_by' in filters and filters['created_by']:
            query = query.filter(TeamModel.created_by == filters['created_by'])
        if 'user_id' in filters and filters['user_id']:
            # Teams where the user is a member
            query = query.join(TeamModel.members)\
                .filter(TeamMemberModel.user_id == filters['user_id'])

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    teams = query.offset(skip).limit(limit).all()

    return teams, total

def update_team(db: Session, team_id: int, team: TeamUpdate) -> TeamModel:
    """
    Update a team
    """
    db_team = get_team(db, team_id)

    try:
        # Update fields if provided
        if team.team_name is not None:
            # Check if team name already exists for this event
            if team.team_name != db_team.team_name:
                existing_team = db.query(TeamModel).filter(
                    TeamModel.team_name == team.team_name,
                    TeamModel.event_id == db_team.event_id
                ).first()

                if existing_team:
                    raise HTTPException(status_code=400, detail="Team with this name already exists for this event")

            db_team.team_name = team.team_name

        if team.event_id is not None:
            # Check if event exists and is a team event
            event = db.query(EventModel).filter(EventModel.id == team.event_id).first()
            if not event:
                raise HTTPException(status_code=404, detail="Event not found")
            if not event.is_team_event:
                raise HTTPException(status_code=400, detail="This event does not support teams")

            db_team.event_id = team.event_id

        db.commit()
        db.refresh(db_team)
        return db_team
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating team")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def delete_team(db: Session, team_id: int) -> TeamModel:
    """
    Delete a team
    """
    db_team = get_team(db, team_id)

    try:
        # Delete all team members first
        db.query(TeamMemberModel).filter(TeamMemberModel.team_id == team_id).delete()

        # Then delete the team
        db.delete(db_team)
        db.commit()
        return db_team
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting team: {str(e)}")


