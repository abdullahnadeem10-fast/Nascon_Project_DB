from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple

from models.events import TeamMember as TeamMemberModel, Team as TeamModel
from models.rbac import User as UserModel
from schemas.Events.TeamMember import TeamMemberCreate, TeamMemberUpdate

def create_team_member(db: Session, member: TeamMemberCreate) -> TeamMemberModel:
    """
    Add a member to a team
    """
    try:
        # Check if team exists
        team = db.query(TeamModel).filter(TeamModel.id == member.team_id).first()
        if not team:
            raise HTTPException(status_code=404, detail="Team not found")
        
        # Check if user exists
        user = db.query(UserModel).filter(UserModel.id == member.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check if user is already a member of this team
        existing_member = db.query(TeamMemberModel).filter(
            TeamMemberModel.team_id == member.team_id,
            TeamMemberModel.user_id == member.user_id
        ).first()
        
        if existing_member:
            raise HTTPException(status_code=400, detail="User is already a member of this team")
        
        # Check team size limit
        current_members_count = db.query(TeamMemberModel).filter(
            TeamMemberModel.team_id == member.team_id
        ).count()
        
        if team.event.max_team_size and current_members_count >= team.event.max_team_size:
            raise HTTPException(status_code=400, detail=f"Team has reached the maximum size of {team.event.max_team_size}")
        
        # Create new team member
        db_member = TeamMemberModel(
            team_id=member.team_id,
            user_id=member.user_id,
            is_team_lead=member.is_team_lead
        )
        db.add(db_member)
        db.commit()
        db.refresh(db_member)
        return db_member
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error adding team member")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def get_team_member(db: Session, member_id: int) -> Optional[TeamMemberModel]:
    """
    Get a team member by ID
    """
    member = db.query(TeamMemberModel).filter(TeamMemberModel.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Team member not found")
    return member

def get_team_member_with_user(db: Session, member_id: int) -> Optional[TeamMemberModel]:
    """
    Get a team member by ID with user details
    """
    member = db.query(TeamMemberModel)\
        .options(
            joinedload(TeamMemberModel.user),
            joinedload(TeamMemberModel.team)
        )\
        .filter(TeamMemberModel.id == member_id)\
        .first()
    
    if not member:
        raise HTTPException(status_code=404, detail="Team member not found")
    return member

def get_team_members(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[TeamMemberModel], int]:
    """
    Get all team members with pagination and optional filtering
    """
    query = db.query(TeamMemberModel)
    
    # Apply filters if provided
    if filters:
        if 'team_id' in filters and filters['team_id']:
            query = query.filter(TeamMemberModel.team_id == filters['team_id'])
        if 'user_id' in filters and filters['user_id']:
            query = query.filter(TeamMemberModel.user_id == filters['user_id'])
        if 'is_team_lead' in filters and filters['is_team_lead'] is not None:
            query = query.filter(TeamMemberModel.is_team_lead == filters['is_team_lead'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    members = query.offset(skip).limit(limit).all()
    
    return members, total

def get_team_members_with_users(
    db: Session, 
    team_id: int,
    skip: int = 0, 
    limit: int = 100
) -> Tuple[List[TeamMemberModel], int]:
    """
    Get all members of a specific team with user details
    """
    query = db.query(TeamMemberModel)\
        .options(
            joinedload(TeamMemberModel.user),
            joinedload(TeamMemberModel.team)
        )\
        .filter(TeamMemberModel.team_id == team_id)
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    members = query.offset(skip).limit(limit).all()
    
    return members, total

def update_team_member(db: Session, member_id: int, member: TeamMemberUpdate) -> TeamMemberModel:
    """
    Update a team member
    """
    db_member = get_team_member(db, member_id)
    
    try:
        # Update fields if provided
        if member.is_team_lead is not None:
            db_member.is_team_lead = member.is_team_lead
        
        db.commit()
        db.refresh(db_member)
        return db_member
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating team member: {str(e)}")

def delete_team_member(db: Session, member_id: int) -> TeamMemberModel:
    """
    Remove a member from a team
    """
    db_member = get_team_member(db, member_id)
    
    try:
        # Check if this is the last member (team lead)
        team_members_count = db.query(TeamMemberModel).filter(
            TeamMemberModel.team_id == db_member.team_id
        ).count()
        
        if team_members_count <= 1:
            raise HTTPException(status_code=400, detail="Cannot remove the last team member. Delete the team instead.")
        
        # If this is the team lead and there are other members, make sure there's another team lead
        if db_member.is_team_lead:
            other_leads = db.query(TeamMemberModel).filter(
                TeamMemberModel.team_id == db_member.team_id,
                TeamMemberModel.id != db_member.id,
                TeamMemberModel.is_team_lead == True
            ).count()
            
            if other_leads == 0:
                raise HTTPException(status_code=400, detail="Cannot remove the only team lead. Assign another member as team lead first.")
        
        # Store a copy for return value
        member_copy = TeamMemberModel(
            id=db_member.id,
            team_id=db_member.team_id,
            user_id=db_member.user_id,
            is_team_lead=db_member.is_team_lead,
            joined_at=db_member.joined_at
        )
        
        db.delete(db_member)
        db.commit()
        return member_copy
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"Error removing team member: {str(e)}")

def make_team_lead(db: Session, member_id: int) -> TeamMemberModel:
    """
    Make a team member the team lead
    """
    db_member = get_team_member(db, member_id)
    
    try:
        # If already team lead, just return
        if db_member.is_team_lead:
            return db_member
        
        # Update this member to be team lead
        db_member.is_team_lead = True
        db.commit()
        db.refresh(db_member)
        return db_member
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating team lead: {str(e)}")
