from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Tuple

from models.events import EventCategory as EventCategoryModel, Event as EventModel
from schemas.Events.EventCategory import EventCategoryCreate, EventCategoryUpdate

def create_event_category(db: Session, category: EventCategoryCreate) -> EventCategoryModel:
    """
    Create a new event category
    """
    try:
        # Check if category with same name already exists
        existing = get_event_category_by_name(db, category.category_name)
        if existing:
            raise HTTPException(status_code=400, detail="Category with this name already exists")

        # Create new category
        db_category = EventCategoryModel(
            category_name=category.category_name,
            description=category.description
        )
        db.add(db_category)
        db.commit()
        db.refresh(db_category)
        return db_category
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Category with this name already exists")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_event_category(db: Session, category_id: int) -> Optional[EventCategoryModel]:
    """
    Get an event category by ID
    """
    category = db.query(EventCategoryModel).filter(EventCategoryModel.id == category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Event category not found")
    return category

def get_event_category_by_name(db: Session, category_name: str) -> Optional[EventCategoryModel]:
    """
    Get an event category by name
    """
    return db.query(EventCategoryModel).filter(EventCategoryModel.category_name == category_name).first()

def get_event_categories(db: Session, skip: int = 0, limit: int = 100) -> List[EventCategoryModel]:
    """
    Get all event categories with pagination
    """
    return db.query(EventCategoryModel).offset(skip).limit(limit).all()

def update_event_category(db: Session, category_id: int, category: EventCategoryUpdate) -> EventCategoryModel:
    """
    Update an event category
    """
    db_category = get_event_category(db, category_id)
    if not db_category:
        raise HTTPException(status_code=404, detail="Event category not found")

    try:
        # Check if updating to a name that already exists
        if category.category_name and category.category_name != db_category.category_name:
            existing = get_event_category_by_name(db, category.category_name)
            if existing:
                raise HTTPException(status_code=400, detail="Category with this name already exists")

        # Update fields
        update_data = category.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_category, field, value)

        db.commit()
        db.refresh(db_category)
        return db_category
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Category with this name already exists")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_event_category(db: Session, category_id: int) -> EventCategoryModel:
    """
    Delete an event category and all associated events and teams
    """
    from models.events import Team as TeamModel, TeamMember as TeamMemberModel

    db_category = db.query(EventCategoryModel).filter(EventCategoryModel.id == category_id).first()
    if not db_category:
        raise HTTPException(status_code=404, detail="Event category not found")

    try:
        # Store a copy of the category before deleting
        category_copy = db_category

        # Find all events associated with this category
        events = db.query(EventModel).filter(EventModel.category_id == category_id).all()

        # For each event, delete all associated teams and team members
        for event in events:
            # Find all teams associated with this event
            teams = db.query(TeamModel).filter(TeamModel.event_id == event.id).all()

            # For each team, delete all team members first
            for team in teams:
                # Delete all team members
                db.query(TeamMemberModel).filter(TeamMemberModel.team_id == team.id).delete()

                # Delete the team
                db.delete(team)

            # Delete the event
            db.delete(event)

        # Delete the category
        db.delete(db_category)
        db.commit()

        return category_copy
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting category: {str(e)}")
