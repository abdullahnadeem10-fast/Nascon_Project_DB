from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime

from models.events import EventSchedule as EventScheduleModel, Event, Venue
from schemas.Events.EventSchedule import EventScheduleCreate, EventScheduleUpdate

def create_event_schedule(db: Session, schedule: EventScheduleCreate) -> EventScheduleModel:
    """
    Create a new event schedule
    """
    try:
        # Validate time range
        if schedule.end_time <= schedule.start_time:
            raise HTTPException(status_code=400, detail="End time must be after start time")

        # Check for scheduling conflicts
        conflicts = check_scheduling_conflicts(
            db,
            venue_id=schedule.venue_id,
            start_time=schedule.start_time,
            end_time=schedule.end_time
        )

        if conflicts:
            raise HTTPException(status_code=400, detail="Scheduling conflict detected with existing events")

        # Create new schedule
        db_schedule = EventScheduleModel(
            event_id=schedule.event_id,
            venue_id=schedule.venue_id,
            start_time=schedule.start_time,
            end_time=schedule.end_time,
            round_name=schedule.round_name.value
        )
        db.add(db_schedule)
        db.commit()
        db.refresh(db_schedule)
        return db_schedule
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating event schedule")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def get_event_schedule(db: Session, schedule_id: int) -> Optional[EventScheduleModel]:
    """
    Get an event schedule by ID
    """
    schedule = db.query(EventScheduleModel).filter(EventScheduleModel.id == schedule_id).first()
    if not schedule:
        raise HTTPException(status_code=404, detail="Event schedule not found")
    return schedule

def get_event_schedule_with_details(db: Session, schedule_id: int) -> Optional[EventScheduleModel]:
    """
    Get an event schedule by ID with related event and venue details
    """
    schedule = db.query(EventScheduleModel)\
        .options(
            joinedload(EventScheduleModel.event),
            joinedload(EventScheduleModel.venue)
        )\
        .filter(EventScheduleModel.id == schedule_id)\
        .first()

    if not schedule:
        raise HTTPException(status_code=404, detail="Event schedule not found")
    return schedule

def get_event_schedules(db: Session, skip: int = 0, limit: int = 100, filters: Dict[str, Any] = None) -> Tuple[List[Dict], int]:
    """
    Get all event schedules with pagination and optional filtering
    Returns schedules with event and venue names
    """
    # Query with joins to get event and venue names
    query = db.query(
        EventScheduleModel,
        Event.event_name,
        Venue.venue_name
    ).join(
        Event, EventScheduleModel.event_id == Event.id
    ).join(
        Venue, EventScheduleModel.venue_id == Venue.id
    )

    # Apply filters if provided
    if filters:
        if 'round_name' in filters and filters['round_name']:
            query = query.filter(EventScheduleModel.round_name == filters['round_name'])
        if 'date' in filters and filters['date']:
            # Filter by date (ignoring time)
            date = filters['date']
            query = query.filter(
                db.func.date(EventScheduleModel.start_time) == date
            )

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    results = query.offset(skip).limit(limit).all()

    # Convert results to list of dictionaries with event and venue names
    schedules = []
    for result in results:
        schedule, event_name, venue_name = result

        schedules.append({
            "id": schedule.id,
            "event_id": schedule.event_id,
            "venue_id": schedule.venue_id,
            "start_time": schedule.start_time,
            "end_time": schedule.end_time,
            "round_name": schedule.round_name,
            "event_name": event_name,
            "venue_name": venue_name
        })

    return schedules, total

def update_event_schedule(db: Session, schedule_id: int, schedule: EventScheduleUpdate) -> EventScheduleModel:
    """
    Update an event schedule
    """
    db_schedule = get_event_schedule(db, schedule_id)

    # Prepare update data
    update_data = {}
    if schedule.event_id is not None:
        update_data['event_id'] = schedule.event_id
    if schedule.venue_id is not None:
        update_data['venue_id'] = schedule.venue_id
    if schedule.start_time is not None:
        update_data['start_time'] = schedule.start_time
    if schedule.end_time is not None:
        update_data['end_time'] = schedule.end_time
    if schedule.round_name is not None:
        update_data['round_name'] = schedule.round_name.value

    # Check if we need to validate time range and conflicts
    if ('start_time' in update_data or 'end_time' in update_data):
        start_time = update_data.get('start_time', db_schedule.start_time)
        end_time = update_data.get('end_time', db_schedule.end_time)

        # Validate time range
        if end_time <= start_time:
            raise HTTPException(status_code=400, detail="End time must be after start time")

        # Check for scheduling conflicts
        venue_id = update_data.get('venue_id', db_schedule.venue_id)
        conflicts = check_scheduling_conflicts(
            db,
            venue_id=venue_id,
            start_time=start_time,
            end_time=end_time,
            exclude_schedule_id=schedule_id
        )

        if conflicts:
            raise HTTPException(status_code=400, detail="Scheduling conflict detected with existing events")

    try:
        # Update fields
        for key, value in update_data.items():
            setattr(db_schedule, key, value)

        db.commit()
        db.refresh(db_schedule)
        return db_schedule
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating event schedule")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def delete_event_schedule(db: Session, schedule_id: int) -> EventScheduleModel:
    """
    Delete an event schedule
    """
    db_schedule = get_event_schedule(db, schedule_id)

    try:
        db.delete(db_schedule)
        db.commit()
        return db_schedule
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting event schedule: {str(e)}")

def check_scheduling_conflicts(db: Session, venue_id: int, start_time: datetime, end_time: datetime, exclude_schedule_id: Optional[int] = None) -> bool:
    """
    Check if there are any scheduling conflicts for a venue at the given time range
    """
    query = db.query(EventScheduleModel).filter(
        EventScheduleModel.venue_id == venue_id,
        # Check if the new schedule overlaps with any existing schedule
        # (new_start < existing_end) AND (new_end > existing_start)
        start_time < EventScheduleModel.end_time,
        end_time > EventScheduleModel.start_time
    )

    # Exclude the current schedule if updating
    if exclude_schedule_id:
        query = query.filter(EventScheduleModel.id != exclude_schedule_id)

    # If any results are found, there's a conflict
    return query.first() is not None
