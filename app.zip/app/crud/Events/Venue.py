from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple

from models.events import Venue as VenueModel
from schemas.Events.Venue import VenueCreate, VenueUpdate

def create_venue(db: Session, venue: VenueCreate) -> VenueModel:
    """
    Create a new venue
    """
    try:
        # Create new venue
        db_venue = VenueModel(
            venue_name=venue.venue_name,
            location=venue.location,
            capacity=venue.capacity,
            description=venue.description,
            venue_type=venue.venue_type.value
        )
        db.add(db_venue)
        db.commit()
        db.refresh(db_venue)
        return db_venue
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating venue")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_venue(db: Session, venue_id: int) -> Optional[VenueModel]:
    """
    Get a venue by ID
    """
    venue = db.query(VenueModel).filter(VenueModel.id == venue_id).first()
    if not venue:
        raise HTTPException(status_code=404, detail="Venue not found")
    return venue

def get_venue_with_schedules(db: Session, venue_id: int) -> Optional[VenueModel]:
    """
    Get a venue by ID with all related schedules
    """
    venue = db.query(VenueModel)\
        .options(
            joinedload(VenueModel.schedules)
        )\
        .filter(VenueModel.id == venue_id)\
        .first()
    
    if not venue:
        raise HTTPException(status_code=404, detail="Venue not found")
    return venue

def get_venues(db: Session, skip: int = 0, limit: int = 100, filters: Dict[str, Any] = None) -> Tuple[List[VenueModel], int]:
    """
    Get all venues with pagination and optional filtering
    """
    query = db.query(VenueModel)
    
    # Apply filters if provided
    if filters:
        if 'venue_type' in filters and filters['venue_type']:
            query = query.filter(VenueModel.venue_type == filters['venue_type'])
        if 'min_capacity' in filters and filters['min_capacity']:
            query = query.filter(VenueModel.capacity >= filters['min_capacity'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    venues = query.offset(skip).limit(limit).all()
    
    return venues, total

def update_venue(db: Session, venue_id: int, venue: VenueUpdate) -> VenueModel:
    """
    Update a venue
    """
    db_venue = get_venue(db, venue_id)
    
    # Update fields if provided
    if venue.venue_name is not None:
        db_venue.venue_name = venue.venue_name
    if venue.location is not None:
        db_venue.location = venue.location
    if venue.capacity is not None:
        db_venue.capacity = venue.capacity
    if venue.description is not None:
        db_venue.description = venue.description
    if venue.venue_type is not None:
        db_venue.venue_type = venue.venue_type.value
    
    try:
        db.commit()
        db.refresh(db_venue)
        return db_venue
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating venue")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_venue(db: Session, venue_id: int) -> VenueModel:
    """
    Delete a venue
    """
    db_venue = get_venue(db, venue_id)
    
    try:
        db.delete(db_venue)
        db.commit()
        return db_venue
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting venue: {str(e)}")
