from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple

from models.events import Event as EventModel
from schemas.Events.Events import EventCreate, EventUpdate

def create_event(db: Session, event: EventCreate, user_id: int) -> EventModel:
    """
    Create a new event
    """
    try:
        # Create new event
        db_event = EventModel(
            event_name=event.event_name,
            description=event.description,
            rules=event.rules,
            max_participants=event.max_participants,
            registration_fee=event.registration_fee,
            registration_deadline=event.registration_deadline,
            category_id=event.category_id,
            is_team_event=event.is_team_event,
            min_team_size=event.min_team_size,
            max_team_size=event.max_team_size,
            created_by=user_id
        )
        db.add(db_event)
        db.commit()
        db.refresh(db_event)
        return db_event
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating event")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_event(db: Session, event_id: int) -> Optional[EventModel]:
    """
    Get an event by ID
    """
    event = db.query(EventModel).filter(EventModel.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event

def get_event_with_details(db: Session, event_id: int) -> Optional[EventModel]:
    """
    Get an event by ID with all related details
    """
    event = db.query(EventModel)\
        .options(
            joinedload(EventModel.category),
            joinedload(EventModel.creator),
            joinedload(EventModel.schedules),
            joinedload(EventModel.evaluation_criteria)
        )\
        .filter(EventModel.id == event_id)\
        .first()

    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event

def get_events(db: Session, skip: int = 0, limit: int = 100, filters: Dict[str, Any] = None) -> Tuple[List[EventModel], int]:
    """
    Get all events with pagination and optional filtering
    Returns a tuple of (events, total_count)
    """
    query = db.query(EventModel)

    # Apply filters if provided
    if filters:
        if 'category_id' in filters and filters['category_id']:
            query = query.filter(EventModel.category_id == filters['category_id'])
        if 'is_team_event' in filters and filters['is_team_event'] is not None:
            query = query.filter(EventModel.is_team_event == filters['is_team_event'])

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    events = query.offset(skip).limit(limit).all()

    return events, total

def update_event(db: Session, event_id: int, event: EventUpdate) -> EventModel:
    """
    Update an event
    """
    db_event = get_event(db, event_id)

    # Update fields if provided
    if event.event_name is not None:
        db_event.event_name = event.event_name
    if event.description is not None:
        db_event.description = event.description
    if event.rules is not None:
        db_event.rules = event.rules
    if event.max_participants is not None:
        db_event.max_participants = event.max_participants
    if event.registration_fee is not None:
        db_event.registration_fee = event.registration_fee
    if event.registration_deadline is not None:
        db_event.registration_deadline = event.registration_deadline
    if event.category_id is not None:
        db_event.category_id = event.category_id
    if event.is_team_event is not None:
        db_event.is_team_event = event.is_team_event
    if event.min_team_size is not None:
        db_event.min_team_size = event.min_team_size
    if event.max_team_size is not None:
        db_event.max_team_size = event.max_team_size

    try:
        db.commit()
        db.refresh(db_event)
        return db_event
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating event")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_event(db: Session, event_id: int) -> EventModel:
    """
    Delete an event
    """
    db_event = get_event(db, event_id)

    try:
        db.delete(db_event)
        db.commit()
        return db_event
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting event: {str(e)}")

def get_unscheduled_events(db: Session, skip: int = 0, limit: int = 100, filters: Dict[str, Any] = None) -> Tuple[List[EventModel], int]:
    """
    Get all events that haven't been scheduled yet
    Returns a tuple of (events, total_count)

    Parameters:
    - db: Database session
    - skip: Number of records to skip (for pagination)
    - limit: Maximum number of records to return (for pagination)
    - filters: Optional dictionary of filters to apply (category_id, is_team_event)
    """
    # Import necessary modules
    from models.events import EventSchedule

    # Subquery to get all event IDs that have schedules
    scheduled_event_ids = db.query(EventSchedule.event_id).distinct().subquery()

    # Main query to get events that are not in the scheduled events subquery
    query = db.query(EventModel).filter(
        ~EventModel.id.in_(scheduled_event_ids)
    )

    # Apply additional filters if provided
    if filters:
        if 'category_id' in filters and filters['category_id']:
            query = query.filter(EventModel.category_id == filters['category_id'])
        if 'is_team_event' in filters and filters['is_team_event'] is not None:
            query = query.filter(EventModel.is_team_event == filters['is_team_event'])

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    events = query.offset(skip).limit(limit).all()

    return events, total
