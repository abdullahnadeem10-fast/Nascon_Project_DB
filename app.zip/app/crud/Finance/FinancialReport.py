from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, and_, desc, cast, Date
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, date, timedelta
from decimal import Decimal

from models.finance import FinancialReport as FinancialReportModel, Payment, Expense
from schemas.Finance.FinancialReport import FinancialReportCreate, FinancialReportUpdate

def create_financial_report(db: Session, report: FinancialReportCreate) -> FinancialReportModel:
    """
    Create a new financial report
    """
    try:
        # Validate net profit calculation
        if report.net_profit != (report.total_income - report.total_expense):
            raise HTTPException(
                status_code=400,
                detail="Net profit must equal total income minus total expenses"
            )

        # Create new financial report
        db_report = FinancialReportModel(
            report_name=report.report_name,
            report_type=report.report_type,
            start_date=report.start_date,
            end_date=report.end_date,
            total_income=report.total_income,
            total_expense=report.total_expense,
            net_profit=report.net_profit,
            report_data=report.report_data,
            generated_by=report.generated_by
        )
        db.add(db_report)
        db.commit()
        db.refresh(db_report)
        return db_report
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating financial report")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def get_financial_report(db: Session, report_id: int) -> Optional[FinancialReportModel]:
    """
    Get a financial report by ID
    """
    report = db.query(FinancialReportModel).filter(FinancialReportModel.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Financial report not found")
    return report

def get_financial_report_with_generator(db: Session, report_id: int) -> Optional[FinancialReportModel]:
    """
    Get a financial report by ID with generator details
    """
    report = db.query(FinancialReportModel)\
        .options(joinedload(FinancialReportModel.generator))\
        .filter(FinancialReportModel.id == report_id)\
        .first()

    if not report:
        raise HTTPException(status_code=404, detail="Financial report not found")
    return report

def get_financial_reports(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    filters: Dict[str, Any] = None
) -> Tuple[List[FinancialReportModel], int]:
    """
    Get all financial reports with pagination and optional filtering
    """
    query = db.query(FinancialReportModel)

    # Apply filters if provided
    if filters:
        if 'report_type' in filters and filters['report_type']:
            query = query.filter(FinancialReportModel.report_type == filters['report_type'])
        if 'generated_by' in filters and filters['generated_by']:
            query = query.filter(FinancialReportModel.generated_by == filters['generated_by'])
        if 'start_date' in filters and filters['start_date']:
            query = query.filter(FinancialReportModel.start_date >= filters['start_date'])
        if 'end_date' in filters and filters['end_date']:
            query = query.filter(FinancialReportModel.end_date <= filters['end_date'])
        if 'min_income' in filters and filters['min_income']:
            query = query.filter(FinancialReportModel.total_income >= filters['min_income'])
        if 'max_income' in filters and filters['max_income']:
            query = query.filter(FinancialReportModel.total_income <= filters['max_income'])
        if 'min_expense' in filters and filters['min_expense']:
            query = query.filter(FinancialReportModel.total_expense >= filters['min_expense'])
        if 'max_expense' in filters and filters['max_expense']:
            query = query.filter(FinancialReportModel.total_expense <= filters['max_expense'])
        if 'min_profit' in filters and filters['min_profit']:
            query = query.filter(FinancialReportModel.net_profit >= filters['min_profit'])
        if 'max_profit' in filters and filters['max_profit']:
            query = query.filter(FinancialReportModel.net_profit <= filters['max_profit'])
        if 'search' in filters and filters['search']:
            search_term = f"%{filters['search']}%"
            query = query.filter(FinancialReportModel.report_name.ilike(search_term))

    # Get total count before pagination
    total = query.count()

    # Apply pagination and ordering
    reports = query.order_by(desc(FinancialReportModel.generated_at)).offset(skip).limit(limit).all()

    return reports, total

def get_financial_reports_with_generators(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    filters: Dict[str, Any] = None
) -> Tuple[List[FinancialReportModel], int]:
    """
    Get all financial reports with generator details
    """
    query = db.query(FinancialReportModel)\
        .options(joinedload(FinancialReportModel.generator))

    # Apply filters if provided
    if filters:
        if 'report_type' in filters and filters['report_type']:
            query = query.filter(FinancialReportModel.report_type == filters['report_type'])
        if 'generated_by' in filters and filters['generated_by']:
            query = query.filter(FinancialReportModel.generated_by == filters['generated_by'])
        if 'start_date' in filters and filters['start_date']:
            query = query.filter(FinancialReportModel.start_date >= filters['start_date'])
        if 'end_date' in filters and filters['end_date']:
            query = query.filter(FinancialReportModel.end_date <= filters['end_date'])
        if 'search' in filters and filters['search']:
            search_term = f"%{filters['search']}%"
            query = query.filter(FinancialReportModel.report_name.ilike(search_term))

    # Get total count before pagination
    total = query.count()

    # Apply pagination and ordering
    reports = query.order_by(desc(FinancialReportModel.generated_at)).offset(skip).limit(limit).all()

    return reports, total

def get_latest_financial_reports(
    db: Session,
    report_type: str = None,
    limit: int = 5
) -> List[FinancialReportModel]:
    """
    Get the latest financial reports of a specific type
    """
    query = db.query(FinancialReportModel)

    if report_type:
        query = query.filter(FinancialReportModel.report_type == report_type)

    reports = query.order_by(desc(FinancialReportModel.generated_at)).limit(limit).all()

    return reports

def generate_periodic_report(
    db: Session,
    report_type: str,
    start_date: date,
    end_date: date,
    user_id: int,
    report_name: Optional[str] = None
) -> FinancialReportModel:
    """
    Generate a periodic financial report (daily, weekly, monthly)
    Calculates actual financial data from payment records and expenses
    """

    # Calculate report name if not provided
    if not report_name:
        if report_type == "Daily":
            report_name = f"Daily Report - {start_date.strftime('%Y-%m-%d')}"
        elif report_type == "Weekly":
            report_name = f"Weekly Report - {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}"
        elif report_type == "Monthly":
            report_name = f"Monthly Report - {start_date.strftime('%B %Y')}"
        else:
            report_name = f"Financial Report - {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}"

    # Calculate total income from completed payments
    # Convert datetime to date for comparison with start_date and end_date
    payments_query = db.query(
        Payment.payment_type,
        func.sum(Payment.amount).label("total")
    ).filter(
        and_(
            cast(Payment.payment_date, Date) >= start_date,
            cast(Payment.payment_date, Date) <= end_date,
            Payment.status == 'Completed'  # Only count completed payments
        )
    ).group_by(Payment.payment_type)

    payment_results = payments_query.all()

    # Initialize income sources dictionary
    income_sources = {
        "Registration": 0.0,
        "Accommodation": 0.0,
        "Sponsorship": 0.0,
        "Other": 0.0
    }

    # Populate income sources from query results
    total_income = Decimal('0.0')
    for payment_type, amount in payment_results:
        income_sources[payment_type] = float(amount)
        total_income += amount

    # Calculate total expenses from approved expenses
    expenses_query = db.query(
        Expense.expense_category,
        func.sum(Expense.amount).label("total")
    ).filter(
        and_(
            Expense.expense_date >= start_date,
            Expense.expense_date <= end_date,
            Expense.approval_status == 'Approved'  # Only count approved expenses
        )
    ).group_by(Expense.expense_category)

    expense_results = expenses_query.all()

    # Initialize expense categories dictionary
    expense_categories = {
        "Venue": 0.0,
        "Catering": 0.0,
        "Marketing": 0.0,
        "Equipment": 0.0,
        "Transport": 0.0,
        "Miscellaneous": 0.0
    }

    # Populate expense categories from query results
    total_expense = Decimal('0.0')
    for expense_category, amount in expense_results:
        expense_categories[expense_category.value] = float(amount)
        total_expense += amount

    # Calculate net profit
    net_profit = total_income - total_expense

    # Create detailed report data
    report_data = {
        "income_sources": income_sources,
        "expense_categories": expense_categories,
        "summary": {
            "total_payments": db.query(Payment).filter(
                and_(
                    cast(Payment.payment_date, Date) >= start_date,
                    cast(Payment.payment_date, Date) <= end_date,
                    Payment.status == 'Completed'
                )
            ).count(),
            "total_expenses": db.query(Expense).filter(
                and_(
                    Expense.expense_date >= start_date,
                    Expense.expense_date <= end_date,
                    Expense.approval_status == 'Approved'
                )
            ).count(),
            "pending_payments": db.query(Payment).filter(
                and_(
                    cast(Payment.payment_date, Date) >= start_date,
                    cast(Payment.payment_date, Date) <= end_date,
                    Payment.status == 'Pending'
                )
            ).count(),
            "pending_expenses": db.query(Expense).filter(
                and_(
                    Expense.expense_date >= start_date,
                    Expense.expense_date <= end_date,
                    Expense.approval_status == 'Pending'
                )
            ).count()
        }
    }

    # Create report
    report = FinancialReportCreate(
        report_name=report_name,
        report_type=report_type,
        start_date=start_date,
        end_date=end_date,
        total_income=float(total_income),
        total_expense=float(total_expense),
        net_profit=float(net_profit),
        report_data=report_data,
        generated_by=user_id
    )

    return create_financial_report(db, report)

def generate_event_report(
    db: Session,
    event_id: int,
    user_id: int,
    report_name: Optional[str] = None
) -> FinancialReportModel:
    """
    Generate a financial report for a specific event
    Calculates actual financial data from payment records and expenses related to the event
    """
    # Import necessary models
    from models.events import Event, EventRegistration

    # Get event details
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    # Use event start and end dates for the report period
    start_date = event.start_date
    end_date = event.end_date

    # If event hasn't ended yet, use current date as end_date
    if end_date > datetime.now().date():
        end_date = datetime.now().date()

    # Calculate report name if not provided
    if not report_name:
        report_name = f"Event Financial Report - {event.name}"

    # Get all registrations for this event
    registrations = db.query(EventRegistration.id).filter(EventRegistration.event_id == event_id).all()
    registration_ids = [reg.id for reg in registrations]

    # Calculate total income from completed payments for this event
    payments_query = db.query(
        Payment.payment_type,
        func.sum(Payment.amount).label("total")
    ).filter(
        and_(
            Payment.registration_id.in_(registration_ids),
            Payment.status == 'Completed'  # Only count completed payments
        )
    ).group_by(Payment.payment_type)

    payment_results = payments_query.all()

    # Initialize income sources dictionary
    income_sources = {
        "Registration": 0.0,
        "Accommodation": 0.0,
        "Sponsorship": 0.0,
        "Other": 0.0
    }

    # Populate income sources from query results
    total_income = Decimal('0.0')
    for payment_type, amount in payment_results:
        income_sources[payment_type] = float(amount)
        total_income += amount

    # Calculate total expenses for this event
    # For simplicity, we'll assume expenses are tagged with event_id
    # In a real application, you might need a more complex query or a relationship between events and expenses
    expenses_query = db.query(
        Expense.expense_category,
        func.sum(Expense.amount).label("total")
    ).filter(
        and_(
            Expense.expense_date >= start_date,
            Expense.expense_date <= end_date,
            Expense.approval_status == 'Approved'  # Only count approved expenses
        )
    ).group_by(Expense.expense_category)

    expense_results = expenses_query.all()

    # Initialize expense categories dictionary
    expense_categories = {
        "Venue": 0.0,
        "Catering": 0.0,
        "Marketing": 0.0,
        "Equipment": 0.0,
        "Transport": 0.0,
        "Miscellaneous": 0.0
    }

    # Populate expense categories from query results
    total_expense = Decimal('0.0')
    for expense_category, amount in expense_results:
        expense_categories[expense_category.value] = float(amount)
        total_expense += amount

    # Calculate net profit
    net_profit = total_income - total_expense

    # Create detailed report data
    report_data = {
        "event_id": event_id,
        "event_name": event.name,
        "event_dates": {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        },
        "income_sources": income_sources,
        "expense_categories": expense_categories,
        "summary": {
            "total_registrations": len(registration_ids),
            "total_payments": db.query(Payment).filter(
                and_(
                    Payment.registration_id.in_(registration_ids),
                    Payment.status == 'Completed'
                )
            ).count(),
            "total_expenses": db.query(Expense).filter(
                and_(
                    Expense.expense_date >= start_date,
                    Expense.expense_date <= end_date,
                    Expense.approval_status == 'Approved'
                )
            ).count(),
            "pending_payments": db.query(Payment).filter(
                and_(
                    Payment.registration_id.in_(registration_ids),
                    Payment.status == 'Pending'
                )
            ).count()
        }
    }

    # Create report
    report = FinancialReportCreate(
        report_name=report_name,
        report_type="Event-specific",
        start_date=start_date,
        end_date=end_date,
        total_income=float(total_income),
        total_expense=float(total_expense),
        net_profit=float(net_profit),
        report_data=report_data,
        generated_by=user_id
    )

    return create_financial_report(db, report)

def update_financial_report(db: Session, report_id: int, report: FinancialReportUpdate) -> FinancialReportModel:
    """
    Update a financial report
    """
    db_report = get_financial_report(db, report_id)

    try:
        # Update fields if provided
        if report.report_name is not None:
            db_report.report_name = report.report_name
        if report.report_type is not None:
            db_report.report_type = report.report_type
        if report.start_date is not None:
            db_report.start_date = report.start_date
        if report.end_date is not None:
            # Validate end_date is after start_date
            if report.end_date < (report.start_date or db_report.start_date):
                raise HTTPException(status_code=400, detail="End date cannot be before start date")
            db_report.end_date = report.end_date

        # Update financial values
        update_income = report.total_income is not None
        update_expense = report.total_expense is not None
        update_profit = report.net_profit is not None

        if update_income:
            db_report.total_income = report.total_income
        if update_expense:
            db_report.total_expense = report.total_expense

        # If income or expense is updated, recalculate net profit unless explicitly provided
        if (update_income or update_expense) and not update_profit:
            db_report.net_profit = db_report.total_income - db_report.total_expense
        elif update_profit:
            # Validate net profit calculation
            calculated_profit = (
                report.total_income if update_income else db_report.total_income
            ) - (
                report.total_expense if update_expense else db_report.total_expense
            )
            if report.net_profit != calculated_profit:
                raise HTTPException(
                    status_code=400,
                    detail="Net profit must equal total income minus total expenses"
                )
            db_report.net_profit = report.net_profit

        if report.report_data is not None:
            db_report.report_data = report.report_data

        db.commit()
        db.refresh(db_report)
        return db_report
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating financial report")
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def delete_financial_report(db: Session, report_id: int) -> FinancialReportModel:
    """
    Delete a financial report
    """
    db_report = get_financial_report(db, report_id)

    try:
        db.delete(db_report)
        db.commit()
        return db_report
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting financial report: {str(e)}")
