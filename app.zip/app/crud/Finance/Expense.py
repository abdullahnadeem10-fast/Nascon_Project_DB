from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, and_
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, date

from models.finance import Expense as ExpenseModel
from schemas.Finance.Expense import ExpenseCreate, ExpenseUpdate, ApprovalStatus, ExpenseSummary

def create_expense(db: Session, expense: ExpenseCreate, user_id: int) -> ExpenseModel:
    """
    Create a new expense record
    """
    try:
        # Create new expense
        db_expense = ExpenseModel(
            expense_category=expense.expense_category,
            description=expense.description,
            amount=expense.amount,
            expense_date=expense.expense_date,
            receipt_url=expense.receipt_url,
            created_by=user_id,
            approval_status=ApprovalStatus.PENDING
        )
        db.add(db_expense)
        db.commit()
        db.refresh(db_expense)
        return db_expense
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating expense record")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_expense(db: Session, expense_id: int) -> Optional[ExpenseModel]:
    """
    Get an expense by ID
    """
    expense = db.query(ExpenseModel).filter(ExpenseModel.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    return expense

def get_expenses(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[ExpenseModel], int]:
    """
    Get all expenses with pagination and optional filtering
    """
    query = db.query(ExpenseModel)
    
    # Apply filters if provided
    if filters:
        if 'created_by' in filters and filters['created_by']:
            query = query.filter(ExpenseModel.created_by == filters['created_by'])
        if 'expense_category' in filters and filters['expense_category']:
            query = query.filter(ExpenseModel.expense_category == filters['expense_category'])
        if 'approval_status' in filters and filters['approval_status']:
            query = query.filter(ExpenseModel.approval_status == filters['approval_status'])
        if 'start_date' in filters and filters['start_date']:
            query = query.filter(ExpenseModel.expense_date >= filters['start_date'])
        if 'end_date' in filters and filters['end_date']:
            query = query.filter(ExpenseModel.expense_date <= filters['end_date'])
        if 'min_amount' in filters and filters['min_amount']:
            query = query.filter(ExpenseModel.amount >= filters['min_amount'])
        if 'max_amount' in filters and filters['max_amount']:
            query = query.filter(ExpenseModel.amount <= filters['max_amount'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    expenses = query.order_by(ExpenseModel.created_at.desc()).offset(skip).limit(limit).all()
    
    return expenses, total

def get_expense_summary(
    db: Session, 
    created_by: Optional[int] = None,
    expense_category: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None
) -> ExpenseSummary:
    """
    Get expense summary statistics
    """
    # Build filter conditions
    conditions = []
    if created_by:
        conditions.append(ExpenseModel.created_by == created_by)
    if expense_category:
        conditions.append(ExpenseModel.expense_category == expense_category)
    if start_date:
        conditions.append(ExpenseModel.expense_date >= start_date)
    if end_date:
        conditions.append(ExpenseModel.expense_date <= end_date)
    
    filter_condition = and_(*conditions) if conditions else True
    
    # Get total amount and count
    total_query = db.query(
        func.sum(ExpenseModel.amount).label("total_amount"),
        func.count(ExpenseModel.id).label("expense_count")
    ).filter(filter_condition)
    
    total_result = total_query.first()
    total_amount = total_result.total_amount or 0
    expense_count = total_result.expense_count or 0
    
    # Get approved amount and count
    approved_query = db.query(
        func.sum(ExpenseModel.amount).label("approved_amount"),
        func.count(ExpenseModel.id).label("approved_count")
    ).filter(
        filter_condition,
        ExpenseModel.approval_status == ApprovalStatus.APPROVED
    )
    
    approved_result = approved_query.first()
    approved_amount = approved_result.approved_amount or 0
    approved_count = approved_result.approved_count or 0
    
    # Get pending amount and count
    pending_query = db.query(
        func.sum(ExpenseModel.amount).label("pending_amount"),
        func.count(ExpenseModel.id).label("pending_count")
    ).filter(
        filter_condition,
        ExpenseModel.approval_status == ApprovalStatus.PENDING
    )
    
    pending_result = pending_query.first()
    pending_amount = pending_result.pending_amount or 0
    pending_count = pending_result.pending_count or 0
    
    # Get rejected amount and count
    rejected_query = db.query(
        func.sum(ExpenseModel.amount).label("rejected_amount"),
        func.count(ExpenseModel.id).label("rejected_count")
    ).filter(
        filter_condition,
        ExpenseModel.approval_status == ApprovalStatus.REJECTED
    )
    
    rejected_result = rejected_query.first()
    rejected_amount = rejected_result.rejected_amount or 0
    rejected_count = rejected_result.rejected_count or 0
    
    # Get breakdown by category
    category_query = db.query(
        ExpenseModel.expense_category,
        func.sum(ExpenseModel.amount).label("amount"),
        func.count(ExpenseModel.id).label("count")
    ).filter(filter_condition).group_by(ExpenseModel.expense_category)
    
    by_category = {}
    for category_result in category_query.all():
        by_category[category_result.expense_category] = {
            "amount": category_result.amount,
            "count": category_result.count
        }
    
    return ExpenseSummary(
        total_amount=total_amount,
        approved_amount=approved_amount,
        pending_amount=pending_amount,
        rejected_amount=rejected_amount,
        expense_count=expense_count,
        approved_count=approved_count,
        pending_count=pending_count,
        rejected_count=rejected_count,
        by_category=by_category
    )

def update_expense(db: Session, expense_id: int, expense: ExpenseUpdate) -> ExpenseModel:
    """
    Update an expense
    """
    db_expense = get_expense(db, expense_id)
    
    try:
        # Update fields if provided
        if expense.expense_category is not None:
            db_expense.expense_category = expense.expense_category
        if expense.description is not None:
            db_expense.description = expense.description
        if expense.amount is not None:
            db_expense.amount = expense.amount
        if expense.expense_date is not None:
            db_expense.expense_date = expense.expense_date
        if expense.receipt_url is not None:
            db_expense.receipt_url = expense.receipt_url
        
        db.commit()
        db.refresh(db_expense)
        return db_expense
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating expense")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def approve_expense(db: Session, expense_id: int, approver_id: int) -> ExpenseModel:
    """
    Approve an expense
    """
    db_expense = get_expense(db, expense_id)
    
    if db_expense.approval_status != ApprovalStatus.PENDING:
        raise HTTPException(status_code=400, detail="Expense is not in pending status")
    
    try:
        db_expense.approval_status = ApprovalStatus.APPROVED
        db_expense.approved_by = approver_id
        db.commit()
        db.refresh(db_expense)
        return db_expense
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error approving expense: {str(e)}")

def reject_expense(db: Session, expense_id: int, approver_id: int) -> ExpenseModel:
    """
    Reject an expense
    """
    db_expense = get_expense(db, expense_id)
    
    if db_expense.approval_status != ApprovalStatus.PENDING:
        raise HTTPException(status_code=400, detail="Expense is not in pending status")
    
    try:
        db_expense.approval_status = ApprovalStatus.REJECTED
        db_expense.approved_by = approver_id
        db.commit()
        db.refresh(db_expense)
        return db_expense
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error rejecting expense: {str(e)}")

def delete_expense(db: Session, expense_id: int) -> ExpenseModel:
    """
    Delete an expense
    """
    db_expense = get_expense(db, expense_id)
    
    try:
        db.delete(db_expense)
        db.commit()
        return db_expense
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting expense: {str(e)}")
