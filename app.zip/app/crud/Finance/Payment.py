from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, and_
from typing import List, Optional, Dict, Any, Tuple
import uuid
from datetime import datetime, date

from models.finance import Payment as PaymentModel
from schemas.Finance.Payment import PaymentCreate, PaymentUpdate, PaymentStatus, PaymentSummary

def generate_transaction_id():
    """Generate a unique transaction ID"""
    return f"TXN-{str(uuid.uuid4())[:8].upper()}"

# Helper function to map between database and schema payment types
def map_db_to_schema_payment_type(db_type: str) -> str:
    """Map database payment type to schema payment type"""
    mapping = {
        "Registration": "Event Registration",
        "Accommodation": "Accommodation",
        "Sponsorship": "Sponsorship"
    }
    return mapping.get(db_type, "Other")

def map_schema_to_db_payment_type(schema_type: str) -> str:
    """Map schema payment type to database payment type"""
    mapping = {
        "Event Registration": "Registration",
        "Accommodation": "Accommodation",
        "Sponsorship": "Sponsorship",
        "Merchandise": "Registration",  # Default to Registration
        "Other": "Registration"  # Default to Registration
    }
    return mapping.get(schema_type, "Registration")

def create_payment(db: Session, payment: PaymentCreate) -> PaymentModel:
    """
    Create a new payment record
    """
    try:
        # Generate transaction ID
        transaction_id = generate_transaction_id()

        # Map payment type from schema to database enum values
        db_payment_type = map_schema_to_db_payment_type(payment.payment_type)

        # Map payment method to database enum values
        db_payment_method = payment.payment_method
        # Handle payment method mapping
        if payment.payment_method == "Cash":
            db_payment_method = "Cash"
        elif payment.payment_method == "Credit Card":
            db_payment_method = "Credit Card"
        elif payment.payment_method == "Bank Transfer":
            db_payment_method = "Bank Transfer"
        elif payment.payment_method == "Online Payment":
            db_payment_method = "Online"
        else:
            db_payment_method = "Cash"  # Default to Cash if not recognized

        # Create new payment
        db_payment = PaymentModel(
            amount=payment.amount,
            payment_method=db_payment_method,
            payment_type=db_payment_type,
            registration_id=payment.registration_id,
            notes=payment.notes,
            user_id=payment.user_id,
            received_by=payment.user_id,  # Set received_by to the same as user_id for now
            status="Pending",  # Default status is pending
            transaction_id=transaction_id
        )
        db.add(db_payment)
        db.commit()
        db.refresh(db_payment)
        return db_payment
    except IntegrityError as ie:
        db.rollback()
        # Log the specific integrity error for debugging
        print(f"IntegrityError: {str(ie)}")
        raise HTTPException(status_code=400, detail=f"Error creating payment record: {str(ie)}")
    except Exception as e:
        db.rollback()
        print(f"Exception: {str(e)}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

def get_payment(db: Session, payment_id: int) -> Optional[PaymentModel]:
    """
    Get a payment by ID
    """
    payment = db.query(PaymentModel).filter(PaymentModel.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payment

def get_payment_by_transaction_id(db: Session, transaction_id: str) -> Optional[PaymentModel]:
    """
    Get a payment by transaction ID
    """
    payment = db.query(PaymentModel).filter(PaymentModel.transaction_id == transaction_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payment

def get_payments(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    filters: Dict[str, Any] = None
) -> Tuple[List[PaymentModel], int]:
    """
    Get all payments with pagination and optional filtering
    """
    query = db.query(PaymentModel)

    # Apply filters if provided
    if filters:
        if 'user_id' in filters and filters['user_id']:
            query = query.filter(PaymentModel.user_id == filters['user_id'])
        if 'payment_type' in filters and filters['payment_type']:
            query = query.filter(PaymentModel.payment_type == filters['payment_type'])
        if 'payment_method' in filters and filters['payment_method']:
            query = query.filter(PaymentModel.payment_method == filters['payment_method'])
        if 'status' in filters and filters['status']:
            query = query.filter(PaymentModel.status == filters['status'])
        if 'registration_id' in filters and filters['registration_id']:
            query = query.filter(PaymentModel.registration_id == filters['registration_id'])
        if 'start_date' in filters and filters['start_date']:
            query = query.filter(PaymentModel.created_at >= filters['start_date'])
        if 'end_date' in filters and filters['end_date']:
            query = query.filter(PaymentModel.created_at <= filters['end_date'])
        if 'min_amount' in filters and filters['min_amount']:
            query = query.filter(PaymentModel.amount >= filters['min_amount'])
        if 'max_amount' in filters and filters['max_amount']:
            query = query.filter(PaymentModel.amount <= filters['max_amount'])

    # Get total count before pagination
    total = query.count()

    # Apply pagination
    payments = query.order_by(PaymentModel.payment_date.desc()).offset(skip).limit(limit).all()

    return payments, total

def get_payment_summary(
    db: Session,
    user_id: Optional[int] = None,
    payment_type: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None
) -> PaymentSummary:
    """
    Get payment summary statistics
    """
    # Build filter conditions
    conditions = []
    if user_id:
        conditions.append(PaymentModel.user_id == user_id)
    if payment_type:
        conditions.append(PaymentModel.payment_type == payment_type)
    if start_date:
        conditions.append(PaymentModel.created_at >= start_date)
    if end_date:
        conditions.append(PaymentModel.created_at <= end_date)

    filter_condition = and_(*conditions) if conditions else True

    # Get total amount and count
    total_query = db.query(
        func.sum(PaymentModel.amount).label("total_amount"),
        func.count(PaymentModel.id).label("payment_count")
    ).filter(filter_condition)

    total_result = total_query.first()
    total_amount = total_result.total_amount or 0
    payment_count = total_result.payment_count or 0

    # Get completed amount and count
    completed_query = db.query(
        func.sum(PaymentModel.amount).label("completed_amount"),
        func.count(PaymentModel.id).label("completed_count")
    ).filter(
        filter_condition,
        PaymentModel.status == PaymentStatus.COMPLETED
    )

    completed_result = completed_query.first()
    completed_amount = completed_result.completed_amount or 0
    completed_count = completed_result.completed_count or 0

    # Get pending amount and count
    pending_query = db.query(
        func.sum(PaymentModel.amount).label("pending_amount"),
        func.count(PaymentModel.id).label("pending_count")
    ).filter(
        filter_condition,
        PaymentModel.status == PaymentStatus.PENDING
    )

    pending_result = pending_query.first()
    pending_amount = pending_result.pending_amount or 0
    pending_count = pending_result.pending_count or 0

    return PaymentSummary(
        total_amount=total_amount,
        completed_amount=completed_amount,
        pending_amount=pending_amount,
        payment_count=payment_count,
        completed_count=completed_count,
        pending_count=pending_count
    )

def update_payment(db: Session, payment_id: int, payment: PaymentUpdate) -> PaymentModel:
    """
    Update a payment
    """
    db_payment = get_payment(db, payment_id)

    try:
        # Update fields if provided
        if payment.amount is not None:
            db_payment.amount = payment.amount
        if payment.payment_method is not None:
            db_payment.payment_method = payment.payment_method
        if payment.payment_type is not None:
            db_payment.payment_type = payment.payment_type
        if payment.registration_id is not None:
            db_payment.registration_id = payment.registration_id
        if payment.notes is not None:
            db_payment.notes = payment.notes
        if payment.status is not None:
            db_payment.status = payment.status
            db_payment.updated_at = datetime.now()
        if payment.transaction_id is not None:
            db_payment.transaction_id = payment.transaction_id

        db.commit()
        db.refresh(db_payment)
        return db_payment
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating payment")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def update_payment_status(db: Session, payment_id: int, status: str) -> PaymentModel:
    """
    Update the status of a payment and the associated registration's payment status if applicable
    """
    db_payment = get_payment(db, payment_id)

    try:
        db_payment.status = status
        db_payment.updated_at = datetime.now()

        # If this is a registration payment and status is changed to "Completed",
        # update the associated registration's payment status to "Paid"
        if db_payment.payment_type == "Registration" and db_payment.registration_id is not None and status == "Completed":
            from models.events import EventRegistration
            from schemas.Events.EventRegistration import PaymentStatus as RegistrationPaymentStatus

            # Get the associated registration
            registration = db.query(EventRegistration).filter(
                EventRegistration.id == db_payment.registration_id
            ).first()

            if registration:
                # Update registration payment status to PAID
                registration.payment_status = RegistrationPaymentStatus.PAID.value

        db.commit()
        db.refresh(db_payment)
        return db_payment
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating payment status: {str(e)}")

def delete_payment(db: Session, payment_id: int) -> PaymentModel:
    """
    Delete a payment
    """
    db_payment = get_payment(db, payment_id)

    try:
        db.delete(db_payment)
        db.commit()
        return db_payment
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting payment: {str(e)}")
