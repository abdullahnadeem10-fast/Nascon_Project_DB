from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func
from typing import List, Optional

from models.notifications import Announcement as AnnouncementModel
from models.rbac import User
from schemas.notifications.Announcement import AnnouncementCreate, AnnouncementUpdate

def create_announcement(db: Session, announcement: AnnouncementCreate, publisher_id: int) -> AnnouncementModel:
    """
    Create a new announcement
    """
    try:
        db_announcement = AnnouncementModel(
            title=announcement.title,
            content=announcement.content,
            target_audience=announcement.target_audience,
            event_id=announcement.event_id,
            published_by=publisher_id,
            is_active=announcement.is_active
        )
        db.add(db_announcement)
        db.commit()
        db.refresh(db_announcement)
        return db_announcement
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating announcement")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_announcement(db: Session, announcement_id: int) -> AnnouncementModel:
    """
    Get an announcement by ID
    """
    announcement = db.query(AnnouncementModel).filter(AnnouncementModel.id == announcement_id).first()
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    return announcement

def get_announcement_with_publisher(db: Session, announcement_id: int) -> dict:
    """
    Get an announcement with publisher details
    """
    result = db.query(
        AnnouncementModel,
        func.concat(User.first_name, ' ', User.last_name).label('publisher_name')
    ).join(
        User, AnnouncementModel.published_by == User.id
    ).filter(
        AnnouncementModel.id == announcement_id
    ).first()
    
    if not result:
        raise HTTPException(status_code=404, detail="Announcement not found")
    
    announcement, publisher_name = result
    
    return {
        **announcement.__dict__,
        'publisher_name': publisher_name
    }

def get_announcements(db: Session, skip: int = 0, limit: int = 100, active_only: bool = True) -> List[AnnouncementModel]:
    """
    Get all announcements
    """
    query = db.query(AnnouncementModel)
    
    if active_only:
        query = query.filter(AnnouncementModel.is_active == True)
    
    return query.order_by(AnnouncementModel.published_at.desc()).offset(skip).limit(limit).all()

def get_announcements_by_event(db: Session, event_id: int, skip: int = 0, limit: int = 100, active_only: bool = True) -> List[AnnouncementModel]:
    """
    Get all announcements for an event
    """
    query = db.query(AnnouncementModel).filter(AnnouncementModel.event_id == event_id)
    
    if active_only:
        query = query.filter(AnnouncementModel.is_active == True)
    
    return query.order_by(AnnouncementModel.published_at.desc()).offset(skip).limit(limit).all()

def get_announcements_by_audience(db: Session, audience: str, skip: int = 0, limit: int = 100, active_only: bool = True) -> List[AnnouncementModel]:
    """
    Get all announcements for a specific audience
    """
    query = db.query(AnnouncementModel).filter(
        (AnnouncementModel.target_audience == audience) | 
        (AnnouncementModel.target_audience == 'All')
    )
    
    if active_only:
        query = query.filter(AnnouncementModel.is_active == True)
    
    return query.order_by(AnnouncementModel.published_at.desc()).offset(skip).limit(limit).all()

def update_announcement(db: Session, announcement_id: int, announcement: AnnouncementUpdate) -> AnnouncementModel:
    """
    Update an announcement
    """
    db_announcement = get_announcement(db, announcement_id)
    
    update_data = announcement.dict(exclude_unset=True)
    
    try:
        for key, value in update_data.items():
            setattr(db_announcement, key, value)
        
        db.commit()
        db.refresh(db_announcement)
        return db_announcement
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating announcement")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_announcement(db: Session, announcement_id: int) -> AnnouncementModel:
    """
    Delete an announcement
    """
    db_announcement = get_announcement(db, announcement_id)
    
    try:
        db.delete(db_announcement)
        db.commit()
        return db_announcement
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting announcement: {str(e)}")

def toggle_announcement_status(db: Session, announcement_id: int) -> AnnouncementModel:
    """
    Toggle the active status of an announcement
    """
    db_announcement = get_announcement(db, announcement_id)
    
    try:
        db_announcement.is_active = not db_announcement.is_active
        db.commit()
        db.refresh(db_announcement)
        return db_announcement
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
