from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func
from typing import List

from models.notifications import Notification as NotificationModel
from schemas.notifications.Notification import NotificationCreate, NotificationUpdate

def create_notification(db: Session, notification: NotificationCreate) -> NotificationModel:
    """
    Create a new notification
    """
    try:
        db_notification = NotificationModel(
            user_id=notification.user_id,
            title=notification.title,
            message=notification.message,
            notification_type=notification.notification_type,
            is_read=notification.is_read
        )
        db.add(db_notification)
        db.commit()
        db.refresh(db_notification)
        return db_notification
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error creating notification")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_notification(db: Session, notification_id: int) -> NotificationModel:
    """
    Get a notification by ID
    """
    notification = db.query(NotificationModel).filter(NotificationModel.id == notification_id).first()
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    return notification

def get_notifications(db: Session, user_id: int, skip: int = 0, limit: int = 100) -> List[NotificationModel]:
    """
    Get all notifications for a user
    """
    return db.query(NotificationModel)\
        .filter(NotificationModel.user_id == user_id)\
        .order_by(NotificationModel.created_at.desc())\
        .offset(skip)\
        .limit(limit)\
        .all()

def get_unread_count(db: Session, user_id: int) -> int:
    """
    Get count of unread notifications for a user
    """
    return db.query(func.count(NotificationModel.id))\
        .filter(NotificationModel.user_id == user_id, NotificationModel.is_read == False)\
        .scalar()

def update_notification(db: Session, notification_id: int, notification: NotificationUpdate) -> NotificationModel:
    """
    Update a notification
    """
    db_notification = get_notification(db, notification_id)

    update_data = notification.model_dump(exclude_unset=True)

    try:
        for key, value in update_data.items():
            setattr(db_notification, key, value)

        db.commit()
        db.refresh(db_notification)
        return db_notification
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error updating notification")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def mark_as_read(db: Session, notification_id: int) -> NotificationModel:
    """
    Mark a notification as read
    """
    db_notification = get_notification(db, notification_id)

    try:
        db_notification.is_read = True
        db.commit()
        db.refresh(db_notification)
        return db_notification
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def mark_all_as_read(db: Session, user_id: int) -> int:
    """
    Mark all notifications as read for a user
    Returns the number of notifications updated
    """
    try:
        result = db.query(NotificationModel)\
            .filter(NotificationModel.user_id == user_id, NotificationModel.is_read == False)\
            .update({NotificationModel.is_read: True})
        db.commit()
        return result
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_notification(db: Session, notification_id: int) -> NotificationModel:
    """
    Delete a notification
    """
    db_notification = get_notification(db, notification_id)

    try:
        db.delete(db_notification)
        db.commit()
        return db_notification
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting notification: {str(e)}")

def delete_all_notifications(db: Session, user_id: int) -> int:
    """
    Delete all notifications for a user
    Returns the number of notifications deleted
    """
    try:
        result = db.query(NotificationModel)\
            .filter(NotificationModel.user_id == user_id)\
            .delete()
        db.commit()
        return result
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def create_system_notification(
    db: Session,
    user_id: int,
    title: str,
    message: str,
    notification_type: str = "System"
) -> NotificationModel:
    """
    Utility function to create a system notification for a user

    This can be called from other parts of the application to create notifications
    programmatically when certain events occur.

    Args:
        db: Database session
        user_id: ID of the user to receive the notification
        title: Notification title
        message: Notification message
        notification_type: Type of notification (default: "System")

    Returns:
        The created notification
    """
    try:
        notification = NotificationModel(
            user_id=user_id,
            title=title,
            message=message,
            notification_type=notification_type,
            is_read=False
        )
        db.add(notification)
        db.commit()
        db.refresh(notification)
        return notification
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error creating notification: {str(e)}")

def create_bulk_notifications(
    db: Session,
    user_ids: list,
    title: str,
    message: str,
    notification_type: str = "System"
) -> int:
    """
    Create notifications for multiple users at once

    Args:
        db: Database session
        user_ids: List of user IDs to receive the notification
        title: Notification title
        message: Notification message
        notification_type: Type of notification (default: "System")

    Returns:
        Number of notifications created
    """
    try:
        notifications = []
        for user_id in user_ids:
            notification = NotificationModel(
                user_id=user_id,
                title=title,
                message=message,
                notification_type=notification_type,
                is_read=False
            )
            notifications.append(notification)

        db.add_all(notifications)
        db.commit()
        return len(notifications)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error creating notifications: {str(e)}")
