from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime

from models.judging import Winner as WinnerModel
from models.events import Event, EventRegistration
from models.rbac import User
from schemas.Judging.Winner import WinnerCreate, WinnerUpdate, BatchWinnerCreate

def create_winner(db: Session, winner: WinnerCreate, declarer_id: int) -> WinnerModel:
    """
    Create a new winner
    """
    try:
        # Check if position is already taken for this event
        existing_winner = db.query(WinnerModel).filter(
            WinnerModel.event_id == winner.event_id,
            WinnerModel.position == winner.position
        ).first()
        
        if existing_winner:
            raise HTTPException(
                status_code=400, 
                detail=f"Position {winner.position} is already assigned for this event"
            )
        
        # Create new winner
        db_winner = WinnerModel(
            event_id=winner.event_id,
            registration_id=winner.registration_id,
            position=winner.position,
            prize_description=winner.prize_description,
            declared_by=declarer_id
        )
        db.add(db_winner)
        db.commit()
        db.refresh(db_winner)
        return db_winner
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Invalid data provided or constraints violated")
    except HTTPException as e:
        db.rollback()
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def batch_create_winners(db: Session, batch: BatchWinnerCreate, declarer_id: int) -> List[WinnerModel]:
    """
    Create multiple winners in a batch
    """
    try:
        created_winners = []
        
        # Check if any positions are duplicated in the batch
        positions = [w["position"] for w in batch.winners]
        if len(positions) != len(set(positions)):
            raise HTTPException(status_code=400, detail="Duplicate positions in the batch")
        
        # Check if any positions are already taken for this event
        existing_positions = db.query(WinnerModel.position).filter(
            WinnerModel.event_id == batch.event_id,
            WinnerModel.position.in_(positions)
        ).all()
        
        if existing_positions:
            taken_positions = [p[0] for p in existing_positions]
            raise HTTPException(
                status_code=400, 
                detail=f"Positions {taken_positions} are already assigned for this event"
            )
        
        # Create winners
        for winner_data in batch.winners:
            registration_id = winner_data["registration_id"]
            position = winner_data["position"]
            prize_description = winner_data.get("prize_description")
            
            # Create winner
            db_winner = WinnerModel(
                event_id=batch.event_id,
                registration_id=registration_id,
                position=position,
                prize_description=prize_description,
                declared_by=declarer_id
            )
            db.add(db_winner)
            created_winners.append(db_winner)
        
        db.commit()
        
        # Refresh all winners
        for winner in created_winners:
            db.refresh(winner)
        
        return created_winners
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Invalid data provided or constraints violated")
    except HTTPException as e:
        db.rollback()
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_winner(db: Session, winner_id: int) -> Optional[WinnerModel]:
    """
    Get a winner by ID
    """
    winner = db.query(WinnerModel).filter(WinnerModel.id == winner_id).first()
    if not winner:
        raise HTTPException(status_code=404, detail="Winner not found")
    return winner

def get_winners(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[WinnerModel], int]:
    """
    Get all winners with pagination and optional filtering
    """
    query = db.query(WinnerModel)
    
    # Apply filters if provided
    if filters:
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(WinnerModel.event_id == filters['event_id'])
        if 'registration_id' in filters and filters['registration_id']:
            query = query.filter(WinnerModel.registration_id == filters['registration_id'])
        if 'position' in filters and filters['position']:
            query = query.filter(WinnerModel.position == filters['position'])
        if 'declared_by' in filters and filters['declared_by']:
            query = query.filter(WinnerModel.declared_by == filters['declared_by'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    winners = query.order_by(WinnerModel.position).offset(skip).limit(limit).all()
    
    return winners, total

def get_winners_with_details(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[Dict], int]:
    """
    Get all winners with related details
    """
    query = db.query(
        WinnerModel,
        Event.event_name,
        EventRegistration.participant_name,
        User.first_name.label("declarer_first_name"),
        User.last_name.label("declarer_last_name")
    ).join(
        Event, WinnerModel.event_id == Event.id
    ).join(
        EventRegistration, WinnerModel.registration_id == EventRegistration.id
    ).join(
        User, WinnerModel.declared_by == User.id
    )
    
    # Apply filters if provided
    if filters:
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(WinnerModel.event_id == filters['event_id'])
        if 'registration_id' in filters and filters['registration_id']:
            query = query.filter(WinnerModel.registration_id == filters['registration_id'])
        if 'position' in filters and filters['position']:
            query = query.filter(WinnerModel.position == filters['position'])
        if 'declared_by' in filters and filters['declared_by']:
            query = query.filter(WinnerModel.declared_by == filters['declared_by'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    results = query.order_by(WinnerModel.position).offset(skip).limit(limit).all()
    
    # Convert results to list of dictionaries
    winners = []
    for result in results:
        winner, event_name, participant_name, declarer_first_name, declarer_last_name = result
        
        winners.append({
            "id": winner.id,
            "event_id": winner.event_id,
            "registration_id": winner.registration_id,
            "position": winner.position,
            "prize_description": winner.prize_description,
            "declared_by": winner.declared_by,
            "declared_at": winner.declared_at,
            "event_name": event_name,
            "participant_name": participant_name,
            "declarer_name": f"{declarer_first_name} {declarer_last_name}"
        })
    
    return winners, total

def update_winner(db: Session, winner_id: int, winner: WinnerUpdate) -> WinnerModel:
    """
    Update a winner
    """
    db_winner = get_winner(db, winner_id)
    
    try:
        # Check if position is being updated and if it's already taken
        if winner.position is not None and winner.position != db_winner.position:
            existing_winner = db.query(WinnerModel).filter(
                WinnerModel.event_id == db_winner.event_id,
                WinnerModel.position == winner.position
            ).first()
            
            if existing_winner:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Position {winner.position} is already assigned for this event"
                )
        
        # Update fields if provided
        if winner.registration_id is not None:
            db_winner.registration_id = winner.registration_id
        if winner.position is not None:
            db_winner.position = winner.position
        if winner.prize_description is not None:
            db_winner.prize_description = winner.prize_description
        
        db.commit()
        db.refresh(db_winner)
        return db_winner
    except HTTPException as e:
        db.rollback()
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_winner(db: Session, winner_id: int) -> WinnerModel:
    """
    Delete a winner
    """
    db_winner = get_winner(db, winner_id)
    
    try:
        db.delete(db_winner)
        db.commit()
        return db_winner
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting winner: {str(e)}")
