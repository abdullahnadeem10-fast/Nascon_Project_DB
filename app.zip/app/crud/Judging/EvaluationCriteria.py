from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple
from decimal import Decimal

from models.judging import EvaluationCriteria as EvaluationCriteriaModel
from models.events import Event
from schemas.Judging.EvaluationCriteria import EvaluationCriteriaCreate, EvaluationCriteriaUpdate

def create_evaluation_criteria(db: Session, criteria: EvaluationCriteriaCreate) -> EvaluationCriteriaModel:
    """
    Create a new evaluation criteria
    """
    try:
        # Create new criteria
        db_criteria = EvaluationCriteriaModel(
            event_id=criteria.event_id,
            criteria_name=criteria.criteria_name,
            description=criteria.description,
            max_score=criteria.max_score,
            weight=criteria.weight
        )
        db.add(db_criteria)
        db.commit()
        db.refresh(db_criteria)
        return db_criteria
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Criteria with this name already exists for this event or invalid data provided")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_evaluation_criteria(db: Session, criteria_id: int) -> Optional[EvaluationCriteriaModel]:
    """
    Get an evaluation criteria by ID
    """
    criteria = db.query(EvaluationCriteriaModel).filter(EvaluationCriteriaModel.id == criteria_id).first()
    if not criteria:
        raise HTTPException(status_code=404, detail="Evaluation criteria not found")
    return criteria

def get_evaluation_criteria_by_event(db: Session, event_id: int) -> List[EvaluationCriteriaModel]:
    """
    Get all evaluation criteria for an event
    """
    return db.query(EvaluationCriteriaModel).filter(EvaluationCriteriaModel.event_id == event_id).all()

def get_evaluation_criteria_list(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[EvaluationCriteriaModel], int]:
    """
    Get all evaluation criteria with pagination and optional filtering
    """
    query = db.query(EvaluationCriteriaModel)
    
    # Apply filters if provided
    if filters:
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(EvaluationCriteriaModel.event_id == filters['event_id'])
        if 'criteria_name' in filters and filters['criteria_name']:
            query = query.filter(EvaluationCriteriaModel.criteria_name.ilike(f"%{filters['criteria_name']}%"))
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    criteria = query.order_by(EvaluationCriteriaModel.id).offset(skip).limit(limit).all()
    
    return criteria, total

def get_evaluation_criteria_with_event(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[Dict], int]:
    """
    Get all evaluation criteria with event details
    """
    query = db.query(
        EvaluationCriteriaModel,
        Event.event_name
    ).join(
        Event, EvaluationCriteriaModel.event_id == Event.id
    )
    
    # Apply filters if provided
    if filters:
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(EvaluationCriteriaModel.event_id == filters['event_id'])
        if 'criteria_name' in filters and filters['criteria_name']:
            query = query.filter(EvaluationCriteriaModel.criteria_name.ilike(f"%{filters['criteria_name']}%"))
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    results = query.order_by(EvaluationCriteriaModel.id).offset(skip).limit(limit).all()
    
    # Convert results to list of dictionaries
    criteria_list = []
    for result in results:
        criteria, event_name = result
        
        criteria_list.append({
            "id": criteria.id,
            "event_id": criteria.event_id,
            "criteria_name": criteria.criteria_name,
            "description": criteria.description,
            "max_score": criteria.max_score,
            "weight": criteria.weight,
            "event_name": event_name
        })
    
    return criteria_list, total

def update_evaluation_criteria(db: Session, criteria_id: int, criteria: EvaluationCriteriaUpdate) -> EvaluationCriteriaModel:
    """
    Update an evaluation criteria
    """
    db_criteria = get_evaluation_criteria(db, criteria_id)
    
    try:
        # Update fields if provided
        if criteria.criteria_name is not None:
            db_criteria.criteria_name = criteria.criteria_name
        if criteria.description is not None:
            db_criteria.description = criteria.description
        if criteria.max_score is not None:
            db_criteria.max_score = criteria.max_score
        if criteria.weight is not None:
            db_criteria.weight = criteria.weight
        
        db.commit()
        db.refresh(db_criteria)
        return db_criteria
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Criteria with this name already exists for this event")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_evaluation_criteria(db: Session, criteria_id: int) -> EvaluationCriteriaModel:
    """
    Delete an evaluation criteria
    """
    db_criteria = get_evaluation_criteria(db, criteria_id)
    
    try:
        db.delete(db_criteria)
        db.commit()
        return db_criteria
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting evaluation criteria: {str(e)}")
