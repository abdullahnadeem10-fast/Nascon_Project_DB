from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, and_, desc
from typing import List, Optional, Dict, Any, Tuple
from decimal import Decimal
from datetime import datetime

from models.judging import Score as ScoreModel, EvaluationCriteria
from models.events import Event, EventSchedule, EventRegistration
from models.rbac import User
from schemas.Judging.Score import ScoreCreate, ScoreUpdate, BatchScoreCreate

def create_score(db: Session, score: ScoreCreate) -> ScoreModel:
    """
    Create a new score
    """
    try:
        # Get the criteria to check max_score
        criteria = db.query(EvaluationCriteria).filter(EvaluationCriteria.id == score.criteria_id).first()
        if not criteria:
            raise HTTPException(status_code=404, detail="Evaluation criteria not found")
        
        # Validate score against max_score
        if score.score_value > criteria.max_score:
            raise HTTPException(
                status_code=400, 
                detail=f"Score value cannot exceed maximum score of {criteria.max_score}"
            )
        
        # Create new score
        db_score = ScoreModel(
            judge_id=score.judge_id,
            registration_id=score.registration_id,
            criteria_id=score.criteria_id,
            schedule_id=score.schedule_id,
            score_value=score.score_value,
            comments=score.comments
        )
        db.add(db_score)
        db.commit()
        db.refresh(db_score)
        return db_score
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400, 
            detail="Score already exists for this judge, participant, criteria, and schedule or invalid data provided"
        )
    except HTTPException as e:
        db.rollback()
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def batch_create_scores(db: Session, batch: BatchScoreCreate, judge_id: int) -> List[ScoreModel]:
    """
    Create multiple scores in a batch
    """
    try:
        created_scores = []
        
        # Get all criteria for validation
        criteria_ids = [score["criteria_id"] for score in batch.scores]
        criteria_map = {
            c.id: c for c in db.query(EvaluationCriteria).filter(EvaluationCriteria.id.in_(criteria_ids)).all()
        }
        
        # Check if all criteria exist
        for criteria_id in criteria_ids:
            if criteria_id not in criteria_map:
                raise HTTPException(status_code=404, detail=f"Evaluation criteria with ID {criteria_id} not found")
        
        # Create scores
        for score_data in batch.scores:
            criteria_id = score_data["criteria_id"]
            score_value = score_data["score_value"]
            comments = score_data.get("comments")
            
            # Validate score against max_score
            if score_value > criteria_map[criteria_id].max_score:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Score value {score_value} for criteria {criteria_id} exceeds maximum score of {criteria_map[criteria_id].max_score}"
                )
            
            # Create score
            db_score = ScoreModel(
                judge_id=judge_id,
                registration_id=batch.registration_id,
                criteria_id=criteria_id,
                schedule_id=batch.schedule_id,
                score_value=score_value,
                comments=comments
            )
            db.add(db_score)
            created_scores.append(db_score)
        
        db.commit()
        
        # Refresh all scores
        for score in created_scores:
            db.refresh(score)
        
        return created_scores
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400, 
            detail="Some scores already exist for this judge, participant, criteria, and schedule"
        )
    except HTTPException as e:
        db.rollback()
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_score(db: Session, score_id: int) -> Optional[ScoreModel]:
    """
    Get a score by ID
    """
    score = db.query(ScoreModel).filter(ScoreModel.id == score_id).first()
    if not score:
        raise HTTPException(status_code=404, detail="Score not found")
    return score

def get_scores(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[ScoreModel], int]:
    """
    Get all scores with pagination and optional filtering
    """
    query = db.query(ScoreModel)
    
    # Apply filters if provided
    if filters:
        if 'judge_id' in filters and filters['judge_id']:
            query = query.filter(ScoreModel.judge_id == filters['judge_id'])
        if 'registration_id' in filters and filters['registration_id']:
            query = query.filter(ScoreModel.registration_id == filters['registration_id'])
        if 'criteria_id' in filters and filters['criteria_id']:
            query = query.filter(ScoreModel.criteria_id == filters['criteria_id'])
        if 'schedule_id' in filters and filters['schedule_id']:
            query = query.filter(ScoreModel.schedule_id == filters['schedule_id'])
        if 'event_id' in filters and filters['event_id']:
            query = query.join(EventRegistration).filter(EventRegistration.event_id == filters['event_id'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    scores = query.order_by(ScoreModel.submitted_at.desc()).offset(skip).limit(limit).all()
    
    return scores, total

def get_scores_with_details(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[Dict], int]:
    """
    Get all scores with related details
    """
    query = db.query(
        ScoreModel,
        User.first_name.label("judge_first_name"),
        User.last_name.label("judge_last_name"),
        EventRegistration.participant_name,
        Event.event_name,
        EvaluationCriteria.criteria_name,
        EvaluationCriteria.max_score,
        EventSchedule.start_time
    ).join(
        User, ScoreModel.judge_id == User.id
    ).join(
        EventRegistration, ScoreModel.registration_id == EventRegistration.id
    ).join(
        Event, EventRegistration.event_id == Event.id
    ).join(
        EvaluationCriteria, ScoreModel.criteria_id == EvaluationCriteria.id
    ).join(
        EventSchedule, ScoreModel.schedule_id == EventSchedule.id
    )
    
    # Apply filters if provided
    if filters:
        if 'judge_id' in filters and filters['judge_id']:
            query = query.filter(ScoreModel.judge_id == filters['judge_id'])
        if 'registration_id' in filters and filters['registration_id']:
            query = query.filter(ScoreModel.registration_id == filters['registration_id'])
        if 'criteria_id' in filters and filters['criteria_id']:
            query = query.filter(ScoreModel.criteria_id == filters['criteria_id'])
        if 'schedule_id' in filters and filters['schedule_id']:
            query = query.filter(ScoreModel.schedule_id == filters['schedule_id'])
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(EventRegistration.event_id == filters['event_id'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    results = query.order_by(ScoreModel.submitted_at.desc()).offset(skip).limit(limit).all()
    
    # Convert results to list of dictionaries
    scores = []
    for result in results:
        score, judge_first_name, judge_last_name, participant_name, event_name, criteria_name, max_score, schedule_date = result
        
        scores.append({
            "id": score.id,
            "judge_id": score.judge_id,
            "registration_id": score.registration_id,
            "criteria_id": score.criteria_id,
            "schedule_id": score.schedule_id,
            "score_value": score.score_value,
            "comments": score.comments,
            "submitted_at": score.submitted_at,
            "judge_name": f"{judge_first_name} {judge_last_name}",
            "participant_name": participant_name,
            "event_name": event_name,
            "criteria_name": criteria_name,
            "max_score": max_score,
            "schedule_date": schedule_date
        })
    
    return scores, total

def get_participant_score_summaries(
    db: Session, 
    event_id: int,
    schedule_id: Optional[int] = None
) -> List[Dict]:
    """
    Get score summaries for all participants in an event
    """
    # Get all registrations for the event
    registrations = db.query(
        EventRegistration.id,
        EventRegistration.participant_name,
        Event.event_name
    ).join(
        Event, EventRegistration.event_id == Event.id
    ).filter(
        EventRegistration.event_id == event_id
    ).all()
    
    if not registrations:
        return []
    
    # Build base query for scores
    base_query = db.query(ScoreModel).join(
        EventRegistration, ScoreModel.registration_id == EventRegistration.id
    ).filter(
        EventRegistration.event_id == event_id
    )
    
    if schedule_id:
        base_query = base_query.filter(ScoreModel.schedule_id == schedule_id)
    
    # Get all criteria for the event
    criteria = db.query(
        EvaluationCriteria.id,
        EvaluationCriteria.criteria_name,
        EvaluationCriteria.weight
    ).filter(
        EvaluationCriteria.event_id == event_id
    ).all()
    
    criteria_map = {c.id: (c.criteria_name, c.weight) for c in criteria}
    
    # Calculate summaries for each participant
    summaries = []
    for reg_id, participant_name, event_name in registrations:
        # Get all scores for this participant
        scores = base_query.filter(ScoreModel.registration_id == reg_id).all()
        
        if not scores:
            continue
        
        # Calculate total and average scores
        total_score = Decimal(0)
        judge_count = len(set(score.judge_id for score in scores))
        
        # Group scores by criteria
        criteria_scores = {}
        for score in scores:
            criteria_name, weight = criteria_map.get(score.criteria_id, ("Unknown", Decimal(1)))
            if criteria_name not in criteria_scores:
                criteria_scores[criteria_name] = []
            
            # Apply weight to the score
            weighted_score = score.score_value * weight
            criteria_scores[criteria_name].append(weighted_score)
        
        # Calculate average for each criteria
        avg_criteria_scores = {}
        for criteria_name, scores_list in criteria_scores.items():
            avg_criteria_scores[criteria_name] = sum(scores_list) / len(scores_list)
            total_score += avg_criteria_scores[criteria_name]
        
        # Calculate overall average
        average_score = total_score / len(avg_criteria_scores) if avg_criteria_scores else Decimal(0)
        
        summaries.append({
            "registration_id": reg_id,
            "participant_name": participant_name,
            "event_name": event_name,
            "total_score": total_score,
            "average_score": average_score,
            "judge_count": judge_count,
            "criteria_scores": avg_criteria_scores
        })
    
    # Sort by average score (descending) and assign ranks
    summaries.sort(key=lambda x: x["average_score"], reverse=True)
    for i, summary in enumerate(summaries):
        summary["rank"] = i + 1
    
    return summaries

def update_score(db: Session, score_id: int, score: ScoreUpdate) -> ScoreModel:
    """
    Update a score
    """
    db_score = get_score(db, score_id)
    
    try:
        # Get the criteria to check max_score
        criteria = db.query(EvaluationCriteria).filter(EvaluationCriteria.id == db_score.criteria_id).first()
        
        # Update score_value if provided
        if score.score_value is not None:
            # Validate score against max_score
            if score.score_value > criteria.max_score:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Score value cannot exceed maximum score of {criteria.max_score}"
                )
            db_score.score_value = score.score_value
        
        # Update comments if provided
        if score.comments is not None:
            db_score.comments = score.comments
        
        db.commit()
        db.refresh(db_score)
        return db_score
    except HTTPException as e:
        db.rollback()
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def delete_score(db: Session, score_id: int) -> ScoreModel:
    """
    Delete a score
    """
    db_score = get_score(db, score_id)
    
    try:
        db.delete(db_score)
        db.commit()
        return db_score
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting score: {str(e)}")
