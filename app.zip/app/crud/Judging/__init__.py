# Initialize the Judging CRUD package
