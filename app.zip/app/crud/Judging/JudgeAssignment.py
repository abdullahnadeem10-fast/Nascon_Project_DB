from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime

from models.judging import JudgeAssignment as JudgeAssignmentModel
from models.events import Event, EventSchedule
from models.rbac import User
from schemas.Judging.JudgeAssignment import JudgeAssignmentCreate, JudgeAssignmentUpdate, JudgeStatus

def create_judge_assignment(db: Session, assignment: JudgeAssignmentCreate, assigner_id: int) -> JudgeAssignmentModel:
    """
    Create a new judge assignment
    """
    try:
        # Create new assignment
        db_assignment = JudgeAssignmentModel(
            user_id=assignment.user_id,
            event_id=assignment.event_id,
            schedule_id=assignment.schedule_id,
            assigned_by=assigner_id,
            status=JudgeStatus.ACTIVE
        )
        db.add(db_assignment)
        db.commit()
        db.refresh(db_assignment)
        return db_assignment
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Judge is already assigned to this schedule or invalid data provided")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

def get_judge_assignment(db: Session, assignment_id: int) -> Optional[JudgeAssignmentModel]:
    """
    Get a judge assignment by ID
    """
    assignment = db.query(JudgeAssignmentModel).filter(JudgeAssignmentModel.id == assignment_id).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Judge assignment not found")
    return assignment

def get_judge_assignments(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[JudgeAssignmentModel], int]:
    """
    Get all judge assignments with pagination and optional filtering
    """
    query = db.query(JudgeAssignmentModel)
    
    # Apply filters if provided
    if filters:
        if 'user_id' in filters and filters['user_id']:
            query = query.filter(JudgeAssignmentModel.user_id == filters['user_id'])
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(JudgeAssignmentModel.event_id == filters['event_id'])
        if 'schedule_id' in filters and filters['schedule_id']:
            query = query.filter(JudgeAssignmentModel.schedule_id == filters['schedule_id'])
        if 'assigned_by' in filters and filters['assigned_by']:
            query = query.filter(JudgeAssignmentModel.assigned_by == filters['assigned_by'])
        if 'status' in filters and filters['status']:
            query = query.filter(JudgeAssignmentModel.status == filters['status'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    assignments = query.order_by(JudgeAssignmentModel.assigned_at.desc()).offset(skip).limit(limit).all()
    
    return assignments, total

def get_judge_assignments_with_details(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    filters: Dict[str, Any] = None
) -> Tuple[List[Dict], int]:
    """
    Get all judge assignments with related details
    """
    query = db.query(
        JudgeAssignmentModel,
        User.first_name.label("judge_first_name"),
        User.last_name.label("judge_last_name"),
        Event.event_name,
        EventSchedule.start_time,
        EventSchedule.end_time,
        User.first_name.label("assigner_first_name"),
        User.last_name.label("assigner_last_name")
    ).join(
        User, JudgeAssignmentModel.user_id == User.id
    ).join(
        Event, JudgeAssignmentModel.event_id == Event.id
    ).join(
        EventSchedule, JudgeAssignmentModel.schedule_id == EventSchedule.id
    ).join(
        User, JudgeAssignmentModel.assigned_by == User.id, isouter=True
    )
    
    # Apply filters if provided
    if filters:
        if 'user_id' in filters and filters['user_id']:
            query = query.filter(JudgeAssignmentModel.user_id == filters['user_id'])
        if 'event_id' in filters and filters['event_id']:
            query = query.filter(JudgeAssignmentModel.event_id == filters['event_id'])
        if 'schedule_id' in filters and filters['schedule_id']:
            query = query.filter(JudgeAssignmentModel.schedule_id == filters['schedule_id'])
        if 'assigned_by' in filters and filters['assigned_by']:
            query = query.filter(JudgeAssignmentModel.assigned_by == filters['assigned_by'])
        if 'status' in filters and filters['status']:
            query = query.filter(JudgeAssignmentModel.status == filters['status'])
    
    # Get total count before pagination
    total = query.count()
    
    # Apply pagination
    results = query.order_by(JudgeAssignmentModel.assigned_at.desc()).offset(skip).limit(limit).all()
    
    # Convert results to list of dictionaries
    assignments = []
    for result in results:
        assignment, judge_first_name, judge_last_name, event_name, start_time, end_time, assigner_first_name, assigner_last_name = result
        
        assignments.append({
            "id": assignment.id,
            "user_id": assignment.user_id,
            "event_id": assignment.event_id,
            "schedule_id": assignment.schedule_id,
            "assigned_by": assignment.assigned_by,
            "status": assignment.status,
            "assigned_at": assignment.assigned_at,
            "judge_name": f"{judge_first_name} {judge_last_name}",
            "event_name": event_name,
            "schedule_date": start_time,
            "assigner_name": f"{assigner_first_name} {assigner_last_name}" if assigner_first_name and assigner_last_name else "Unknown"
        })
    
    return assignments, total

def update_judge_assignment(db: Session, assignment_id: int, assignment: JudgeAssignmentUpdate) -> JudgeAssignmentModel:
    """
    Update a judge assignment
    """
    db_assignment = get_judge_assignment(db, assignment_id)
    
    try:
        # Update status if provided
        if assignment.status is not None:
            db_assignment.status = assignment.status
        
        db.commit()
        db.refresh(db_assignment)
        return db_assignment
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating judge assignment: {str(e)}")

def delete_judge_assignment(db: Session, assignment_id: int) -> JudgeAssignmentModel:
    """
    Delete a judge assignment
    """
    db_assignment = get_judge_assignment(db, assignment_id)
    
    try:
        db.delete(db_assignment)
        db.commit()
        return db_assignment
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting judge assignment: {str(e)}")
