# app/core/permissions.py
from fastapi import Depends, HTTPException, status
from api.deps import get_current_user
from crud.rbac.roles import get_permissions_of_role, get_role_by_name, create_role, assign_permission
from crud.rbac.permissions import get_permission_by_name, create_permission
from sqlalchemy.orm import Session
from db.session import get_db
from models import User, Permission
from schemas.rbac.role import RoleCreate
from schemas.rbac.permission import PermissionCreate

def require_permission(permission: str):
    def permission_dependency(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
        # Check if permission exists, if not create it
        permission_obj = get_permission_by_name(db, permission)
        if not permission_obj:
            perm_create = PermissionCreate(
                permission_name=permission,
                description=f"Auto-generated permission: {permission}"
            )
            permission_obj = create_permission(db, perm_create)

            # Get Admin role and assign the new permission
            admin_role = get_role_by_name(db, "Admin")
            if admin_role:
                try:
                    assign_permission(db, admin_role.id, permission_obj.id)
                except HTTPException as e:
                    if "Permission already assigned to role" not in str(e.detail):
                        raise e

        # First check if user has Admin role for efficiency
        if any(role.role_name == "Admin" for role in user.roles):
            return user

        # If not admin, check specific permissions
        role_ids = [role.id for role in user.roles]
        if role_ids:
            permissions = get_permissions_of_role(db, role_ids)

            if permission in permissions:
                return user

        # If we get here, the user doesn't have the required permission
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"User does not have the '{permission}' permission"
        )
        return user
    return permission_dependency

def ensure_admin_role_exists(db: Session):
    """
    Ensures that the Admin role exists and has all permissions.
    Should be called on application startup.
    """
    # Check if Admin role exists
    admin_role = get_role_by_name(db, "Admin")
    if not admin_role:
        # Create Admin role
        role_create = RoleCreate(
            role_name="Admin",
            description="Administrator role with all permissions"
        )
        admin_role = create_role(db, role_create)

    # Get all existing permissions and ensure Admin has them
    permissions = db.query(Permission).all()
    for permission in permissions:
        try:
            assign_permission(db, admin_role.id, permission.id)
        except HTTPException as e:
            # Skip if permission is already assigned
            if "Permission already assigned to role" not in str(e.detail):
                raise e
