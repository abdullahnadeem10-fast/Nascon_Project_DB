import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import '../styles/About.css';

export default function About() {
  // Team members data
  const teamMembers = [
    {
      id: 1,
      name: "Ayaan Faisal",
      role: "Event Director",
      image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      bio: "Ayaan is leading NASCON for over 5 years with a background in Computer Science and Event Management."
    },
    {
      id: 2,
      name: "Salar Khan",
      role: "Technical Lead",
      image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      bio: "Salar oversees all technical competitions and workshops, bringing 10+ years of industry experience."
    },
    {
      id: 3,
      name: "Abdullah Nadeem",
      role: "Sponsorship Coordinator",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      bio: "Abdullah manages relationships with our corporate partners and ensures successful sponsorship campaigns."
    },
    {
      id: 4,
      name: "Zain Ahmed",
      role: "Creative Director",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
      bio: "Zain leads our design team and ensures NASCON's visual identity remains cutting-edge and memorable."
    },
  ];

  // Achievements data
  const achievements = [
    {
      year: "2023",
      title: "Record Participation",
      description: "Hosted over 5,000 participants from 120 universities across the country."
    },
    {
      year: "2022",
      title: "International Recognition",
      description: "NASCON was recognized as one of the top 10 student conferences in Asia."
    },
    {
      year: "2021",
      title: "Industry Partnerships",
      description: "Established partnerships with 25 leading technology companies for student opportunities."
    },
    {
      year: "2020",
      title: "Virtual Innovation",
      description: "Successfully transitioned to a fully virtual format during the pandemic, reaching a global audience."
    }
  ];

  return (
    <div className="about-page">
      {/* Hero Section */}
      <div className="about-hero">
        <Container>
          <Row className="justify-content-center text-center">
            <Col md={10} lg={8}>
              <h1 className="display-4 fw-bold text-white mb-4">About NASCON</h1>
              <p className="lead text-white-75 mb-5">
                Bringing together the brightest minds in technology, innovation, and entrepreneurship since 2010.
              </p>
            </Col>
          </Row>
        </Container>
      </div>

      {/* Mission Section */}
      <section className="py-5 bg-light">
        <Container>
          <Row className="justify-content-center">
            <Col md={10} lg={8} className="text-center">
              <h2 className="section-title">Our Mission</h2>
              <p className="section-subtitle">Empowering the next generation of innovators</p>
              <div className="section-divider"></div>
              <p className="mission-text">
                NASCON aims to bridge the gap between academic learning and industry requirements by providing a platform
                for students to showcase their talents, learn from industry experts, and network with peers from across the nation.
                We believe in fostering innovation, collaboration, and excellence in all our endeavors.
              </p>
            </Col>
          </Row>
        </Container>
      </section>

      {/* History Section */}
      <section className="py-5">
        <Container>
          <Row>
            <Col lg={6}>
              <h2 className="section-title">Our History</h2>
              <p className="section-subtitle">A decade of excellence and innovation</p>
              <div className="section-divider mb-4"></div>
              <p>
                Founded in 2010 by a group of passionate students and faculty members, NASCON started as a small departmental
                event with just 200 participants. Over the years, it has grown into one of the largest student-run technology
                conferences in the region.
              </p>
              <p>
                What began as a single-day event now spans an entire week, featuring competitions, workshops, panel discussions,
                and networking opportunities. Our growth reflects our commitment to providing value to students, academia, and industry partners.
              </p>
              <p>
                Today, NASCON stands as a testament to student leadership, innovation, and the power of community. We continue
                to evolve, embracing new technologies and addressing emerging challenges in the tech landscape.
              </p>
            </Col>
            <Col lg={6}>
              <div className="history-image-container">
                <img
                  src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="NASCON History"
                  className="img-fluid rounded shadow-lg"
                />
                <div className="history-image-overlay">
                  <span>Est. 2010</span>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Team Section */}
      <section className="py-5 bg-light">
        <Container>
          <Row className="text-center mb-5">
            <Col>
              <h2 className="section-title">Meet Our Team</h2>
              <p className="section-subtitle">The people behind NASCON's success</p>
              <div className="section-divider"></div>
            </Col>
          </Row>
          <Row>
            {teamMembers.map(member => (
              <Col md={6} lg={3} key={member.id} className="mb-4">
                <Card className="team-card h-100">
                  <div className="team-image-container">
                    <Card.Img variant="top" src={member.image} alt={member.name} className="team-image" />
                  </div>
                  <Card.Body className="text-center">
                    <Card.Title className="member-name">{member.name}</Card.Title>
                    <Card.Subtitle className="member-role mb-3">{member.role}</Card.Subtitle>
                    <Card.Text className="member-bio">{member.bio}</Card.Text>
                    <div className="social-icons">
                      <a href="#" className="social-icon"><i className="bi bi-linkedin"></i></a>
                      <a href="#" className="social-icon"><i className="bi bi-twitter"></i></a>
                      <a href="#" className="social-icon"><i className="bi bi-envelope"></i></a>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Achievements Section */}
      <section className="py-5">
        <Container>
          <Row className="text-center mb-5">
            <Col>
              <h2 className="section-title">Our Achievements</h2>
              <p className="section-subtitle">Milestones that define our journey</p>
              <div className="section-divider"></div>
            </Col>
          </Row>
          <Row className="achievement-timeline">
            {achievements.map((achievement, index) => (
              <Col md={6} className="mb-4" key={index}>
                <div className="achievement-card">
                  <div className="achievement-year">{achievement.year}</div>
                  <h3 className="achievement-title">{achievement.title}</h3>
                  <p className="achievement-description">{achievement.description}</p>
                </div>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Values Section */}
      <section className="py-5 bg-primary text-white values-section">
        <Container>
          <Row className="text-center mb-5">
            <Col>
              <h2 className="section-title text-white">Our Core Values</h2>
              <div className="section-divider bg-white"></div>
            </Col>
          </Row>
          <Row className="g-4">
            <Col md={4}>
              <div className="value-item text-center">
                <div className="value-icon">
                  <i className="bi bi-lightbulb-fill"></i>
                </div>
                <h3 className="value-title">Innovation</h3>
                <p>We encourage creative thinking and novel approaches to problem-solving.</p>
              </div>
            </Col>
            <Col md={4}>
              <div className="value-item text-center">
                <div className="value-icon">
                  <i className="bi bi-people-fill"></i>
                </div>
                <h3 className="value-title">Collaboration</h3>
                <p>We believe in the power of teamwork and diverse perspectives.</p>
              </div>
            </Col>
            <Col md={4}>
              <div className="value-item text-center">
                <div className="value-icon">
                  <i className="bi bi-award-fill"></i>
                </div>
                <h3 className="value-title">Excellence</h3>
                <p>We strive for the highest standards in everything we do.</p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Call to Action */}
      <section className="py-5 text-center cta-section">
        <Container>
          <Row className="justify-content-center">
            <Col md={8}>
              <h2 className="mb-4">Join Us in Shaping the Future</h2>
              <p className="lead mb-5">
                Whether you're a student looking to participate, a company interested in sponsorship,
                or an enthusiast wanting to volunteer, there's a place for you at NASCON.
              </p>
              <div className="d-flex justify-content-center gap-3">
                <a href="/events" className="btn btn-primary btn-lg">Explore Events</a>
                <a href="/contact" className="btn btn-outline-primary btn-lg">Contact Us</a>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </div>
  );
}