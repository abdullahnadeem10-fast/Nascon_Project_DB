import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BaseUrl from '../BaseUrl';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import '../styles/Teams.css';

function Teams() {
  const [teams, setTeams] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddTeamForm, setShowAddTeamForm] = useState(false);
  const [showAddMemberForm, setShowAddMemberForm] = useState(false);
  const [teamFormData, setTeamFormData] = useState({
    team_name: '',
    event_id: ''
  });
  const [memberFormData, setMemberFormData] = useState({
    team_id: '',
    user_id: '',
    is_team_lead: false
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [activeTeam, setActiveTeam] = useState(null);
  const [teamMembers, setTeamMembers] = useState([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);

  const baseUrl = BaseUrl;
  const accessToken = localStorage.getItem('access_token');
  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchTeams();
    fetchEvents();
  }, []);

  const fetchTeams = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${baseUrl}/teams/my-teams?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setTeams(response.data.teams || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching teams:', err);
      setError('Failed to load teams. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchEvents = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}/events/public?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
          },
        }
      );
      setEvents(response.data.events || []);
    } catch (err) {
      console.error('Error fetching events:', err);
    }
  };

  const fetchTeamMembers = async (teamId) => {
    try {
      setLoadingMembers(true);
      const response = await axios.get(
        `${baseUrl}/team-members/?skip=0&limit=100&team_id=${teamId}`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setTeamMembers(response.data.team_members || []);
    } catch (err) {
      console.error('Error fetching team members:', err);
    } finally {
      setLoadingMembers(false);
    }
  };

  const searchUsers = async (query) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      setSearchLoading(true);
      const response = await axios.get(
        `${baseUrl}/users/search?query=${query}`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setSearchResults(response.data.users || []);
    } catch (err) {
      console.error('Error searching users:', err);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleTeamInputChange = (e) => {
    const { name, value } = e.target;
    setTeamFormData({ ...teamFormData, [name]: value });

    // Clear error when field is edited
    if (formErrors[name]) {
      setFormErrors({ ...formErrors, [name]: '' });
    }
  };

  const handleMemberInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    setMemberFormData({ ...memberFormData, [name]: newValue });

    // Clear error when field is edited
    if (formErrors[name]) {
      setFormErrors({ ...formErrors, [name]: '' });
    }
  };

  const validateTeamForm = () => {
    const errors = {};

    if (!teamFormData.team_name.trim()) {
      errors.team_name = 'Team name is required';
    }

    if (!teamFormData.event_id) {
      errors.event_id = 'Event is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const validateMemberForm = () => {
    const errors = {};

    if (!memberFormData.user_id) {
      errors.user_id = 'User is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddTeam = async () => {
    if (!validateTeamForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.post(
        `${baseUrl}/teams/`,
        {
          team_name: teamFormData.team_name,
          event_id: parseInt(teamFormData.event_id)
        },
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      // Reset form
      setTeamFormData({
        team_name: '',
        event_id: ''
      });

      setShowAddTeamForm(false);
      await fetchTeams();
    } catch (err) {
      console.error('Error adding team:', err);
      setError('Failed to add team. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddMember = async () => {
    if (!validateMemberForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.post(
        `${baseUrl}/team-members/`,
        {
          team_id: parseInt(memberFormData.team_id),
          user_id: parseInt(memberFormData.user_id),
          is_team_lead: memberFormData.is_team_lead
        },
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      // Reset form
      setMemberFormData({
        team_id: memberFormData.team_id,
        user_id: '',
        is_team_lead: false
      });

      setShowAddMemberForm(false);
      if (activeTeam) {
        await fetchTeamMembers(activeTeam.id);
      }
    } catch (err) {
      console.error('Error adding team member:', err);
      setError('Failed to add team member. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteTeam = async (id) => {
    if (!window.confirm('Are you sure you want to delete this team?')) {
      return;
    }

    try {
      await axios.delete(
        `${baseUrl}/teams/${id}`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setTeams(teams.filter(team => team.id !== id));
      if (activeTeam && activeTeam.id === id) {
        setActiveTeam(null);
        setTeamMembers([]);
      }
    } catch (err) {
      console.error('Error deleting team:', err);
      setError('Failed to delete team. Please try again.');
    }
  };

  const handleRemoveMember = async (id) => {
    if (!window.confirm('Are you sure you want to remove this member?')) {
      return;
    }

    try {
      await axios.delete(
        `${baseUrl}/team-members/${id}`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setTeamMembers(teamMembers.filter(member => member.id !== id));
    } catch (err) {
      console.error('Error removing team member:', err);
      setError('Failed to remove team member. Please try again.');
    }
  };

  const handleViewTeam = (team) => {
    setActiveTeam(team);
    fetchTeamMembers(team.id);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);

    // Debounce search
    const timeoutId = setTimeout(() => {
      searchUsers(value);
    }, 500);

    return () => clearTimeout(timeoutId);
  };

  const handleSelectUser = (user) => {
    setMemberFormData({
      ...memberFormData,
      user_id: user.id
    });
    setSearchTerm(user.username || user.email);
    setSearchResults([]);
  };

  const getEventName = (eventId) => {
    const event = events.find(e => e.id === eventId);
    return event ? event.title : 'Unknown Event';
  };

  return (
    <div className="container mt-5 pt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1 className="h3">My Teams</h1>
        <button
          onClick={() => setShowAddTeamForm(true)}
          className="btn btn-primary d-flex align-items-center"
        >
          <i className="bi bi-plus-lg me-2"></i>
          Create Team
        </button>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
          <span>{error}</span>
          <button type="button" className="btn-close" aria-label="Close" onClick={() => setError(null)}></button>
        </div>
      )}

      <div className="row">
        {/* Teams List */}
        <div className={`col-md-${activeTeam ? '4' : '12'} mb-4`}>
          <div className="card shadow-sm">
            <div className="card-header bg-light">
              <h5 className="mb-0">My Teams</h5>
            </div>
            <div className="card-body p-0">
              {loading ? (
                <div className="d-flex justify-content-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : teams.length > 0 ? (
                <div className="list-group list-group-flush">
                  {teams.map(team => (
                    <div key={team.id} className={`list-group-item list-group-item-action d-flex justify-content-between align-items-center ${activeTeam && activeTeam.id === team.id ? 'active' : ''}`}>
                      <div className="d-flex flex-column" onClick={() => handleViewTeam(team)} style={{ cursor: 'pointer', flex: 1 }}>
                        <h6 className="mb-1">{team.team_name}</h6>
                        <small>{getEventName(team.event_id)}</small>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTeam(team.id);
                        }}
                        className="btn btn-sm btn-outline-danger"
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-5">
                  <i className="bi bi-people display-4 text-muted mb-3"></i>
                  <p className="lead mb-0">No teams found</p>
                  <p className="text-muted">Click "Create Team" to get started</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Team Members */}
        {activeTeam && (
          <div className="col-md-8">
            <div className="card shadow-sm">
              <div className="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 className="mb-0">{activeTeam.team_name} - Members</h5>
                <button
                  onClick={() => {
                    setMemberFormData({
                      team_id: activeTeam.id.toString(),
                      user_id: '',
                      is_team_lead: false
                    });
                    setShowAddMemberForm(true);
                  }}
                  className="btn btn-sm btn-primary"
                >
                  <i className="bi bi-person-plus me-1"></i> Add Member
                </button>
              </div>
              <div className="card-body p-0">
                {loadingMembers ? (
                  <div className="d-flex justify-content-center py-5">
                    <div className="spinner-border text-primary" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </div>
                  </div>
                ) : teamMembers.length > 0 ? (
                  <div className="table-responsive">
                    <table className="table table-hover mb-0">
                      <thead className="table-light">
                        <tr>
                          <th>User ID</th>
                          <th>Role</th>
                          <th>Joined</th>
                          <th className="text-end">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {teamMembers.map(member => (
                          <tr key={member.id}>
                            <td>{member.user_id}</td>
                            <td>
                              {member.is_team_lead ? (
                                <span className="badge bg-primary">Team Lead</span>
                              ) : (
                                <span className="badge bg-secondary">Member</span>
                              )}
                            </td>
                            <td>{new Date(member.created_at).toLocaleDateString()}</td>
                            <td className="text-end">
                              <button
                                onClick={() => handleRemoveMember(member.id)}
                                className="btn btn-sm btn-outline-danger"
                                disabled={member.user_id === currentUser.id}
                              >
                                <i className="bi bi-person-x"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-5">
                    <i className="bi bi-person-plus display-4 text-muted mb-3"></i>
                    <p className="lead mb-0">No team members yet</p>
                    <p className="text-muted">Add members to your team</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Team Modal */}
      {showAddTeamForm && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Create New Team</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddTeamForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label htmlFor="team_name" className="form-label">Team Name *</label>
                  <input
                    type="text"
                    className={`form-control ${formErrors.team_name ? 'is-invalid' : ''}`}
                    id="team_name"
                    name="team_name"
                    value={teamFormData.team_name}
                    onChange={handleTeamInputChange}
                  />
                  {formErrors.team_name && <div className="invalid-feedback">{formErrors.team_name}</div>}
                </div>

                <div className="mb-3">
                  <label htmlFor="event_id" className="form-label">Event *</label>
                  <select
                    className={`form-select ${formErrors.event_id ? 'is-invalid' : ''}`}
                    id="event_id"
                    name="event_id"
                    value={teamFormData.event_id}
                    onChange={handleTeamInputChange}
                  >
                    <option value="">Select Event</option>
                    {events.map(event => (
                      <option key={event.id} value={event.id}>{event.title}</option>
                    ))}
                  </select>
                  {formErrors.event_id && <div className="invalid-feedback">{formErrors.event_id}</div>}
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddTeamForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleAddTeam}
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Creating...
                    </>
                  ) : (
                    'Create Team'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Member Modal */}
      {showAddMemberForm && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add Team Member</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddMemberForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label htmlFor="user_id" className="form-label">Search User *</label>
                  <input
                    type="text"
                    className={`form-control ${formErrors.user_id ? 'is-invalid' : ''}`}
                    id="user_search"
                    placeholder="Search by username or email"
                    value={searchTerm}
                    onChange={handleSearchChange}
                  />
                  {formErrors.user_id && <div className="invalid-feedback">{formErrors.user_id}</div>}

                  {searchResults.length > 0 && (
                    <div className="search-results mt-2">
                      {searchResults.map(user => (
                        <div
                          key={user.id}
                          className="search-result-item p-2 border-bottom"
                          onClick={() => handleSelectUser(user)}
                        >
                          <div className="d-flex align-items-center">
                            <div className="me-2">
                              <i className="bi bi-person-circle"></i>
                            </div>
                            <div>
                              <div>{user.username || 'No username'}</div>
                              <small className="text-muted">{user.email}</small>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {searchLoading && (
                    <div className="text-center mt-2">
                      <div className="spinner-border spinner-border-sm text-primary" role="status">
                        <span className="visually-hidden">Loading...</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mb-3 form-check">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="is_team_lead"
                    name="is_team_lead"
                    checked={memberFormData.is_team_lead}
                    onChange={handleMemberInputChange}
                  />
                  <label className="form-check-label" htmlFor="is_team_lead">Make Team Lead</label>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddMemberForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleAddMember}
                  disabled={submitting || !memberFormData.user_id}
                >
                  {submitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Adding...
                    </>
                  ) : (
                    'Add Member'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Teams;