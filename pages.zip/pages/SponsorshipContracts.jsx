import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BaseUrl from '../BaseUrl';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import '../styles/SponsorshipContracts.css';


function SponsorshipContracts() {
  const [contracts, setContracts] = useState([]);
  const [sponsors, setSponsors] = useState([]);
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    sponsor_id: 0,
    package_id: 0,
    start_date: '',
    end_date: '',
    total_amount: 0,
    status: 'Pending',
    payment_status: 'Pending' // Valid values: 'Pending', 'Partial', 'Completed'
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [selectedContract, setSelectedContract] = useState(null);
  const [showEditForm, setShowEditForm] = useState(false);

  const accessToken = localStorage.getItem('access_token');
  const apiBaseUrl = BaseUrl;

  useEffect(() => {
    fetchContracts();
    fetchSponsors();
    fetchPackages();
  }, []);

  const fetchContracts = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${apiBaseUrl}/sponsorship/contracts/?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setContracts(response.data.contracts || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching contracts:', err);
      setError('Failed to load contracts. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchSponsors = async () => {
    try {
      const response = await axios.get(
        `${apiBaseUrl}/sponsorship/sponsors/?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setSponsors(response.data.sponsors || []);
    } catch (err) {
      console.error('Error fetching sponsors:', err);
    }
  };

  const fetchPackages = async () => {
    try {
      const response = await axios.get(
        `${apiBaseUrl}/sponsorship/packages/?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setPackages(response.data.packages || []);
    } catch (err) {
      console.error('Error fetching packages:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let parsedValue = value;

    // Convert numeric values
    if (name === 'sponsor_id' || name === 'package_id') {
      parsedValue = parseInt(value, 10);
    } else if (name === 'total_amount') {
      parsedValue = parseFloat(value);
    }

    setFormData({ ...formData, [name]: parsedValue });

    // Clear error when field is edited
    if (formErrors[name]) {
      setFormErrors({ ...formErrors, [name]: '' });
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.sponsor_id) {
      errors.sponsor_id = 'Sponsor is required';
    }

    if (!formData.package_id) {
      errors.package_id = 'Package is required';
    }

    if (!formData.start_date) {
      errors.start_date = 'Start date is required';
    }

    if (!formData.end_date) {
      errors.end_date = 'End date is required';
    } else if (formData.end_date < formData.start_date) {
      errors.end_date = 'End date must be after start date';
    }

    if (!formData.total_amount || formData.total_amount <= 0) {
      errors.total_amount = 'Valid amount is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddContract = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.post(
        `${apiBaseUrl}/sponsorship/contracts/`,
        formData,
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      // Reset form
      setFormData({
        sponsor_id: 0,
        package_id: 0,
        start_date: '',
        end_date: '',
        total_amount: 0,
        status: 'Pending',
        payment_status: 'Pending' // Valid values: 'Pending', 'Partial', 'Completed'
      });

      setShowAddForm(false);
      await fetchContracts();
    } catch (err) {
      console.error('Error adding contract:', err);
      setError('Failed to add contract. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateContract = async () => {
    if (!selectedContract || !validateForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.put(
        `${apiBaseUrl}/sponsorship/contracts/${selectedContract.id}`,
        formData,
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setShowEditForm(false);
      setSelectedContract(null);
      await fetchContracts();
    } catch (err) {
      console.error('Error updating contract:', err);
      setError('Failed to update contract. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteContract = async (id) => {
    if (!window.confirm('Are you sure you want to delete this contract?')) {
      return;
    }

    try {
      await axios.delete(
        `${apiBaseUrl}/sponsorship/contracts/${id}`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setContracts(contracts.filter(contract => contract.id !== id));
    } catch (err) {
      console.error('Error deleting contract:', err);
      setError('Failed to delete contract. Please try again.');
    }
  };

  const handleEditContract = (contract) => {
    setSelectedContract(contract);
    setFormData({
      sponsor_id: contract.sponsor_id,
      package_id: contract.package_id,
      start_date: contract.start_date,
      end_date: contract.end_date,
      total_amount: contract.total_amount,
      status: contract.status,
      payment_status: contract.payment_status
    });
    setShowEditForm(true);
  };

  const handleUpdateStatus = async (id, status) => {
    try {
      await axios.patch(
        `${apiBaseUrl}/sponsorship/contracts/${id}/status`,
        { status },
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      // Update local state
      setContracts(contracts.map(contract =>
        contract.id === id ? { ...contract, status } : contract
      ));
    } catch (err) {
      console.error('Error updating status:', err);
      setError('Failed to update status. Please try again.');
    }
  };

  const handleUpdatePaymentStatus = async (id, payment_status) => {
    try {
      await axios.patch(
        `${apiBaseUrl}/sponsorship/contracts/${id}/payment-status`,
        { payment_status },
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      // Update local state
      setContracts(contracts.map(contract =>
        contract.id === id ? { ...contract, payment_status } : contract
      ));
    } catch (err) {
      console.error('Error updating payment status:', err);
      setError('Failed to update payment status. Please try again.');
    }
  };

  const getSponsorName = (id) => {
    const sponsor = sponsors.find(s => s.id === id);
    return sponsor ? sponsor.company_name : 'Unknown';
  };

  const getPackageName = (id) => {
    const pkg = packages.find(p => p.id === id);
    return pkg ? pkg.package_name : 'Unknown';
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-success';
      case 'Pending':
        return 'bg-warning text-dark';
      case 'Expired':
        return 'bg-danger';
      case 'Cancelled':
        return 'bg-secondary';
      default:
        return 'bg-info';
    }
  };

  const getPaymentStatusBadgeClass = (status) => {
    switch (status) {
      case 'Completed':
        return 'bg-success';
      case 'Pending':
        return 'bg-warning text-dark';
      case 'Partial':
        return 'bg-info';
      default:
        return 'bg-secondary';
    }
  };

  return (
    <div className="container-fluid mt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1 className="h3">Sponsorship Contracts</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="btn btn-primary d-flex align-items-center"
        >
          <i className="bi bi-plus-lg me-2"></i>
          Add Contract
        </button>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
          <span>{error}</span>
          <button type="button" className="btn-close" aria-label="Close" onClick={() => setError(null)}></button>
        </div>
      )}

      {loading ? (
        <div className="d-flex justify-content-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : (
        <>
          {contracts && contracts.length > 0 ? (
            <div className="card shadow-sm">
              <div className="card-body p-0">
                <div className="table-container">
                  <table className="table table-striped table-hover mb-0">
                    <thead className="bg-light">
                      <tr>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '120px' }}>Sponsor</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '120px' }}>Package</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '180px' }}>Duration</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '100px' }}>Amount</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '100px' }}>Status</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '100px' }}>Payment</th>
                        <th scope="col" className="px-3 py-2 text-end" style={{ minWidth: '120px' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {contracts.map((contract) => (
                        <tr key={contract.id} className="hover-bg-light">
                          <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>{getSponsorName(contract.sponsor_id)}</td>
                          <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>{getPackageName(contract.package_id)}</td>
                          <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>
                            {new Date(contract.start_date).toLocaleDateString()} -
                            {new Date(contract.end_date).toLocaleDateString()}
                          </td>
                          <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>${contract.total_amount.toLocaleString()}</td>
                          <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>
                            <div className="dropdown">
                              <span
                                className={`badge ${getStatusBadgeClass(contract.status)} dropdown-toggle`}
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                              >
                                {contract.status}
                              </span>
                              <ul className="dropdown-menu">
                                <li><button className="dropdown-item" onClick={() => handleUpdateStatus(contract.id, 'Pending')}>Pending</button></li>
                                <li><button className="dropdown-item" onClick={() => handleUpdateStatus(contract.id, 'Active')}>Active</button></li>
                                <li><button className="dropdown-item" onClick={() => handleUpdateStatus(contract.id, 'Expired')}>Expired</button></li>
                                <li><button className="dropdown-item" onClick={() => handleUpdateStatus(contract.id, 'Cancelled')}>Cancelled</button></li>
                              </ul>
                            </div>
                          </td>
                          <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>
                            <div className="dropdown">
                              <span
                                className={`badge ${getPaymentStatusBadgeClass(contract.payment_status)} dropdown-toggle`}
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                              >
                                {contract.payment_status}
                              </span>
                              <ul className="dropdown-menu">
                                <li><button className="dropdown-item" onClick={() => handleUpdatePaymentStatus(contract.id, 'Pending')}>Pending</button></li>
                                <li><button className="dropdown-item" onClick={() => handleUpdatePaymentStatus(contract.id, 'Partial')}>Partial</button></li>
                                <li><button className="dropdown-item" onClick={() => handleUpdatePaymentStatus(contract.id, 'Completed')}>Completed</button></li>
                              </ul>
                            </div>
                          </td>
                          <td className="px-3 py-2 text-end" style={{ whiteSpace: 'nowrap' }}>
                            <button
                              onClick={() => handleEditContract(contract)}
                              className="btn btn-outline-primary btn-sm me-2"
                            >
                              <i className="bi bi-pencil"></i>
                            </button>
                            <button
                              onClick={() => handleDeleteContract(contract.id)}
                              className="btn btn-outline-danger btn-sm"
                            >
                              <i className="bi bi-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="card shadow-sm">
              <div className="card-body text-center py-5">
                <i className="bi bi-file-earmark-text display-4 text-muted mb-3"></i>
                <p className="lead mb-0">No sponsorship contracts found</p>
                <p className="text-muted">Click "Add Contract" to create your first contract</p>
              </div>
            </div>
          )}
        </>
      )}

      {/* Add Contract Modal */}
      {showAddForm && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Contract</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="sponsor_id" className="form-label">Sponsor *</label>
                    <select
                      className={`form-select ${formErrors.sponsor_id ? 'is-invalid' : ''}`}
                      id="sponsor_id"
                      name="sponsor_id"
                      value={formData.sponsor_id}
                      onChange={handleInputChange}
                    >
                      <option value={0}>Select Sponsor</option>
                      {sponsors.map(sponsor => (
                        <option key={sponsor.id} value={sponsor.id}>{sponsor.company_name}</option>
                      ))}
                    </select>
                    {formErrors.sponsor_id && <div className="invalid-feedback">{formErrors.sponsor_id}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="package_id" className="form-label">Package *</label>
                    <select
                      className={`form-select ${formErrors.package_id ? 'is-invalid' : ''}`}
                      id="package_id"
                      name="package_id"
                      value={formData.package_id}
                      onChange={handleInputChange}
                    >
                      <option value={0}>Select Package</option>
                      {packages.map(pkg => (
                        <option key={pkg.id} value={pkg.id}>{pkg.package_name} (${pkg.price})</option>
                      ))}
                    </select>
                    {formErrors.package_id && <div className="invalid-feedback">{formErrors.package_id}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="start_date" className="form-label">Start Date *</label>
                    <input
                      type="date"
                      className={`form-control ${formErrors.start_date ? 'is-invalid' : ''}`}
                      id="start_date"
                      name="start_date"
                      value={formData.start_date}
                      onChange={handleInputChange}
                    />
                    {formErrors.start_date && <div className="invalid-feedback">{formErrors.start_date}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="end_date" className="form-label">End Date *</label>
                    <input
                      type="date"
                      className={`form-control ${formErrors.end_date ? 'is-invalid' : ''}`}
                      id="end_date"
                      name="end_date"
                      value={formData.end_date}
                      onChange={handleInputChange}
                    />
                    {formErrors.end_date && <div className="invalid-feedback">{formErrors.end_date}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="total_amount" className="form-label">Total Amount *</label>
                    <div className="input-group">
                      <span className="input-group-text">$</span>
                      <input
                        type="number"
                        className={`form-control ${formErrors.total_amount ? 'is-invalid' : ''}`}
                        id="total_amount"
                        name="total_amount"
                        value={formData.total_amount}
                        onChange={handleInputChange}
                        min="0"
                        step="0.01"
                      />
                      {formErrors.total_amount && <div className="invalid-feedback">{formErrors.total_amount}</div>}
                    </div>
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="status" className="form-label">Status</label>
                    <select
                      className="form-select"
                      id="status"
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Active">Active</option>
                      <option value="Expired">Expired</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="payment_status" className="form-label">Payment Status</label>
                    <select
                      className="form-select"
                      id="payment_status"
                      name="payment_status"
                      value={formData.payment_status}
                      onChange={handleInputChange}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Partial">Partial</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleAddContract}
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Saving...
                    </>
                  ) : (
                    'Save Contract'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Contract Modal */}
      {showEditForm && selectedContract && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit Contract</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="edit_sponsor_id" className="form-label">Sponsor *</label>
                    <select
                      className={`form-select ${formErrors.sponsor_id ? 'is-invalid' : ''}`}
                      id="edit_sponsor_id"
                      name="sponsor_id"
                      value={formData.sponsor_id}
                      onChange={handleInputChange}
                    >
                      <option value={0}>Select Sponsor</option>
                      {sponsors.map(sponsor => (
                        <option key={sponsor.id} value={sponsor.id}>{sponsor.company_name}</option>
                      ))}
                    </select>
                    {formErrors.sponsor_id && <div className="invalid-feedback">{formErrors.sponsor_id}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_package_id" className="form-label">Package *</label>
                    <select
                      className={`form-select ${formErrors.package_id ? 'is-invalid' : ''}`}
                      id="edit_package_id"
                      name="package_id"
                      value={formData.package_id}
                      onChange={handleInputChange}
                    >
                      <option value={0}>Select Package</option>
                      {packages.map(pkg => (
                        <option key={pkg.id} value={pkg.id}>{pkg.package_name} (${pkg.price})</option>
                      ))}
                    </select>
                    {formErrors.package_id && <div className="invalid-feedback">{formErrors.package_id}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_start_date" className="form-label">Start Date *</label>
                    <input
                      type="date"
                      className={`form-control ${formErrors.start_date ? 'is-invalid' : ''}`}
                      id="edit_start_date"
                      name="start_date"
                      value={formData.start_date}
                      onChange={handleInputChange}
                    />
                    {formErrors.start_date && <div className="invalid-feedback">{formErrors.start_date}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_end_date" className="form-label">End Date *</label>
                    <input
                      type="date"
                      className={`form-control ${formErrors.end_date ? 'is-invalid' : ''}`}
                      id="edit_end_date"
                      name="end_date"
                      value={formData.end_date}
                      onChange={handleInputChange}
                    />
                    {formErrors.end_date && <div className="invalid-feedback">{formErrors.end_date}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_total_amount" className="form-label">Total Amount *</label>
                    <div className="input-group">
                      <span className="input-group-text">$</span>
                      <input
                        type="number"
                        className={`form-control ${formErrors.total_amount ? 'is-invalid' : ''}`}
                        id="edit_total_amount"
                        name="total_amount"
                        value={formData.total_amount}
                        onChange={handleInputChange}
                        min="0"
                        step="0.01"
                      />
                      {formErrors.total_amount && <div className="invalid-feedback">{formErrors.total_amount}</div>}
                    </div>
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_status" className="form-label">Status</label>
                    <select
                      className="form-select"
                      id="edit_status"
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Active">Active</option>
                      <option value="Expired">Expired</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_payment_status" className="form-label">Payment Status</label>
                    <select
                      className="form-select"
                      id="edit_payment_status"
                      name="payment_status"
                      value={formData.payment_status}
                      onChange={handleInputChange}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Partial">Partial</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowEditForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleUpdateContract}
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Updating...
                    </>
                  ) : (
                    'Update Contract'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default SponsorshipContracts;