import { useState, useEffect } from 'react';
import BaseUrl from '../BaseUrl';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

export default function SponsorshipPage() {
  const token = localStorage.getItem('access_token');
  const [sponsors, setSponsors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    company_name: '',
    contact_person_name: '',
    email: '',
    phone_number: '',
    address: '',
    logo_url: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const apiBaseUrl = BaseUrl + `/sponsorship`;

  useEffect(() => {
    fetchSponsors();
  }, []);

  const fetchSponsors = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${apiBaseUrl}/sponsors/?skip=0&limit=100`, {
        headers: { 'accept': 'application/json', 'Authorization': `Bearer ${token}` }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch sponsors');
      }
      const data = await response.json();
      setSponsors(data.sponsors);
      setError(null);
    } catch (err) {
      setError('Error loading sponsors. Please try again later.');
      console.error('Error fetching sponsors:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (formErrors[name]) {
      setFormErrors({ ...formErrors, [name]: null });
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.company_name.trim()) errors.company_name = 'Company name is required';
    if (!formData.contact_person_name.trim()) errors.contact_person_name = 'Contact person name is required';
    if (!formData.email.trim()) errors.email = 'Email is required';
    if (!formData.email.includes('@')) errors.email = 'Valid email is required';
    if (!formData.phone_number.trim()) errors.phone_number = 'Phone number is required';
    if (!formData.address.trim()) errors.address = 'Address is required';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddSponsor = async () => {
    if (!validateForm()) {
      return;
    }
    try {
      setSubmitting(true);
      const response = await fetch(`${apiBaseUrl}/sponsors/`, {
        method: 'POST',
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });
      if (!response.ok) {
        throw new Error('Failed to add sponsor');
      }
      setFormData({
        company_name: '',
        contact_person_name: '',
        email: '',
        phone_number: '',
        address: '',
        logo_url: ''
      });
      setShowAddForm(false);
      await fetchSponsors();
    } catch (err) {
      setError('Error adding sponsor. Please try again.');
      console.error('Error adding sponsor:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteSponsor = async (id) => {
    if (!window.confirm('Are you sure you want to delete this sponsor?')) {
      return;
    }
    try {
      const response = await fetch(`${apiBaseUrl}/sponsors/${id}`, {
        method: 'DELETE',
        headers: { 'accept': 'application/json', 'Authorization': `Bearer ${token}` }
      });
      if (!response.ok) {
        throw new Error('Failed to delete sponsor');
      }
      setSponsors(sponsors.filter(sponsor => sponsor.id !== id));
    } catch (err) {
      setError('Error deleting sponsor. Please try again.');
      console.error('Error deleting sponsor:', err);
    }
  };

  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1 className="h3">Sponsorship Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="btn btn-primary d-flex align-items-center"
        >
          <i className="bi bi-plus-lg me-2"></i>
          Add Sponsor
        </button>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
          <span>{error}</span>
          <button type="button" className="btn-close" aria-label="Close" onClick={() => setError(null)}></button>
        </div>
      )}

      {loading ? (
        <div className="d-flex justify-content-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : (
        <>
          {sponsors && sponsors.length > 0 ? (
            <div className="card shadow-sm">
              <div className="card-body p-0">
                <div className="table-responsive">
                  <table className="table table-striped table-hover mb-0">
                    <thead className="bg-light">
                      <tr>
                        <th scope="col" className="px-3 py-2">Company</th>
                        <th scope="col" className="px-3 py-2">Contact Person</th>
                        <th scope="col" className="px-3 py-2">Email</th>
                        <th scope="col" className="px-3 py-2">Phone</th>
                        <th scope="col" className="px-3 py-2">Logo</th>
                        <th scope="col" className="px-3 py-2 text-end">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sponsors.map((sponsor) => (
                        <tr key={sponsor.id} className="hover-bg-light">
                          <td className="px-3 py-2">{sponsor.company_name}</td>
                          <td className="px-3 py-2">{sponsor.contact_person_name}</td>
                          <td className="px-3 py-2">{sponsor.email}</td>
                          <td className="px-3 py-2">{sponsor.phone_number}</td>
                          <td className="px-3 py-2">
                            {sponsor.logo_url && (
                              <img
                                src={sponsor.logo_url}
                                alt={`${sponsor.company_name} logo`}
                                className="img-fluid rounded"
                                style={{ maxHeight: '40px' }}
                                onError={(e) => {
                                  e.target.onerror = null;
                                  e.target.src = "/api/placeholder/100/40";
                                }}
                              />
                            )}
                          </td>
                          <td className="px-3 py-2 text-end">
                            <button
                              onClick={() => handleDeleteSponsor(sponsor.id)}
                              className="btn btn-outline-danger btn-sm"
                            >
                              <i className="bi bi-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="alert alert-info py-5 text-center" role="alert">
              No sponsors found. Add your first sponsor!
            </div>
          )}
        </>
      )}

      {showAddForm && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Sponsor</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="company_name" className="form-label">Company Name *</label>
                    <input
                      type="text"
                      className={`form-control ${formErrors.company_name ? 'is-invalid' : ''}`}
                      id="company_name"
                      name="company_name"
                      value={formData.company_name}
                      onChange={handleInputChange}
                    />
                    {formErrors.company_name && <div className="invalid-feedback">{formErrors.company_name}</div>}
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="contact_person_name" className="form-label">Contact Person *</label>
                    <input
                      type="text"
                      className={`form-control ${formErrors.contact_person_name ? 'is-invalid' : ''}`}
                      id="contact_person_name"
                      name="contact_person_name"
                      value={formData.contact_person_name}
                      onChange={handleInputChange}
                    />
                    {formErrors.contact_person_name && <div className="invalid-feedback">{formErrors.contact_person_name}</div>}
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="email" className="form-label">Email *</label>
                    <input
                      type="email"
                      className={`form-control ${formErrors.email ? 'is-invalid' : ''}`}
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                    />
                    {formErrors.email && <div className="invalid-feedback">{formErrors.email}</div>}
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="phone_number" className="form-label">Phone Number *</label>
                    <input
                      type="text"
                      className={`form-control ${formErrors.phone_number ? 'is-invalid' : ''}`}
                      id="phone_number"
                      name="phone_number"
                      value={formData.phone_number}
                      onChange={handleInputChange}
                    />
                    {formErrors.phone_number && <div className="invalid-feedback">{formErrors.phone_number}</div>}
                  </div>
                  <div className="col-12">
                    <label htmlFor="address" className="form-label">Address *</label>
                    <input
                      type="text"
                      className={`form-control ${formErrors.address ? 'is-invalid' : ''}`}
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                    />
                    {formErrors.address && <div className="invalid-feedback">{formErrors.address}</div>}
                  </div>
                  <div className="col-12">
                    <label htmlFor="logo_url" className="form-label">Logo URL (Optional)</label>
                    <input
                      type="text"
                      className="form-control"
                      id="logo_url"
                      name="logo_url"
                      value={formData.logo_url}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleAddSponsor}
                  disabled={submitting}
                >
                  {submitting ? (
                    <div className="spinner-border spinner-border-sm me-2" role="status">
                      <span className="visually-hidden">Submitting...</span>
                    </div>
                  ) : (
                    'Save Sponsor'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}