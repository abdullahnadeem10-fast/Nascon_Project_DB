import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BaseUrl from '../../../BaseUrl';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import '../../../styles/CreateEvent.css';

function CreateEvent() {
  const [formData, setFormData] = useState({
    event_name: '',
    description: '',
    rules: '',
    max_participants: 1,
    registration_fee: 0,
    registration_deadline: '',
    category_id: '',
    is_team_event: false,
    min_team_size: 1,
    max_team_size: 1
  });

  const [categories, setCategories] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const accessToken = localStorage.getItem('access_token');

  // Fetch event categories on component mount
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get(
          `${BaseUrl}/event-categories/?skip=0&limit=100`,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
              accept: 'application/json'
            }
          }
        );
        // API returns array directly, not wrapped in a categories property
        setCategories(Array.isArray(response.data) ? response.data : []);
      } catch (error) {
        console.error('Error fetching event categories:', error);
        setErrorMessage('Failed to load event categories. Please try again later.');
      }
    };

    fetchCategories();
  }, [accessToken]);

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;

    // For checkboxes, use the checked property
    const newValue = type === 'checkbox' ? checked : value;

    // For number inputs, convert to number
    const processedValue = type === 'number' ?
      (value === '' ? '' : Number(value)) : newValue;

    setFormData({
      ...formData,
      [name]: processedValue
    });

    // Clear error when field is edited
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: null
      });
    }
  };

  // Form validation
  const validateForm = () => {
    const errors = {};

    if (!formData.event_name.trim()) {
      errors.event_name = 'Event name is required';
    }

    if (!formData.description.trim()) {
      errors.description = 'Description is required';
    }

    if (!formData.rules.trim()) {
      errors.rules = 'Rules are required';
    }

    if (formData.max_participants < 1) {
      errors.max_participants = 'Maximum participants must be at least 1';
    }

    if (formData.registration_fee < 0) {
      errors.registration_fee = 'Registration fee cannot be negative';
    }

    if (!formData.registration_deadline) {
      errors.registration_deadline = 'Registration deadline is required';
    } else {
      const deadlineDate = new Date(formData.registration_deadline);
      const currentDate = new Date();
      if (deadlineDate <= currentDate) {
        errors.registration_deadline = 'Registration deadline must be in the future';
      }
    }

    if (!formData.category_id) {
      errors.category_id = 'Category is required';
    }

    if (formData.is_team_event) {
      if (formData.min_team_size < 1) {
        errors.min_team_size = 'Minimum team size must be at least 1';
      }

      if (formData.max_team_size < formData.min_team_size) {
        errors.max_team_size = 'Maximum team size must be greater than or equal to minimum team size';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form
    if (!validateForm()) {
      return;
    }

    // Prepare data for API
    const eventData = {
      ...formData,
      category_id: parseInt(formData.category_id),
      max_participants: parseInt(formData.max_participants),
      registration_fee: parseFloat(formData.registration_fee),
      min_team_size: parseInt(formData.min_team_size),
      max_team_size: parseInt(formData.max_team_size)
    };

    setSubmitting(true);
    setSuccessMessage('');
    setErrorMessage('');

    try {
      await axios.post(
        `${BaseUrl}/events/`,
        eventData,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
            accept: 'application/json'
          }
        }
      );

      setSuccessMessage('Event created successfully!');

      // Reset form
      setFormData({
        event_name: '',
        description: '',
        rules: '',
        max_participants: 1,
        registration_fee: 0,
        registration_deadline: '',
        category_id: '',
        is_team_event: false,
        min_team_size: 1,
        max_team_size: 1
      });

    } catch (error) {
      console.error('Error creating event:', error);
      setErrorMessage('Failed to create event. Please check your inputs and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  // Handle form reset
  const handleReset = () => {
    setFormData({
      event_name: '',
      description: '',
      rules: '',
      max_participants: 1,
      registration_fee: 0,
      registration_deadline: '',
      category_id: '',
      is_team_event: false,
      min_team_size: 1,
      max_team_size: 1
    });
    setFormErrors({});
    setSuccessMessage('');
    setErrorMessage('');
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-lg-10">
          <div className="card shadow-sm border-0">
            <div className="card-header bg-primary text-white py-3">
              <h4 className="mb-0">Create New Event</h4>
            </div>
            <div className="card-body p-4">
              {successMessage && (
                <div className="alert alert-success alert-dismissible fade show" role="alert">
                  <i className="bi bi-check-circle-fill me-2"></i>
                  {successMessage}
                  <button type="button" className="btn-close" onClick={() => setSuccessMessage('')} aria-label="Close"></button>
                </div>
              )}

              {errorMessage && (
                <div className="alert alert-danger alert-dismissible fade show" role="alert">
                  <i className="bi bi-exclamation-triangle-fill me-2"></i>
                  {errorMessage}
                  <button type="button" className="btn-close" onClick={() => setErrorMessage('')} aria-label="Close"></button>
                </div>
              )}

              <form onSubmit={handleSubmit} className="needs-validation">
                <div className="row g-3">
                  {/* Event Name */}
                  <div className="col-md-6">
                    <label htmlFor="event_name" className="form-label">Event Name *</label>
                    <input
                      type="text"
                      className={`form-control ${formErrors.event_name ? 'is-invalid' : ''}`}
                      id="event_name"
                      name="event_name"
                      value={formData.event_name}
                      onChange={handleInputChange}
                      placeholder="Enter event name"
                    />
                    {formErrors.event_name && <div className="invalid-feedback">{formErrors.event_name}</div>}
                  </div>

                  {/* Category */}
                  <div className="col-md-6">
                    <label htmlFor="category_id" className="form-label">Category *</label>
                    <select
                      className={`form-select ${formErrors.category_id ? 'is-invalid' : ''}`}
                      id="category_id"
                      name="category_id"
                      value={formData.category_id}
                      onChange={handleInputChange}
                    >
                      <option value="">Select a category</option>
                      {categories.map(category => (
                        <option key={category.id} value={category.id}>
                          {category.category_name}
                        </option>
                      ))}
                    </select>
                    {formErrors.category_id && <div className="invalid-feedback">{formErrors.category_id}</div>}
                  </div>

                  {/* Description */}
                  <div className="col-12">
                    <label htmlFor="description" className="form-label">Description *</label>
                    <textarea
                      className={`form-control ${formErrors.description ? 'is-invalid' : ''}`}
                      id="description"
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      rows="3"
                      placeholder="Enter event description"
                    ></textarea>
                    {formErrors.description && <div className="invalid-feedback">{formErrors.description}</div>}
                  </div>

                  {/* Rules */}
                  <div className="col-12">
                    <label htmlFor="rules" className="form-label">Rules *</label>
                    <textarea
                      className={`form-control ${formErrors.rules ? 'is-invalid' : ''}`}
                      id="rules"
                      name="rules"
                      value={formData.rules}
                      onChange={handleInputChange}
                      rows="3"
                      placeholder="Enter event rules"
                    ></textarea>
                    {formErrors.rules && <div className="invalid-feedback">{formErrors.rules}</div>}
                  </div>

                  {/* Max Participants */}
                  <div className="col-md-4">
                    <label htmlFor="max_participants" className="form-label">Max Participants *</label>
                    <input
                      type="number"
                      className={`form-control ${formErrors.max_participants ? 'is-invalid' : ''}`}
                      id="max_participants"
                      name="max_participants"
                      value={formData.max_participants}
                      onChange={handleInputChange}
                      min="1"
                    />
                    {formErrors.max_participants && <div className="invalid-feedback">{formErrors.max_participants}</div>}
                  </div>

                  {/* Registration Fee */}
                  <div className="col-md-4">
                    <label htmlFor="registration_fee" className="form-label">Registration Fee *</label>
                    <div className="input-group">
                      <span className="input-group-text">$</span>
                      <input
                        type="number"
                        className={`form-control ${formErrors.registration_fee ? 'is-invalid' : ''}`}
                        id="registration_fee"
                        name="registration_fee"
                        value={formData.registration_fee}
                        onChange={handleInputChange}
                        min="0"
                        step="0.01"
                      />
                      {formErrors.registration_fee && <div className="invalid-feedback">{formErrors.registration_fee}</div>}
                    </div>
                  </div>

                  {/* Registration Deadline */}
                  <div className="col-md-4">
                    <label htmlFor="registration_deadline" className="form-label">Registration Deadline *</label>
                    <input
                      type="datetime-local"
                      className={`form-control ${formErrors.registration_deadline ? 'is-invalid' : ''}`}
                      id="registration_deadline"
                      name="registration_deadline"
                      value={formData.registration_deadline}
                      onChange={handleInputChange}
                    />
                    {formErrors.registration_deadline && <div className="invalid-feedback">{formErrors.registration_deadline}</div>}
                  </div>

                  {/* Is Team Event */}
                  <div className="col-12">
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="is_team_event"
                        name="is_team_event"
                        checked={formData.is_team_event}
                        onChange={handleInputChange}
                      />
                      <label className="form-check-label" htmlFor="is_team_event">
                        This is a team event
                      </label>
                    </div>
                  </div>

                  {/* Team Size (only shown if is_team_event is true) */}
                  {formData.is_team_event && (
                    <>
                      <div className="col-md-6">
                        <label htmlFor="min_team_size" className="form-label">Minimum Team Size *</label>
                        <input
                          type="number"
                          className={`form-control ${formErrors.min_team_size ? 'is-invalid' : ''}`}
                          id="min_team_size"
                          name="min_team_size"
                          value={formData.min_team_size}
                          onChange={handleInputChange}
                          min="1"
                        />
                        {formErrors.min_team_size && <div className="invalid-feedback">{formErrors.min_team_size}</div>}
                      </div>

                      <div className="col-md-6">
                        <label htmlFor="max_team_size" className="form-label">Maximum Team Size *</label>
                        <input
                          type="number"
                          className={`form-control ${formErrors.max_team_size ? 'is-invalid' : ''}`}
                          id="max_team_size"
                          name="max_team_size"
                          value={formData.max_team_size}
                          onChange={handleInputChange}
                          min={formData.min_team_size}
                        />
                        {formErrors.max_team_size && <div className="invalid-feedback">{formErrors.max_team_size}</div>}
                      </div>
                    </>
                  )}

                  {/* Form Actions */}
                  <div className="col-12 mt-4">
                    <div className="d-flex justify-content-end gap-2">
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={handleReset}
                        disabled={submitting}
                      >
                        Reset
                      </button>
                      <button
                        type="submit"
                        className="btn btn-primary"
                        disabled={submitting}
                      >
                        {submitting ? (
                          <>
                            <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                            Creating...
                          </>
                        ) : (
                          'Create Event'
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CreateEvent;