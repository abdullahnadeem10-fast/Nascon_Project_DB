import React, { useState, useEffect } from 'react';
import CreateAccommodation from './create/CreateAccomodation';
import ViewAccommodation from './view/ViewAccomodation';
import CreateRoom from './create/CreateRoom';
import ViewRooms from './view/ViewRooms';
import CreateNewRoomType from './create/CreateNewRoomType';
import ViewRoomTypes from './view/ViewRoomTypes';
import ViewAllRequests from './view/ViewAllRequests';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import CreateRoomAllocation from './create/CreateRoomAllocation';
import ViewRoomAllocations from './view/ViewRoomAllocations';
import CreateEventCategory from './create/CreateEventCategory';
import ViewEventCategories from './view/ViewEventCategories';
import CreateVenue from './create/CreateVenue';
import ViewVenues from './view/ViewVenues';
import CreateEvent from './create/CreateEvent';
import ViewEvents from './view/ViewEvents';
import './AdminDashboard.css';
import CreateEventSchedule from './create/CreateEventSchedule';
import ViewEventSchedules from './view/ViewEventSchedules';
import ViewTeams from './view/ViewTeams';
import ViewPayments from './view/ViewPayments';
import CreateFinancialReport from './create/CreateFinancialReports';
import ViewFinancialReports from './view/ViewFinancialReports';
import CreateExpense from './create/CreateExpense';
import ViewExpenses from './view/ViewExpnses';
import ViewEventRegistration from './view/ViewEventRegistration';
import CreateSponsorPackage from './create/CreateSponsorPackage';
import ViewSponsorPackages from './view/ViewSponsorPackages';
import ViewSponsorshipPayments from './view/ViewSponsorshipPayments';

function AdminDashboard() {
    const [activeComponent, setActiveComponent] = useState(() => 'create'); // Initialize with 'create'
    const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
    const [currentSection, setCurrentSection] = useState('accommodation');

    const toggleSidebar = () => {
        setSidebarCollapsed(!sidebarCollapsed);
    };

    const renderContent = () => {
        switch (activeComponent) {
            case 'create':
                return <CreateAccommodation />;
            case 'view':
                return <ViewAccommodation />;
            case 'createnewroomtype':
                return <CreateNewRoomType />;
            case 'viewroomtypes':
                return <ViewRoomTypes />;
            case 'createRoom':
                return <CreateRoom />;
            case 'viewRooms':
                return <ViewRooms />;
            case 'viewAllRequests':
                return <ViewAllRequests />;
            case 'createRoomAllocation':
                return <CreateRoomAllocation />;
            case 'viewRoomAllocations':
                return <ViewRoomAllocations />;
            case 'createEventCategory':
                return <CreateEventCategory />;
            case 'viewEventCategories':
                return <ViewEventCategories />;
            case 'createVenue':
                return <CreateVenue />;
            case 'viewVenues':
                return <ViewVenues />;
            case 'createEvent':
                return <CreateEvent />;
            case 'viewEvents':
                return <ViewEvents />;
            case 'createEventSchedule':
                return <CreateEventSchedule />;
            case 'viewEventSchedules':
                return <ViewEventSchedules />;
            case 'viewTeams':
                return <ViewTeams />;
            case 'viewPayments':
                return <ViewPayments />;
            case 'createFinancialReport':
                return <CreateFinancialReport />;
            case 'viewFinancialRports':
                return <ViewFinancialReports />;
            case 'createExpense':
                return <CreateExpense />;
            case 'viewexpenses':
                return <ViewExpenses />;
            case 'viewRegistration':
                return <ViewEventRegistration />;
                case 'createSponsorPackage':
                return <CreateSponsorPackage />;
            case 'viewSponsorPackages':
                return <ViewSponsorPackages />;
            case 'viewSponsorshipPayments':
                return <ViewSponsorshipPayments />;
            case 'createEvent':
                return <CreateEvent />;
            default:
                return <h4 className="text-center">Please select an option</h4>;
        }
    };

    return (
        <div className="d-flex dashboard-container">
            {/* Sidebar */}
            <div className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''}`} style={{
                width: sidebarCollapsed ? '80px' : '280px',
                height: 'calc(100vh - 56px)', /* Adjust height to account for navbar */
                transition: 'width 0.3s ease',
                backgroundColor: '#ffffff',
                boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
                overflowX: 'hidden',
                position: 'fixed',
                top: '56px', /* Position below navbar */
                left: 0,
                zIndex: 999 /* Set z-index below navbar */
            }}>
                <Sidebar
                    activeComponent={activeComponent}
                    setActiveComponent={setActiveComponent}
                    sidebarCollapsed={sidebarCollapsed}
                    currentSection={currentSection}
                    setCurrentSection={setCurrentSection}
                />
            </div>

            {/* Main Content */}
            <div className="content" style={{
                backgroundColor: '#f8f9fa',
                marginLeft: sidebarCollapsed ? '80px' : '280px',
                marginTop: '0px', /* Add top margin to account for navbar */
                transition: 'margin-left 0.3s ease',
                minHeight: 'calc(100vh)', /* Adjust height to account for navbar */
                width: 'calc(100% - ' + (sidebarCollapsed ? '80px' : '280px') + ')'
            }}>
                {/* Dashboard Header */}
                <div className="dashboard-header bg-white shadow-sm py-1 px-1 d-flex justify-content-between align-items-center" style={{ height: '40px' }}>
                    <div className="d-flex align-items-center">
                        <button
                            className="btn btn-sm border-0 p-1"
                            onClick={toggleSidebar}
                            style={{ marginRight: '10px', color: '#495057' }}
                        >
                            {!sidebarCollapsed ? <i className="bi bi-chevron-left"></i> : <i className="bi bi-chevron-right"></i>}
                        </button>
                        <span className="mb-0" style={{ color: '#3a506b', fontSize: '1rem', fontWeight: '500' }}>Management Dashboard</span>
                    </div>
                </div>

                {/* Content Area */}
                <div className="container-fluid py-2 px-4 content-area">
                    {renderContent()}
                </div>
            </div>

            {/* Mobile Offcanvas Sidebar */}
            <div
                className="offcanvas offcanvas-start d-md-none"
                tabIndex="-1"
                id="sidebarOffcanvas"
                aria-labelledby="sidebarOffcanvasLabel"
                style={{ backgroundColor: '#ffffff' }}
            >
                <div className="offcanvas-header">
                    <h5 id="sidebarOffcanvasLabel" className="text-primary">Dashboard Menu</h5>
                    <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="offcanvas"
                        aria-label="Close"
                    ></button>
                </div>
                <div className="offcanvas-body p-0">
                    <div className="mobile-sidebar-container" style={{ height: 'calc(100vh - 112px)', overflowY: 'hidden', marginTop: '0' }}>
                        <Sidebar
                            activeComponent={activeComponent}
                            setActiveComponent={setActiveComponent}
                            sidebarCollapsed={false}
                            currentSection={currentSection}
                            setCurrentSection={setCurrentSection}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}

function Sidebar({ activeComponent, setActiveComponent, sidebarCollapsed, currentSection, setCurrentSection }) {
    // Initialize activeItem with the current activeComponent from parent
    const [activeItem, setActiveItem] = useState(activeComponent || 'create');

    // Update activeItem when activeComponent changes
    useEffect(() => {
        setActiveItem(activeComponent);
    }, [activeComponent]);

    const handleMenuItemClick = (component, event) => {
        event.stopPropagation();
        setActiveComponent(component);
        setActiveItem(component);

        // Auto close offcanvas in mobile view
        if (window.innerWidth < 768) {
            const offcanvasEl = document.getElementById('sidebarOffcanvas');
            if (offcanvasEl && window.bootstrap?.Offcanvas) {
                const offcanvasInstance = window.bootstrap.Offcanvas.getInstance(offcanvasEl);
                if (offcanvasInstance) {
                    offcanvasInstance.hide();
                }
            }
        }
    };

    const toggleSection = (section) => {
        if (currentSection === section) {
            setCurrentSection('');
        } else {
            setCurrentSection(section);
        }
    };

    // Find which section contains the active component
    const findSectionForComponent = (componentId) => {
        for (const section of menuSections) {
            if (section.items.some(item => item.id === componentId)) {
                return section.id;
            }
        }
        return null;
    };

    // Set the current section based on the active component when component mounts
    useEffect(() => {
        const sectionId = findSectionForComponent(activeItem);
        if (sectionId && currentSection !== sectionId) {
            setCurrentSection(sectionId);
        }
    }, [activeItem]);

    // Define menu structure for cleaner rendering
    const menuSections = [
        {
            id: 'accommodation',
            title: 'Accommodation',
            items: [
                { id: 'create', title: 'Create Accommodation' },
                { id: 'view', title: 'View Accommodation' }
            ]
        },
        {
            id: 'requests',
            title: 'Accommodation Requests',
            items: [
                { id: 'viewAllRequests', title: 'View All Requests' }
            ]
        },
        {
            id: 'roomTypes',
            title: 'Room Types',
            items: [
                { id: 'createnewroomtype', title: 'Create New Room Type' },
                { id: 'viewroomtypes', title: 'View Room Types' }
            ]
        },
        {
            id: 'rooms',
            title: 'Rooms',
            items: [
                { id: 'createRoom', title: 'Create New Room' },
                { id: 'viewRooms', title: 'View All Rooms' }
            ]
        },
        {
            id: 'allocations',
            title: 'Room Allocations',
            items: [
                { id: 'viewRoomAllocations', title: 'View Room Allocations' }
            ]
        },
        {
            id: 'eventCategories',
            title: 'Event Categories',
            items: [
                { id: 'createEventCategory', title: 'Create Event Category' },
                { id: 'viewEventCategories', title: 'View Event Categories' }
            ]
        },
        {
            id: 'events',
            title: 'Events',
            items: [
                { id: 'viewEvents', title: 'View Events' },
                { id: 'createEvent', title: 'Create Event' }
            ]
        },
        {
            id: 'venues',
            title: 'Venues',
            items: [
                { id: 'createVenue', title: 'Create Venue' },
                { id: 'viewVenues', title: 'View Venues' }
            ]
        },
        {
            id: 'eventSchedules',
            title: 'Event Schedules',
            items: [
                { id: 'createEventSchedule', title: 'Create Schedule' },
                { id: 'viewEventSchedules', title: 'View Schedule' }
            ]
        },
        {
            id: 'teams',
            title: 'Teams',
            items: [
                { id: 'viewTeams', title: 'View Teams' }
            ]
        },
        {
            id: 'payments',
            title: 'Payments',
            items: [
                { id: 'viewPayments', title: 'View Payments' }
            ]
        },
        {
            id: 'financialReport',
            title: 'Financial Report',
            items: [
                { id: 'createFinancialReport', title: 'Create Financial Report' },
                { id: 'viewFinancialRports', title: 'View Financial Report' }
            ]
        },
        {
            id: 'expenses',
            title: 'Expenses',
            items: [
                { id: 'createExpense', title: 'Create Expenses' },
                { id: 'viewexpenses', title: 'View Expenses' }
            ]
        },
        {
            id: 'eventRegistration',
            title: 'Event Registration',
            items: [
                { id: 'viewRegistration', title: 'View Registration' }
            ]
        },
        {
            id: 'sponsorPackages',
            title: 'Sponsor Package',
            items: [
                { id: 'createSponsorPackage', title: 'Create' },
                { id: 'viewSponsorPackages', title: 'View' }
            ]
        },
        {
            id: 'sponsorshipPayments',
            title: 'Sponsorship Payments',
            items: [
                { id: 'viewSponsorshipPayments', title: 'View Payments' }
            ]
        }
    ];

    return (
        <div className="d-flex flex-column h-100 sidebar-inner">
            {/* Logo and Brand - Fixed at top */}
            <div className="d-flex align-items-center justify-content-center py-4 border-bottom sidebar-header">
                {sidebarCollapsed ? (
                    <div className="rounded-circle bg-light d-flex justify-content-center align-items-center" style={{ width: '40px', height: '40px', border: '1px solid #dee2e6' }}>
                        <i className="bi bi-person" style={{ fontSize: '18px', color: '#3a506b' }}></i>
                    </div>
                ) : (
                    <div className="d-flex align-items-center">
                        <div className="rounded-circle d-flex justify-content-center align-items-center me-2"
                            style={{
                                width: '40px',
                                height: '40px',
                                backgroundColor: '#3a506b',
                                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                            }}>
                            <i className="bi bi-person-fill" style={{ fontSize: '20px', color: '#ffffff' }}></i>
                        </div>
                        <h4 className="mb-0" style={{ color: '#3a506b', fontWeight: '600' }}>Admin Panel</h4>
                    </div>
                )}
            </div>

            {/* Navigation Menu - Scrollable */}
            <div className="sidebar-menu py-3 flex-grow-1 overflow-auto" style={{
                scrollbarWidth: 'thin',
                overflowY: 'auto',
                height: 'calc(100vh - 196px)' // Adjust based on header, footer height and navbar (56px)
            }}>
                {menuSections.map((section) => (
                    <div key={section.id} className="mb-1">
                        <button
                            onClick={() => toggleSection(section.id)}
                            className={`btn d-flex align-items-center w-100 py-2 px-3 text-start border-0 section-header ${currentSection === section.id ? 'active' : ''}`}
                            style={{
                                borderRadius: '0',
                                marginBottom: '2px',
                                color: '#495057'
                            }}
                        >
                            {!sidebarCollapsed && (
                                <>
                                    <span className="flex-grow-1">{section.title}</span>
                                    <span className="ms-2">
                                        <i className={`bi ${currentSection === section.id ? 'bi-chevron-down' : 'bi-chevron-right'} chevron-icon ${currentSection === section.id ? 'open' : ''}`}></i>
                                    </span>
                                </>
                            )}
                        </button>

                        {/* Section Items */}
                        {!sidebarCollapsed && (
                            <div className={`ps-4 mt-1 submenu ${currentSection === section.id ? 'open' : ''}`}>
                                {section.items.map((item) => (
                                    <button
                                        key={item.id}
                                        className={`btn btn-sm d-flex align-items-center w-100 py-2 px-3 text-start border-0 menu-item ${activeItem === item.id ? 'active' : ''}`}
                                        onClick={(e) => handleMenuItemClick(item.id, e)}
                                        style={{
                                            borderRadius: '0',
                                            color: '#6c757d',
                                            fontWeight: '400'
                                        }}
                                    >
                                        <span className="ms-2">{item.title}</span>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                ))}
            </div>

            {/* Footer - Fixed at bottom */}
            {!sidebarCollapsed && (
                <div className="border-top p-3 text-center sidebar-footer">
                    <small style={{ color: '#8898aa' }}>© 2025 Admin System</small>
                </div>
            )}
        </div>
    );
}

export default AdminDashboard;
