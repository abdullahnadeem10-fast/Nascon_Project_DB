import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BaseUrl from '../../../BaseUrl';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import '../../../styles/SponsorshipPayments.css';

function ViewSponsorshipPayments() {
  const [payments, setPayments] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [sponsors, setSponsors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    contract_id: '',
    amount: '',
    payment_method: 'Bank Transfer',
    transaction_id: '',
    payment_date: new Date().toISOString().split('T')[0],
    notes: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [showEditForm, setShowEditForm] = useState(false);
  const [filterContractId, setFilterContractId] = useState('');
  const [filterPaymentMethod, setFilterPaymentMethod] = useState('');

  const accessToken = localStorage.getItem('access_token');
  const apiBaseUrl = BaseUrl;

  useEffect(() => {
    fetchPayments();
    fetchContracts();
    fetchSponsors();
  }, []);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${apiBaseUrl}/sponsorship/payments/?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setPayments(response.data.payments || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching payments:', err);
      setError('Failed to load payments. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchContracts = async () => {
    try {
      const response = await axios.get(
        `${apiBaseUrl}/sponsorship/contracts/?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setContracts(response.data.contracts || []);
    } catch (err) {
      console.error('Error fetching contracts:', err);
    }
  };

  const fetchSponsors = async () => {
    try {
      const response = await axios.get(
        `${apiBaseUrl}/sponsorship/sponsors/?skip=0&limit=100`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setSponsors(response.data.sponsors || []);
    } catch (err) {
      console.error('Error fetching sponsors:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    // Clear error when field is edited
    if (formErrors[name]) {
      setFormErrors({ ...formErrors, [name]: null });
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.contract_id) {
      errors.contract_id = 'Contract is required';
    }

    if (!formData.amount || isNaN(formData.amount) || parseFloat(formData.amount) <= 0) {
      errors.amount = 'Valid amount is required';
    }

    if (!formData.payment_method) {
      errors.payment_method = 'Payment method is required';
    }

    if (!formData.payment_date) {
      errors.payment_date = 'Payment date is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddPayment = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.post(
        `${apiBaseUrl}/sponsorship/payments/`,
        {
          ...formData,
          amount: parseFloat(formData.amount),
          contract_id: parseInt(formData.contract_id)
        },
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      // Reset form
      setFormData({
        contract_id: '',
        amount: '',
        payment_method: 'Bank Transfer',
        transaction_id: '',
        payment_date: new Date().toISOString().split('T')[0],
        notes: ''
      });

      setShowAddForm(false);
      await fetchPayments();

      // Update contract payment status if needed
      await fetchContracts();
    } catch (err) {
      console.error('Error adding payment:', err);
      setError('Failed to add payment. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdatePayment = async () => {
    if (!selectedPayment || !validateForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.put(
        `${apiBaseUrl}/sponsorship/payments/${selectedPayment.id}`,
        {
          ...formData,
          amount: parseFloat(formData.amount),
          contract_id: parseInt(formData.contract_id)
        },
        {
          headers: {
            accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setShowEditForm(false);
      setSelectedPayment(null);
      await fetchPayments();

      // Update contract payment status if needed
      await fetchContracts();
    } catch (err) {
      console.error('Error updating payment:', err);
      setError('Failed to update payment. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeletePayment = async (id) => {
    if (!window.confirm('Are you sure you want to delete this payment?')) {
      return;
    }

    try {
      await axios.delete(
        `${apiBaseUrl}/sponsorship/payments/${id}`,
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      setPayments(payments.filter(payment => payment.id !== id));

      // Update contract payment status if needed
      await fetchContracts();
    } catch (err) {
      console.error('Error deleting payment:', err);
      setError('Failed to delete payment. Please try again.');
    }
  };

  const handleEditPayment = (payment) => {
    setSelectedPayment(payment);
    setFormData({
      contract_id: payment.contract_id.toString(),
      amount: payment.amount.toString(),
      payment_method: payment.payment_method,
      transaction_id: payment.transaction_id || '',
      payment_date: payment.payment_date ? new Date(payment.payment_date).toISOString().split('T')[0] : '',
      notes: payment.notes || ''
    });
    setShowEditForm(true);
  };

  const getContractDetails = (contractId) => {
    const contract = contracts.find(c => c.id === contractId);
    if (!contract) return { sponsorName: 'Unknown', amount: 0 };

    const sponsor = sponsors.find(s => s.id === contract.sponsor_id);
    return {
      sponsorName: sponsor ? sponsor.company_name : 'Unknown',
      amount: contract.total_amount
    };
  };

  const filteredPayments = payments.filter(payment => {
    if (filterContractId && payment.contract_id.toString() !== filterContractId) {
      return false;
    }
    if (filterPaymentMethod && payment.payment_method !== filterPaymentMethod) {
      return false;
    }
    return true;
  });

  return (
    <div className="container-fluid mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="h3">Sponsorship Payments</h2>
        <button
          onClick={() => setShowAddForm(true)}
          className="btn btn-primary d-flex align-items-center"
        >
          <i className="bi bi-plus-lg me-2"></i>
          Add Payment
        </button>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
          <span>{error}</span>
          <button type="button" className="btn-close" aria-label="Close" onClick={() => setError(null)}></button>
        </div>
      )}

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row">
            <div className="col-md-5">
              <label className="form-label">Filter by Contract</label>
              <select
                className="form-select"
                value={filterContractId}
                onChange={(e) => setFilterContractId(e.target.value)}
              >
                <option value="">All Contracts</option>
                {contracts.map(contract => {
                  const { sponsorName } = getContractDetails(contract.id);
                  return (
                    <option key={contract.id} value={contract.id.toString()}>
                      {sponsorName} - ${contract.total_amount}
                    </option>
                  );
                })}
              </select>
            </div>
            <div className="col-md-5">
              <label className="form-label">Filter by Payment Method</label>
              <select
                className="form-select"
                value={filterPaymentMethod}
                onChange={(e) => setFilterPaymentMethod(e.target.value)}
              >
                <option value="">All Methods</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Check">Check</option>
                <option value="Online Payment">Online Payment</option>
              </select>
            </div>
            <div className="col-md-2 d-flex align-items-end">
              <button
                className="btn btn-outline-secondary w-100"
                onClick={() => {
                  setFilterContractId('');
                  setFilterPaymentMethod('');
                }}
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="d-flex justify-content-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : (
        <>
          {filteredPayments.length > 0 ? (
            <div className="card shadow-sm">
              <div className="card-body p-0">
                <div className="table-container">
                  <table className="table table-striped table-hover mb-0">
                    <thead className="bg-light">
                      <tr>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '150px' }}>Sponsor</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '120px' }}>Amount</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '150px' }}>Payment Method</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '150px' }}>Transaction ID</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '120px' }}>Payment Date</th>
                        <th scope="col" className="px-3 py-2" style={{ minWidth: '200px' }}>Notes</th>
                        <th scope="col" className="px-3 py-2 text-end" style={{ minWidth: '120px' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredPayments.map((payment) => {
                        const { sponsorName } = getContractDetails(payment.contract_id);
                        return (
                          <tr key={payment.id} className="hover-bg-light">
                            <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>{sponsorName}</td>
                            <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>${payment.amount.toLocaleString()}</td>
                            <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>{payment.payment_method}</td>
                            <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>{payment.transaction_id || '-'}</td>
                            <td className="px-3 py-2" style={{ whiteSpace: 'nowrap' }}>
                              {payment.payment_date ? new Date(payment.payment_date).toLocaleDateString() : '-'}
                            </td>
                            <td className="px-3 py-2">{payment.notes || '-'}</td>
                            <td className="px-3 py-2 text-end" style={{ whiteSpace: 'nowrap' }}>
                              <button
                                onClick={() => handleEditPayment(payment)}
                                className="btn btn-outline-primary btn-sm me-2"
                              >
                                <i className="bi bi-pencil"></i>
                              </button>
                              <button
                                onClick={() => handleDeletePayment(payment.id)}
                                className="btn btn-outline-danger btn-sm"
                              >
                                <i className="bi bi-trash"></i>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="card shadow-sm">
              <div className="card-body text-center py-5">
                <i className="bi bi-cash-stack display-4 text-muted mb-3"></i>
                <p className="lead mb-0">No sponsorship payments found</p>
                <p className="text-muted">Click "Add Payment" to record a new payment</p>
              </div>
            </div>
          )}
        </>
      )}

      {/* Add Payment Modal */}
      {showAddForm && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Payment</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="contract_id" className="form-label">Contract *</label>
                    <select
                      className={`form-select ${formErrors.contract_id ? 'is-invalid' : ''}`}
                      id="contract_id"
                      name="contract_id"
                      value={formData.contract_id}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Contract</option>
                      {contracts.map(contract => {
                        const { sponsorName } = getContractDetails(contract.id);
                        return (
                          <option key={contract.id} value={contract.id.toString()}>
                            {sponsorName} - ${contract.total_amount}
                          </option>
                        );
                      })}
                    </select>
                    {formErrors.contract_id && <div className="invalid-feedback">{formErrors.contract_id}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="amount" className="form-label">Amount *</label>
                    <div className="input-group">
                      <span className="input-group-text">$</span>
                      <input
                        type="number"
                        className={`form-control ${formErrors.amount ? 'is-invalid' : ''}`}
                        id="amount"
                        name="amount"
                        value={formData.amount}
                        onChange={handleInputChange}
                        min="0"
                        step="0.01"
                      />
                      {formErrors.amount && <div className="invalid-feedback">{formErrors.amount}</div>}
                    </div>
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="payment_method" className="form-label">Payment Method *</label>
                    <select
                      className={`form-select ${formErrors.payment_method ? 'is-invalid' : ''}`}
                      id="payment_method"
                      name="payment_method"
                      value={formData.payment_method}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Payment Method</option>
                      <option value="Cash">Cash</option>
                      <option value="Bank Transfer">Bank Transfer</option>
                      <option value="Credit Card">Credit Card</option>
                      <option value="Check">Check</option>
                      <option value="Online Payment">Online Payment</option>
                    </select>
                    {formErrors.payment_method && <div className="invalid-feedback">{formErrors.payment_method}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="payment_date" className="form-label">Payment Date *</label>
                    <input
                      type="date"
                      className={`form-control ${formErrors.payment_date ? 'is-invalid' : ''}`}
                      id="payment_date"
                      name="payment_date"
                      value={formData.payment_date}
                      onChange={handleInputChange}
                    />
                    {formErrors.payment_date && <div className="invalid-feedback">{formErrors.payment_date}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="transaction_id" className="form-label">Transaction ID</label>
                    <input
                      type="text"
                      className="form-control"
                      id="transaction_id"
                      name="transaction_id"
                      value={formData.transaction_id}
                      onChange={handleInputChange}
                      placeholder="Optional"
                    />
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="notes" className="form-label">Notes</label>
                    <textarea
                      className="form-control"
                      id="notes"
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      rows="2"
                      placeholder="Optional"
                    ></textarea>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleAddPayment}
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Saving...
                    </>
                  ) : (
                    'Save Payment'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Payment Modal */}
      {showEditForm && selectedPayment && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit Payment</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditForm(false)} aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="edit_contract_id" className="form-label">Contract *</label>
                    <select
                      className={`form-select ${formErrors.contract_id ? 'is-invalid' : ''}`}
                      id="edit_contract_id"
                      name="contract_id"
                      value={formData.contract_id}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Contract</option>
                      {contracts.map(contract => {
                        const { sponsorName } = getContractDetails(contract.id);
                        return (
                          <option key={contract.id} value={contract.id.toString()}>
                            {sponsorName} - ${contract.total_amount}
                          </option>
                        );
                      })}
                    </select>
                    {formErrors.contract_id && <div className="invalid-feedback">{formErrors.contract_id}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_amount" className="form-label">Amount *</label>
                    <div className="input-group">
                      <span className="input-group-text">$</span>
                      <input
                        type="number"
                        className={`form-control ${formErrors.amount ? 'is-invalid' : ''}`}
                        id="edit_amount"
                        name="amount"
                        value={formData.amount}
                        onChange={handleInputChange}
                        min="0"
                        step="0.01"
                      />
                      {formErrors.amount && <div className="invalid-feedback">{formErrors.amount}</div>}
                    </div>
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_payment_method" className="form-label">Payment Method *</label>
                    <select
                      className={`form-select ${formErrors.payment_method ? 'is-invalid' : ''}`}
                      id="edit_payment_method"
                      name="payment_method"
                      value={formData.payment_method}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Payment Method</option>
                      <option value="Cash">Cash</option>
                      <option value="Bank Transfer">Bank Transfer</option>
                      <option value="Credit Card">Credit Card</option>
                      <option value="Check">Check</option>
                      <option value="Online Payment">Online Payment</option>
                    </select>
                    {formErrors.payment_method && <div className="invalid-feedback">{formErrors.payment_method}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_payment_date" className="form-label">Payment Date *</label>
                    <input
                      type="date"
                      className={`form-control ${formErrors.payment_date ? 'is-invalid' : ''}`}
                      id="edit_payment_date"
                      name="payment_date"
                      value={formData.payment_date}
                      onChange={handleInputChange}
                    />
                    {formErrors.payment_date && <div className="invalid-feedback">{formErrors.payment_date}</div>}
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_transaction_id" className="form-label">Transaction ID</label>
                    <input
                      type="text"
                      className="form-control"
                      id="edit_transaction_id"
                      name="transaction_id"
                      value={formData.transaction_id}
                      onChange={handleInputChange}
                      placeholder="Optional"
                    />
                  </div>

                  <div className="col-md-6">
                    <label htmlFor="edit_notes" className="form-label">Notes</label>
                    <textarea
                      className="form-control"
                      id="edit_notes"
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      rows="2"
                      placeholder="Optional"
                    ></textarea>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowEditForm(false)}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleUpdatePayment}
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Updating...
                    </>
                  ) : (
                    'Update Payment'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ViewSponsorshipPayments;