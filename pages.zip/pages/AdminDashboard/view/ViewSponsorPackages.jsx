import React, { useEffect, useState } from 'react';
import axios from 'axios';
import BaseUrl from '../../../BaseUrl';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

function ViewSponsorPackages() {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  const accessToken = localStorage.getItem('access_token');

  const fetchPackages = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${BaseUrl}/sponsorship/packages/?skip=0&limit=100`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            accept: 'application/json',
          },
        }
      );
      setPackages(response.data.packages);
    } catch (error) {
      console.error('Error fetching packages:', error);
      setMessage('❌ Failed to load sponsor packages.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this package?')) return;

    try {
      await axios.delete(`${BaseUrl}/sponsorship/packages/${id}`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          accept: 'application/json',
        },
      });
      setMessage('✅ Package deleted successfully!');
      setPackages((prev) => prev.filter((pkg) => pkg.id !== id));
    } catch (error) {
      console.error('Delete error:', error);
      setMessage('❌ Failed to delete package.');
    }
  };

  useEffect(() => {
    fetchPackages();
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4 text-primary">
        View Sponsor Packages
      </h2>

      {message && (
        <div className={`alert ${message.startsWith('✅') ? 'alert-success' : 'alert-danger'} text-center`} role="alert">
          {message}
        </div>
      )}

      {loading ? (
        <div className="d-flex justify-content-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : packages.length === 0 ? (
        <p className="text-center text-muted">No sponsor packages found.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-bordered table-striped shadow-sm rounded-lg overflow-hidden">
            <thead className="bg-primary text-white">
              <tr>
                <th className="py-2 px-3">Package Name</th>
                <th className="py-2 px-3">Description</th>
                <th className="py-2 px-3">Price</th>
                <th className="py-2 px-3">Benefits</th>
                <th className="py-2 px-3">Max Sponsors</th>
                <th className="py-2 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {packages.map((pkg) => (
                <tr key={pkg.id}>
                  <td className="py-2 px-3">{pkg.package_name}</td>
                  <td className="py-2 px-3">{pkg.description}</td>
                  <td className="py-2 px-3">{pkg.price}</td>
                  <td className="py-2 px-3">{pkg.benefits}</td>
                  <td className="py-2 px-3">{pkg.max_sponsors}</td>
                  <td className="py-2 px-3 text-center">
                    <button
                      onClick={() => handleDelete(pkg.id)}
                      className="btn btn-danger btn-sm"
                    >
                      <i className="bi bi-trash me-1"></i>Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default ViewSponsorPackages;