function EditVenue(id) {
    console.log(id);
    
    return ( 
        <>
         Edit Venue
        </>
     );
}

export default EditVenue;