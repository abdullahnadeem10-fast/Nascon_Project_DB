function EditRoomAllocation() {
    return ( 
        <>
          Edit Room Allocation
        </>
     );
}

export default EditRoomAllocation;