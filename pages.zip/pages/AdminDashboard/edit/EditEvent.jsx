function EditEvent() {
    return ( 
        <>
         Edit Event
         </>
        
     );
}

export default EditEvent;