function EditEventCategory() {
    return ( 
        <>
         Edit Event Categories
        </>
     );
}

export default EditEventCategory;