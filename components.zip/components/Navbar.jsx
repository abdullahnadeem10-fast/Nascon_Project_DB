import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { isAuthenticated, getUserRole } from '../utils/authUtils';
import NotificationDropdown from './NotificationDropdown';
import '../styles/Navbar.css';
import '../styles/NotificationDropdown.css';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [authenticated, setAuthenticated] = useState(isAuthenticated());
  const [userRole, setUserRole] = useState(getUserRole());
  const location = useLocation();

  // Update authentication state when location changes or storage event is triggered
  useEffect(() => {
    const updateAuthState = () => {
      const isAuth = isAuthenticated();
      const role = getUserRole();
      console.log('Navbar: Updating auth state - authenticated:', isAuth, 'role:', role);
      setAuthenticated(isAuth);
      setUserRole(role);
    };

    // Initial update
    updateAuthState();

    // Listen for storage events (including our custom one)
    const handleStorageChange = (e) => {
      console.log('Navbar: Storage event detected', e.key);
      updateAuthState();
    };

    window.addEventListener('storage', handleStorageChange);

    // Clean up event listener
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [location]);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = () => {
    console.log('Navbar: Logging out user');
    // Clear authentication data
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    // Update state
    setAuthenticated(false);
    setUserRole(null);
    console.log('Navbar: Auth state after logout - authenticated:', false, 'role:', null);
    // Dispatch storage event to notify other components
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'user',
      oldValue: 'user data',
      newValue: null
    }));
    // Redirect to home page
    window.location.href = '/';
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm fixed-top">
      <div className="container">
        <Link to="/" className="navbar-brand fw-bold d-flex align-items-center">
          <span className="me-1">NASCON</span>
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          onClick={toggleMenu}
          aria-expanded={isOpen}
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`}>
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
            {/* Common navigation items for all users */}
            <li className="nav-item">
              <Link to="/" className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}>
                <i className="bi bi-house-door me-1"></i> Home
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/about" className={`nav-link ${location.pathname === '/about' ? 'active' : ''}`}>
                <i className="bi bi-info-circle me-1"></i> About
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/contact" className={`nav-link ${location.pathname === '/contact' ? 'active' : ''}`}>
                <i className="bi bi-envelope me-1"></i> Contact
              </Link>
            </li>

            {/* Authenticated user navigation */}
            {authenticated ? (
              <>
                {/* Events Dropdown - Visible to all authenticated users */}
                <li className="nav-item dropdown">
                  <a className={`nav-link dropdown-toggle ${location.pathname.includes('/events') || location.pathname.includes('/teams') || location.pathname.includes('/my-registrations') ? 'active' : ''}`}
                     href="#"
                     id="eventsDropdown"
                     role="button"
                     data-bs-toggle="dropdown"
                     aria-expanded="false">
                    <i className="bi bi-calendar-event me-1"></i> Events
                  </a>
                  <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="eventsDropdown">
                    {/* Browse Events - Visible to all */}
                    <li>
                      <Link to="/events" className="dropdown-item">
                        <i className="bi bi-calendar3 me-2"></i>
                        Browse Events
                      </Link>
                    </li>

                    {/* Create Event - Visible to Admin and Event Organizer */}
                    {(userRole === 'Admin' || userRole === 'Event Organizer') && (
                      <li>
                        <Link to="/create-event" className="dropdown-item">
                          <i className="bi bi-plus-circle me-2"></i>
                          Create Event
                        </Link>
                      </li>
                    )}

                    {/* My Teams - Visible to Participant */}
                    {(userRole === 'Admin' || userRole === 'Participant') && (
                      <li>
                        <Link to="/teams" className="dropdown-item">
                          <i className="bi bi-people-fill me-2"></i>
                          My Teams
                        </Link>
                      </li>
                    )}

                    {/* My Registrations - Visible to Participant */}
                    {(userRole === 'Admin' || userRole === 'Participant') && (
                      <li>
                        <Link to="/my-registrations" className="dropdown-item">
                          <i className="bi bi-card-checklist me-2"></i>
                          My Registrations
                        </Link>
                      </li>
                    )}

                    {/* Judging - Visible to Judge */}
                    {userRole === 'Judge' && (
                      <li>
                        <Link to="/judging" className="dropdown-item">
                          <i className="bi bi-award me-2"></i>
                          Judging Panel
                        </Link>
                      </li>
                    )}
                  </ul>
                </li>

                {/* Sponsorship Dropdown - Visible to Admin, Event Organizer, and Sponsor */}
                {(userRole === 'Admin' || userRole === 'Event Organizer' || userRole === 'Sponsor') && (
                  <li className="nav-item dropdown">
                    <a className={`nav-link dropdown-toggle ${location.pathname.includes('/sponsorship') ? 'active' : ''}`}
                       href="#"
                       id="sponsorshipDropdown"
                       role="button"
                       data-bs-toggle="dropdown"
                       aria-expanded="false">
                      <i className="bi bi-award me-1"></i> Sponsorship
                    </a>
                    <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="sponsorshipDropdown">
                      <li>
                        <Link to="/sponsorships" className="dropdown-item">
                          <i className="bi bi-briefcase me-2"></i>
                          Sponsorships
                        </Link>
                      </li>

                      {/* Contracts - Visible to Admin, Event Organizer, and Sponsor */}
                      <li>
                        <Link to="/SponsorshipContracts" className="dropdown-item">
                          <i className="bi bi-file-earmark-text me-2"></i>
                          Contracts
                        </Link>
                      </li>

                      {/* Sponsor Dashboard - Visible only to Sponsor */}
                      {userRole === 'Sponsor' && (
                        <li>
                          <Link to="/sponsor-dashboard" className="dropdown-item">
                            <i className="bi bi-graph-up me-2"></i>
                            Sponsor Dashboard
                          </Link>
                        </li>
                      )}
                    </ul>
                  </li>
                )}

                {/* My Account Dropdown - Visible to all authenticated users */}
                <li className="nav-item dropdown">
                  <a className={`nav-link dropdown-toggle ${location.pathname.includes('/my-payments') ? 'active' : ''}`}
                     href="#"
                     id="accountDropdown"
                     role="button"
                     data-bs-toggle="dropdown"
                     aria-expanded="false">
                    <i className="bi bi-person-circle me-1"></i> My Account
                  </a>
                  <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="accountDropdown">
                    <li>
                      <Link to="/profile" className="dropdown-item">
                        <i className="bi bi-person me-2"></i>
                        Profile
                      </Link>
                    </li>

                    {/* My Payments - Visible to Participant and Sponsor */}
                    {(userRole === 'Admin' || userRole === 'Participant' || userRole === 'Sponsor') && (
                      <li>
                        <Link to="/my-payments" className="dropdown-item">
                          <i className="bi bi-credit-card me-2"></i>
                          My Payments
                        </Link>
                      </li>
                    )}

                    <li><hr className="dropdown-divider" /></li>
                    <li>
                      <button
                        onClick={handleLogout}
                        className="dropdown-item text-danger"
                      >
                        <i className="bi bi-box-arrow-right me-2"></i>
                        Logout
                      </button>
                    </li>
                  </ul>
                </li>

                {/* Admin Portal (if admin) */}
                {userRole === 'Admin' && (
                  <li className="nav-item">
                    <Link to="/AdminDashboard" className={`nav-link ${location.pathname.includes('/AdminDashboard') ? 'active' : ''}`}>
                      <i className="bi bi-speedometer2 me-1"></i> Admin
                    </Link>
                  </li>
                )}

                {/* Event Organizer Dashboard */}
                {userRole === 'Event Organizer' && (
                  <li className="nav-item">
                    <Link to="/organizer-dashboard" className={`nav-link ${location.pathname.includes('/organizer-dashboard') ? 'active' : ''}`}>
                      <i className="bi bi-clipboard-data me-1"></i> Organizer
                    </Link>
                  </li>
                )}

                {/* Notifications - Visible to all authenticated users */}
                <li className="nav-item">
                  <NotificationDropdown />
                </li>
              </>
            ) : (
              <>
                {/* Authentication links for non-authenticated users */}
                <li className="nav-item">
                  <Link to="/signin" className={`nav-link ${location.pathname === '/signin' ? 'active' : ''}`}>
                    <i className="bi bi-box-arrow-in-right me-1"></i> Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/signup" className={`nav-link ${location.pathname === '/signup' ? 'active' : ''}`}>
                    <i className="bi bi-person-plus me-1"></i> Sign Up
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
