import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import BaseUrl from '../BaseUrl';
import { NavDropdown } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

function NotificationDropdown() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);

  const baseUrl = BaseUrl;
  const accessToken = localStorage.getItem('access_token');

  useEffect(() => {
    const fetchNotifications = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get(
          `${baseUrl}/notifications/?skip=0&limit=5`, // Limit to 5 most recent notifications
          {
            headers: {
              accept: 'application/json',
              Authorization: `Bearer ${accessToken}`,
            },
          }
        );
        setNotifications(response.data.notifications || []);
        setUnreadCount(response.data.unread_count || 0);
      } catch (err) {
        console.error('Error fetching notifications:', err);
        setError('Failed to load notifications.');
      } finally {
        setLoading(false);
      }
    };

    if (accessToken) {
      fetchNotifications();
      
      // Set up a refresh interval (every 30 seconds)
      const intervalId = setInterval(fetchNotifications, 30000);
      
      // Clean up interval on component unmount
      return () => clearInterval(intervalId);
    }
  }, [accessToken, baseUrl]);

  const markAsRead = async (id, e) => {
    e.preventDefault(); // Prevent dropdown from closing
    e.stopPropagation(); // Prevent event bubbling
    
    try {
      await axios.put(
        `${baseUrl}/notifications/${id}/read`,
        {},
        {
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      setNotifications((prev) =>
        prev.map((notification) =>
          notification.id === id ? { ...notification, is_read: true } : notification
        )
      );
      setUnreadCount((prevCount) => Math.max(0, prevCount - 1));
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  // Custom title with notification bell and badge
  const notificationTitle = (
    <div className="notification-icon-container">
      <i className="bi bi-bell-fill"></i>
      {unreadCount > 0 && (
        <span className="notification-badge">{unreadCount}</span>
      )}
    </div>
  );

  return (
    <NavDropdown 
      title={notificationTitle} 
      id="notification-dropdown"
      align="end"
      className="notification-dropdown"
    >
      <div className="notification-header">
        <h6 className="mb-0">Notifications</h6>
        {unreadCount > 0 && (
          <Link 
            to="/notifications" 
            className="text-primary small"
          >
            View All ({unreadCount} unread)
          </Link>
        )}
      </div>
      
      <NavDropdown.Divider />
      
      {loading ? (
        <div className="notification-loading">Loading...</div>
      ) : error ? (
        <div className="notification-error">{error}</div>
      ) : notifications.length === 0 ? (
        <div className="notification-empty">No notifications</div>
      ) : (
        <>
          {notifications.slice(0, 5).map((notification) => (
            <div 
              key={notification.id} 
              className={`notification-item ${!notification.is_read ? 'unread' : ''}`}
            >
              <div className="notification-content">
                <div className="notification-title">{notification.title}</div>
                <div className="notification-message">{notification.message}</div>
                <small className="notification-meta">
                  {new Date(notification.created_at).toLocaleString()}
                </small>
              </div>
              {!notification.is_read && (
                <button
                  className="btn btn-sm mark-read-btn"
                  onClick={(e) => markAsRead(notification.id, e)}
                >
                  <i className="bi bi-check-lg"></i>
                </button>
              )}
            </div>
          ))}
          
          <NavDropdown.Divider />
          
          <Link to="/notifications" className="view-all-link">
            View All Notifications
          </Link>
        </>
      )}
    </NavDropdown>
  );
}

export default NotificationDropdown;
